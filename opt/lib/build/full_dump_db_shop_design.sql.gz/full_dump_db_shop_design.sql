/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.14-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: db-host-shop-design-609221    Database: db_shop_design
-- ------------------------------------------------------
-- Server version	10.11.19-MariaDB-ubu2204

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `basket`
--

DROP TABLE IF EXISTS `basket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `basket` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `sid` mediumint(8) unsigned NOT NULL COMMENT 'Session ID',
  `uid` mediumint(8) unsigned DEFAULT NULL,
  `prod_id` mediumint(8) unsigned NOT NULL COMMENT 'Product ID',
  `instime` timestamp NOT NULL DEFAULT current_timestamp(),
  `count` int(11) NOT NULL,
  `campaign_id` smallint(5) unsigned NOT NULL DEFAULT 0,
  `price` double NOT NULL COMMENT 'Excl. VAT',
  PRIMARY KEY (`id`),
  KEY `sid` (`sid`),
  KEY `sid_2` (`sid`)
) ENGINE=InnoDB AUTO_INCREMENT=352 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `basket`
--

LOCK TABLES `basket` WRITE;
/*!40000 ALTER TABLE `basket` DISABLE KEYS */;
INSERT INTO `basket` VALUES
(179,95,0,7,'2026-10-04 11:34:03',1,0,700),
(191,98,0,7,'2026-10-04 16:53:44',1,0,700),
(192,98,0,7,'2026-10-04 17:33:40',1,0,700),
(214,105,0,6,'2026-10-06 15:46:20',1,0,300),
(224,106,0,4,'2026-10-07 09:52:32',1,0,755.6),
(231,107,0,3,'2026-10-07 15:04:46',1,0,97.3),
(232,108,0,4,'2026-10-07 15:25:00',1,0,755.6),
(233,108,0,1,'2026-10-07 15:25:02',1,0,107.55),
(234,109,0,2,'2026-10-07 15:37:44',1,0,364.75),
(235,110,0,6,'2026-10-07 15:40:52',1,0,300),
(236,111,0,1,'2026-10-07 19:02:06',1,0,107.55),
(244,2086,0,6,'2026-10-14 11:55:50',1,0,300),
(245,2086,0,7,'2026-10-16 12:24:48',1,0,700),
(267,138,0,8,'2026-10-20 12:08:19',1,0,50),
(278,0,0,4,'2026-10-21 09:28:05',1,0,755.6),
(279,0,0,5,'2026-10-21 09:28:15',1,0,100),
(280,0,0,8,'2026-10-21 09:28:24',1,0,50),
(281,0,0,4,'2026-10-21 09:28:32',1,0,755.6),
(282,0,0,4,'2026-10-21 09:28:36',1,0,755.6),
(283,0,0,8,'2026-10-21 09:28:49',1,0,50),
(304,140,0,6,'2026-10-26 10:09:42',1,0,300),
(305,141,0,6,'2026-10-26 10:20:07',1,0,300),
(313,141,0,2,'2026-10-26 12:32:02',1,0,364.75),
(314,143,0,2,'2026-10-26 14:14:18',1,0,364.75),
(315,144,0,1,'2026-10-26 14:34:53',1,0,100),
(349,78,0,7,'2026-10-29 13:25:50',1,0,700),
(350,78,0,6,'2026-10-29 13:37:33',3,0,300),
(351,78,0,1,'2026-11-09 06:34:30',1,0,90);
/*!40000 ALTER TABLE `basket` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `basket_details`
--

DROP TABLE IF EXISTS `basket_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `basket_details` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `basket_id` mediumint(8) unsigned NOT NULL,
  `feature_id` mediumint(8) unsigned NOT NULL,
  `ref` char(255) NOT NULL,
  `price` double NOT NULL COMMENT 'Excl. VAT',
  PRIMARY KEY (`id`),
  KEY `basket_id` (`basket_id`),
  CONSTRAINT `basket_details_ibfk_1` FOREIGN KEY (`basket_id`) REFERENCES `basket` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=122 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `basket_details`
--

LOCK TABLES `basket_details` WRITE;
/*!40000 ALTER TABLE `basket_details` DISABLE KEYS */;
INSERT INTO `basket_details` VALUES
(4,179,1,'IDENT-DE-610041-2',4.63),
(5,179,2,'R61004-2',18.5),
(28,191,1,'IDENT-DE-610041-1',4.63),
(29,191,2,'R61004-1',18.5),
(30,192,1,'IDENT-DE-610041-2',4.63),
(31,192,2,'R61004-2',18.5),
(71,245,1,'IDENT-DE-610041-1',4.63),
(120,349,1,'IDENT-DE-610041-1',4.63),
(121,349,2,'R61004-1',18.5);
/*!40000 ALTER TABLE `basket_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `campaign_data`
--

DROP TABLE IF EXISTS `campaign_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `campaign_data` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `instime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `token` varchar(255) NOT NULL,
  `company_id` smallint(5) unsigned NOT NULL,
  `discount` double DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `token` (`token`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `campaign_data`
--

LOCK TABLES `campaign_data` WRITE;
/*!40000 ALTER TABLE `campaign_data` DISABLE KEYS */;
INSERT INTO `campaign_data` VALUES
(1,'2026-10-27 06:04:22','TOK21',11,0);
/*!40000 ALTER TABLE `campaign_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `campaign_maildom`
--

DROP TABLE IF EXISTS `campaign_maildom`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `campaign_maildom` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT 'XXX Refers to products : campaign_id',
  `instime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `company_id` smallint(5) unsigned NOT NULL COMMENT 'Refers to companies [id]',
  `mail_domain` char(127) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `company_id` (`company_id`)
) ENGINE=MyISAM AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `campaign_maildom`
--

LOCK TABLES `campaign_maildom` WRITE;
/*!40000 ALTER TABLE `campaign_maildom` DISABLE KEYS */;
INSERT INTO `campaign_maildom` VALUES
(38,'2026-10-27 06:18:34',11,'algonetic.ch');
/*!40000 ALTER TABLE `campaign_maildom` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categ_meta`
--

DROP TABLE IF EXISTS `categ_meta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `categ_meta` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `cat_id` smallint(5) unsigned NOT NULL,
  `xkey` char(15) DEFAULT NULL,
  `lang` char(3) NOT NULL,
  `xval` char(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unq` (`cat_id`,`xkey`,`lang`)
) ENGINE=MyISAM AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categ_meta`
--

LOCK TABLES `categ_meta` WRITE;
/*!40000 ALTER TABLE `categ_meta` DISABLE KEYS */;
INSERT INTO `categ_meta` VALUES
(6,1,'IT','de','BKSIT'),
(2,10,'IT','de','GKA'),
(8,8,'IT','de','SK IT'),
(4,6,'IT','de','DVI-KAPO-IT'),
(5,9,'IT','de','GR'),
(9,5,'IT','de','DVI-GES-IT'),
(10,2,'IT','de','DFR'),
(11,7,'IT','de','DGS'),
(25,13,'IT','de','DRZN ITS'),
(13,3,'IT','de','BVU'),
(15,4,'IT','de','DVI-AWA-IT'),
(24,12,'IT','de','ZWLF ITS'),
(23,11,'IT','de','tbd'),
(28,14,'BluBlu','de','tbd'),
(29,16,'daily_offer','sys','1');
/*!40000 ALTER TABLE `categ_meta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` smallint(5) unsigned NOT NULL,
  `parent_id` smallint(5) unsigned NOT NULL,
  `ref` char(63) NOT NULL,
  `visible` tinyint(1) NOT NULL DEFAULT 1,
  `weight` smallint(6) NOT NULL DEFAULT 5,
  `lang` char(3) NOT NULL,
  `label` char(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `extra_label` char(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  UNIQUE KEY `pkey` (`id`,`lang`),
  KEY `wref` (`ref`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES
(1,0,'BKS',1,5,'de','Département Bildung, Kültur u. Sport XL','extra asdf'),
(16,0,'',0,2,'de','Daily Offer',''),
(16,0,'',1,5,'en','Daily Offer',NULL),
(16,0,'',1,5,'fr','Daily Offer',NULL),
(6,0,'DVIKAPO',1,5,'de','Dept DVI KAPO','Kantonspolizeieiei'),
(8,0,'SK',1,5,'de','Staatskanzlei',''),
(9,0,'GR',1,5,'de','Staatskanzlei / Grossrat (asdf xy)',''),
(10,0,'GKA',1,5,'de','Gerichte KTAG HAUPT','Gerchit xtra'),
(13,0,'DRZN',1,95,'de','Dreizehn',''),
(14,1,'',1,5,'de','Subkultur',''),
(15,14,'',1,5,'de','Sub-Subkultur','');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `companies`
--

DROP TABLE IF EXISTS `companies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `companies` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `status` tinyint(4) NOT NULL DEFAULT 1 COMMENT '1=new, 2=released, 3=blocked',
  `tstamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `name` varchar(255) NOT NULL,
  `zip` char(31) DEFAULT NULL,
  `city` char(63) DEFAULT NULL,
  `discount` double NOT NULL DEFAULT 0,
  `email` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `companies`
--

LOCK TABLES `companies` WRITE;
/*!40000 ALTER TABLE `companies` DISABLE KEYS */;
INSERT INTO `companies` VALUES
(1,1,'2026-08-26 11:56:08','ACME GmbH und Co.','8044','Zürich',10.5,''),
(2,1,'2011-05-06 14:16:22','Swiss Remarketing AG',NULL,NULL,30,''),
(3,1,'2012-02-15 14:43:00','Test GmbH & Co.',NULL,NULL,0,''),
(4,1,'2011-07-28 07:43:39','Foobar AG',NULL,NULL,10,''),
(11,1,'2026-04-06 06:28:02','Neué Firmä AG','','',0,'');
/*!40000 ALTER TABLE `companies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `config`
--

DROP TABLE IF EXISTS `config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `config` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT COMMENT 'READONLY:=readonly || STYLE := background-color:#f0f0f0',
  `tstamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp() COMMENT 'READONLY:=readonly || STYLE := background-color:#f0f0f0',
  `key` char(63) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL COMMENT 'READONLY:=readwrite || STYLE := background-color:#f0f0f0; font-weight:bold',
  `val` char(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT 'STYLE := background-color:lightyellow; font-weight:bold; letter-spacing:1px',
  PRIMARY KEY (`id`),
  UNIQUE KEY `key` (`key`)
) ENGINE=MyISAM AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='REM:=Konfiguration || EXT_TOP:=_foo.html || EXT_BOTTOx:=asdf';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `config`
--

LOCK TABLES `config` WRITE;
/*!40000 ALTER TABLE `config` DISABLE KEYS */;
INSERT INTO `config` VALUES
(1,'2026-02-09 22:15:12','DOCUMENT_ROOT','/var/www/html'),
(2,'2026-09-23 13:50:53','site_title','Prismado (lokal)'),
(3,'2026-02-12 14:01:58','app_secret','secrex'),
(4,'2026-10-13 11:51:35','HTTP_HOST','localhost'),
(5,'2026-10-03 16:07:07','vat','8.1'),
(6,'2026-10-03 16:07:39','vat_1','8.1'),
(8,'2026-09-28 20:03:47','round5','1'),
(9,'2026-09-29 08:52:13','theme','algonetic'),
(10,'2026-09-29 09:29:26','default_imgsize_mini','50'),
(11,'2026-09-29 13:08:56','default_imgsize_large','1200'),
(12,'2026-09-29 13:08:56','default_imgsize_thmb','450'),
(13,'2026-09-29 09:31:08','default_cookie_lifetime','5h'),
(14,'2026-09-29 09:31:44','default_curr','CHF'),
(15,'2026-10-05 16:17:53','payrexx_successRedirectUrl','http://localhost/order_detail.html'),
(16,'2026-10-05 16:18:53','payrexx_secret','KaJzxM4ZkwIxrCazNZJdR1jS5n1Teb'),
(17,'2026-10-05 16:19:25','payrexx_instance','algonetic'),
(18,'2026-10-05 16:19:52','payrexx_paymentMethods','mastercard,visa,google-pay,klarna'),
(19,'2026-10-06 15:32:55','default_lang','de'),
(20,'2026-10-06 16:15:39','multi_lang','1'),
(21,'2026-10-06 16:15:55','multi_lang_codes','de,fr,en,it'),
(22,'2026-10-07 12:23:04','vat_ch','8.1'),
(23,'2026-10-13 11:34:51','sso_entra_client_id','cecd3e78-45b3-42dc-9388-e79c7dc0a212'),
(24,'2026-10-13 11:35:27','sso_entra_secret','qVg8Q~6dY-L2leTUTIgwGLhUSW43kS_DXFtbBbiB'),
(25,'2026-10-13 11:35:59','sso_entra_tenant_id',''),
(26,'2026-10-14 09:27:11','smtp_bounce_mail','dmarc-reports@eshop.pub'),
(27,'2026-10-14 09:27:47','smtp_pass','uptorria85'),
(28,'2026-10-14 09:28:34','smtp_conn_sec','starttls'),
(29,'2026-10-14 09:29:07','smtp_user','pg-relay@luckywork.net'),
(30,'2026-10-14 09:29:42','smtp_port','587'),
(31,'2026-10-14 09:30:46','mail_relay','con2.luckywork.net'),
(32,'2026-10-14 09:31:09','mail_encoding','8bit'),
(33,'2026-10-14 09:31:47','mail_type','text/html; charset=ISO-8859-1'),
(34,'2026-10-14 09:32:20','mail_order_format_cust','html'),
(35,'2026-10-14 09:33:55','order_email','root.shopd.merchant@algonetic.ch'),
(36,'2026-10-14 09:34:21','order_email_sender','shop-dev.algo@eshop.pub'),
(37,'2026-10-14 09:35:03','order_post_proc','order_post_proc_dhl( order_id=>$order_id )'),
(38,'2026-10-17 14:13:08','paypal_merchant_id','ELPGZH79BNVLU'),
(39,'2026-10-17 14:11:55','paypal_item_name','Test Item Demoshop'),
(40,'2026-10-29 09:24:24','pay_meth_twi','1'),
(41,'2026-10-29 09:24:44','pay_meth_prx','1'),
(42,'2026-10-29 09:25:18','pay_meth_inv','1'),
(43,'2026-10-29 09:25:46','pay_meth_pp','1'),
(45,'2026-11-11 09:33:18','consent_event_push_ready','1');
/*!40000 ALTER TABLE `config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `config_prod_feat`
--

DROP TABLE IF EXISTS `config_prod_feat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `config_prod_feat` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `featkey` char(127) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `lang` char(3) NOT NULL,
  `featname` char(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `weight` smallint(6) NOT NULL DEFAULT 0 COMMENT 'Could contain negative numbers',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_featkey_lang` (`featkey`,`lang`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `config_prod_feat`
--

LOCK TABLES `config_prod_feat` WRITE;
/*!40000 ALTER TABLE `config_prod_feat` DISABLE KEYS */;
INSERT INTO `config_prod_feat` VALUES
(1,'2fa_enabled','sys','1',0),
(2,'API_KEY_ChatGPT','sys','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',0),
(3,'apply_vat_ch','sys','0',0),
(4,'E310151-1','de','Pflichtauswahl fehlt: {{WHAT}}',0),
(7,'unicode_cart_128722','sys','🛒',0),
(8,'fw_chat_id_1','sys','d3274177-e2e0-4845-bef0-99a300fa55ad',0),
(9,'prozone_507141_1_iv','sys','0',0),
(10,'job_path_new21','sys','new21',0),
(11,'job_detail_10__is_active','sys','0',0),
(12,'job_detail_10__runs_every','sys','30',0),
(13,'job_detail_10_quiet','sys','0',0),
(14,'job_detail_10__description','sys','tbd',0);
/*!40000 ALTER TABLE `config_prod_feat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `help`
--

DROP TABLE IF EXISTS `help`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `help` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `area` tinyint(3) unsigned NOT NULL,
  `sub_area` tinyint(3) unsigned NOT NULL DEFAULT 1,
  `mnemonic` char(31) NOT NULL,
  `audience` char(15) NOT NULL DEFAULT 'adm' COMMENT 'adm or dev',
  `title_en` varchar(255) NOT NULL,
  `title_de` varchar(255) NOT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp(),
  `xval_en` varchar(2047) NOT NULL,
  `xval_de` varchar(2047) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `areas` (`area`,`sub_area`),
  UNIQUE KEY `mnemonic` (`mnemonic`),
  FULLTEXT KEY `title_en` (`title_en`),
  FULLTEXT KEY `title_de` (`title_de`),
  FULLTEXT KEY `xval_de` (`xval_de`),
  FULLTEXT KEY `xval_en` (`xval_en`)
) ENGINE=MyISAM AUTO_INCREMENT=80 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `help`
--

LOCK TABLES `help` WRITE;
/*!40000 ALTER TABLE `help` DISABLE KEYS */;
INSERT INTO `help` VALUES
(1,4,1,'cancel_order','adm','Bestellung stornieren','Bestellung stornieren','2024-07-13 10:59:41','2024-07-14 12:18:04','','Stornierung von Bestellungen<!-- offene/pendente/storno -->'),
(2,7,3,'copy_product','adm','Produkt kopieren','Produkt kopieren','2024-07-13 10:59:41','2024-07-13 17:00:09','','Bestehendes Produkt kopieren'),
(3,4,2,'order','adm','','Bestellung','2024-07-13 13:03:57','2024-07-19 13:18:04','','Informationen zu Bestellungen<!-- mail -->'),
(4,4,3,'delivery_note','adm','','Lieferschein','2024-07-13 13:03:57','2024-10-04 15:00:10','','Erstellen und Bearbeiten von ...<!-- EDI,PDF -->'),
(5,4,5,'order_hist','adm','','History / Verlauf','2024-07-13 13:03:57','2024-07-19 11:09:03','','Ereignisse rund um den Bestellverlauf<!-- Status -->'),
(6,4,4,'send_remind_pend_order','adm','','Erinnerung bei offener Bestellung','2024-07-13 13:03:57','2024-07-13 17:09:03','','Automatische E-Mail nach tbd Std./Min.'),
(7,1,1,'user_general','adm','','Allgemein','2024-07-13 13:03:57','2024-10-26 13:09:04','','Benutzer anlegen und generelle Informationen, Berechtigungen'),
(8,1,2,'user_history','adm','','Aktivit&auml;tsverlauf','2024-07-13 13:03:57','2024-07-13 17:00:09','','User History'),
(9,7,1,'create_product','adm','','Produkt erstellen','2024-07-13 13:03:57','2024-10-15 08:45:03','','Neues Produkt<!-- Artikelnummer,Grade,Grading -->'),
(10,7,5,'prod_discount','adm','','Rabatt','2024-07-13 13:03:57','2024-11-28 09:00:25','','Produkt mit Rabatt reduzieren: Prozent oder Betrag<!-- Geplante Rabatte -->'),
(11,7,2,'gtin','adm','','GTIN','2024-07-13 13:03:57','2024-07-13 16:45:02','','8, oder 12 bis 14-stellige Zahl'),
(12,7,4,'product_manage','adm','','Artikelbearbeitung','2024-07-13 13:03:57','2024-09-27 15:36:07','','Erstellen und Bearbeiten von Artikeln<!-- Exclude,Optionen -->'),
(13,9,1,'err_407131_6','adm','','Fehler / Hinweise','2024-07-13 13:03:57','2024-07-13 17:09:03','','Fehlerbehandlung und Hinweise'),
(15,9,4,'tbd_407131_13','adm','','Fehler Tbd 2','2024-07-13 13:11:35','2024-07-13 13:18:21','','Eine Fehlerbehandlung'),
(16,10,1,'tbd_407141_6','adm','','Online-Hilfe und System-Dokumentation','2024-07-14 10:00:07','2024-10-10 11:45:03','','F&uuml;r Entwickler<!-- Upload -->'),
(17,10,4,'tbd_407141_14','adm','','Online-Hilfe 2','2024-07-14 10:00:07','0000-00-00 00:00:00','','...'),
(18,10,2,'sub_routines','adm','','System-Dokumentation: Sub-Routinen','2024-07-14 14:45:04','0000-00-00 00:00:00','','...'),
(22,4,6,'edi_order','adm','','EDI-Bestellung (Galaxus)','2024-07-16 10:00:05','0000-00-00 00:00:00','','Bestellungen via EDI-Schnittstelle'),
(23,11,1,'prism_core','dev','','Core','2024-07-16 10:00:05','2024-07-23 12:00:08','','Prismado Core Functions<!-- get_webenv,mail_x -->'),
(24,11,2,'web_components','dev','','Web Components','2024-07-16 10:00:05','2024-09-12 10:09:05','','DataTables etc.<!-- Modal,orders,Prismado Dialog -->'),
(25,12,1,'dhl','adm','','DHL-Schnittstelle','2024-07-16 13:27:02','2024-10-16 11:45:03','','...'),
(26,12,4,'newsletter','dev','','Newsletter','2024-07-16 13:27:02','2024-10-06 11:27:03','','Einstellungen<!-- E-Mail,email,Newsletter -->'),
(27,11,3,'sys_jobs','dev','','System Jobs','2024-07-19 10:00:06','2024-08-21 08:36:05','','Periodische automatische Verarbeitungen<!-- EDI,hourly_tasks -->'),
(28,11,4,'prism_shop_core','dev','','Shop','2024-07-19 13:09:03','2024-08-27 12:18:05','','Prismado Core Functions<!-- add_item,env,is_primary -->'),
(29,1,3,'forgot_login','dev','','Login / Passwort vergessen','2024-07-20 10:00:06','0000-00-00 00:00:00','','...<!-- forgot,login,password -->'),
(30,13,1,'main_data','adm','','Stammdaten','2024-07-20 10:00:06','2024-09-13 08:00:26','','Masterdaten, Stammdaten, Logo<!-- ChatGPT,KI,Properties,Safe properties -->'),
(31,13,4,'mail_templates','dev','','E-Mail Templates','2024-07-20 10:00:06','2024-08-13 09:36:04','','E-Mail-Templates, Vorlagen'),
(32,14,1,'tbd_407221_7','adm','','Pro-Zone','2024-07-22 09:00:07','0000-00-00 00:00:00','','Zusammenfassung zur Funktion Mitarbeiter-Shop<!-- prozone -->'),
(33,14,2,'tbd_407221_17','dev','','Pro-Zone (2)','2024-07-22 09:00:07','0000-00-00 00:00:00','','Devel<!-- prozone -->'),
(34,11,5,'web_redir','dev','','Redirects','2024-07-22 09:00:07','0000-00-00 00:00:00','','...<!-- Redirects,Redirs -->'),
(35,1,4,'tbd','dev','','send_register_invitation','2024-07-22 13:09:03','0000-00-00 00:00:00','','...<!-- send_register_invitation -->'),
(36,15,1,'docker_setup','dev','','Setup','2024-07-23 15:27:02','2024-07-24 08:00:06','','Docker Container Setup'),
(37,15,4,'tbx_407232_15','dev','','Tbd 2','2024-07-24 08:00:06','0000-00-00 00:00:00','','...'),
(38,11,6,'session','dev','','Sessions','2024-07-26 11:45:03','0000-00-00 00:00:00','','...<!-- sessions -->'),
(39,7,6,'delete_product','dev','','Produkt l&ouml;schen','2024-07-28 15:54:04','0000-00-00 00:00:00','','...'),
(40,7,7,'product_hist','dev','','History / Verlauf','2024-07-30 08:00:07','0000-00-00 00:00:00','','...<!-- History -->'),
(41,13,5,'art_properties','adm','','Artikeleigenschaften','2024-08-16 09:54:04','2024-09-15 14:00:08','','Standard-Label der Artikeleigenschaften<!-- Stammdaten,Vorauswahl -->'),
(42,11,7,'product_dev','dev','','Produkt','2024-09-01 12:36:06','2024-12-04 09:00:14','','Artikel<!-- Alarmierung,Alert,Aufmerksamkeit,Benachrichtigung,Produkt,Spezialfall,Upload -->'),
(43,11,8,'action','dev','','Actions','2024-09-02 08:00:27','0000-00-00 00:00:00','','...<!-- actions -->'),
(44,11,9,'wysiwyg_edit','dev','','Wysiwyg Editor','2024-09-09 11:54:04','0000-00-00 00:00:00','','<!-- Editor,Wysiwyg -->'),
(45,3,1,'payment_overview','adm','','Payment','2024-09-10 09:45:03','0000-00-00 00:00:00','','&Uuml;bersicht<!-- Payment,Payrexx -->'),
(46,3,2,'voucher','dev','','Gutschein-Code (Voucher)','2024-09-10 09:45:04','2024-09-23 08:00:12','','...<!-- Gutschein,Voucher -->'),
(47,11,10,'ui_components','dev','','UI Components','2024-09-12 11:54:04','2024-09-12 12:00:10','','Forms, Input<!-- Dropdown -->'),
(48,16,1,'ai_overview','dev','','&Uuml;bersicht','2024-09-13 14:00:09','2024-09-13 14:09:03','','tbd<!-- AI,KI -->'),
(49,16,2,'tbx_409131_15','dev','','Tbd 2','2024-09-13 14:00:09','0000-00-00 00:00:00','','...'),
(50,11,11,'post_proc','dev','','Post-processing','2024-09-17 10:09:05','0000-00-00 00:00:00','','...<!-- tbd -->'),
(51,7,8,'edi_product_export','adm','','EDI Produkte-Export','2024-09-20 08:00:17','2024-10-13 08:00:07','','EDI Produkte-Export<!-- Restock Date -->'),
(52,17,1,'design_overview','adm','','&Uuml;bersicht','2024-09-22 09:45:03','2024-12-29 09:00:03','','Inhalt<!-- Design,Font,Layout,Schriftarten,Symbole,Unicode,Upload -->'),
(53,17,2,'design_basket','dev','','Warenkorb','2024-09-22 09:45:03','2024-09-22 12:52:04','','Warenkorb<!-- Basket -->'),
(54,3,3,'vat','adm','','Mehrwertsteuer (VAT / Tax)','2024-09-23 14:36:06','0000-00-00 00:00:00','','...<!-- Mehrwertsteuer,TAX,VAT -->'),
(55,17,3,'teaser','adm','','Teaser','2024-09-25 08:45:03','2024-11-26 09:00:17','','Inhalte<!-- Banner,Content,Teaser -->'),
(56,17,4,'seo','adm','','SEO - Keywords','2024-10-03 13:22:05','2024-10-03 13:36:08','','Einstellungen<!-- Google,Keywords,SEO -->'),
(57,4,7,'paypal','adm','','PayPal','2024-10-04 11:36:07','0000-00-00 00:00:00','','Bestellung<!-- PayPal -->'),
(58,4,8,'invoice','adm','','PDF QR-Rechnung','2024-10-04 15:09:04','0000-00-00 00:00:00','','PDF-Rechnung<!-- QR -->'),
(59,17,5,'product_presentation','adm','','Produkte-Pr&auml;sentation','2024-10-13 08:36:05','0000-00-00 00:00:00','','Inhalte<!-- Darstellung,Design,Produkt -->'),
(60,7,9,'edi_product_refurbished','adm','','EDI Produkte Refurbished','2024-10-13 13:46:04','2025-04-02 10:27:02','','Refurbished<!-- EDI, Restock Date -->'),
(61,7,10,'daily_offer','adm','','Tagesangebot / Daily Offer','2024-10-15 08:00:07','0000-00-00 00:00:00','','...<!-- Daily Offer,Tagesangebot -->'),
(62,12,2,'ads','adm','','Google Ads / SEO / SEA','2024-10-16 11:45:03','0000-00-00 00:00:00','','Google'),
(63,4,9,'returns','adm','','Retouren','2024-10-22 08:00:14','0000-00-00 00:00:00','','RMA / Retouren / Sales Returns'),
(64,11,12,'failover','dev','','Failover','2024-10-22 09:18:05','0000-00-00 00:00:00','','Backup<!-- Failover -->'),
(65,12,5,'rating','adm','','Rating','2024-10-23 08:00:07','0000-00-00 00:00:00','','..<!-- Rating -->'),
(66,7,11,'category','adm','','Kategorien','2024-10-26 12:08:10','2024-10-26 13:30:07','','Kategorien<!-- Category,Service-Portal -->'),
(67,11,13,'mail_reports','dev','','E-Mail-Reports','2024-11-02 09:18:04','0000-00-00 00:00:00','','Daily Reports<!-- Alerts -->'),
(68,11,14,'performance','dev','','Performance','2024-11-03 09:09:04','0000-00-00 00:00:00','','Leistungsoptimierung<!-- Performance -->'),
(69,11,15,'theme','dev','','Theme / Webseiten-Template','2024-11-03 09:45:05','2024-11-03 12:27:03','','Infos<!-- Performance,LazyLoad,Theme -->'),
(70,12,6,'cmp','dev','','Consent Mode v2','2024-11-06 09:00:21','0000-00-00 00:00:00','','Cookie-Einwilligung<!-- Einwilligung,CMP,Consent Mode -->'),
(71,11,16,'modal','dev','','Modal','2024-11-17 17:00:08','0000-00-00 00:00:00','','Modal'),
(72,11,17,'css','dev','','CSS','2024-11-19 12:27:03','0000-00-00 00:00:00','','Theme / CSS'),
(73,17,6,'dark_mode','adm','','Dark Mode','2024-11-25 13:20:03','0000-00-00 00:00:00','','Dark Mode'),
(74,4,10,'sales_report','adm','','Verkaufs-Statistiken','2024-11-26 13:34:16','2024-11-26 13:44:14','','Verkaufs-Statistiken, Umsatz'),
(75,12,7,'edi_config','dev','','EDI-Konfiguration','2025-01-16 10:00:03','0000-00-00 00:00:00','','EDI-Konfiguration'),
(76,13,6,'notifications','adm','','Benachrichtigungen','2025-01-25 13:05:03','0000-00-00 00:00:00','','E-Mail-Benachrichtigungen, Notifications'),
(77,11,18,'cleanup','dev','','Cleanup','2025-01-25 13:54:02','0000-00-00 00:00:00','','tbd<!-- Performance,LazyLoad,Theme -->'),
(78,4,11,'edi_order_process','adm','','EDI-Bestellung, Admin-Bearbeitung','2025-03-18 09:45:02','0000-00-00 00:00:00','','Bestellungen via EDI-Schnittstelle'),
(79,11,19,'prism_multilang','dev','','Core','2026-04-02 09:27:02','0000-00-00 00:00:00','','Prismado Multilingualit&auuml;t<!-- lang,multilang -->');
/*!40000 ALTER TABLE `help` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log`
--

DROP TABLE IF EXISTS `log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `source` char(31) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL COMMENT 'Default: $ENV{REMOTE_ADDR}',
  `importance` smallint(6) NOT NULL DEFAULT 2 COMMENT '1 = highest',
  `sid` int(10) unsigned NOT NULL COMMENT 'Default: 0',
  `uid` mediumint(9) NOT NULL COMMENT 'Default: $self->getUID()',
  `module` varchar(255) CHARACTER SET latin1 COLLATE latin1_german1_ci NOT NULL COMMENT 'Default: $args{''module''}',
  `service` char(63) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL COMMENT 'Default: log',
  `action` varchar(511) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `tstamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `rc` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2950 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log`
--

LOCK TABLES `log` WRITE;
/*!40000 ALTER TABLE `log` DISABLE KEYS */;
/*!40000 ALTER TABLE `log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `options`
--

DROP TABLE IF EXISTS `options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `options` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `style` smallint(6) unsigned NOT NULL DEFAULT 1 COMMENT '1=dropdown, 2=checkbox, 3=dropdown_no_count_no_price',
  `mandatory` tinyint(1) DEFAULT NULL,
  `instime` timestamp NOT NULL DEFAULT current_timestamp(),
  `weight` smallint(6) DEFAULT 0,
  `inc_art_no` smallint(6) DEFAULT NULL COMMENT 'Includes article number',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='One option per row. No prices on this level! Upd: 16.04.2013';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `options`
--

LOCK TABLES `options` WRITE;
/*!40000 ALTER TABLE `options` DISABLE KEYS */;
INSERT INTO `options` VALUES
(1,3,1,'2026-10-04 08:40:17',1,0),
(2,3,0,'2026-10-04 09:40:47',1,0);
/*!40000 ALTER TABLE `options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `options_desc`
--

DROP TABLE IF EXISTS `options_desc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `options_desc` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `option_id` smallint(5) unsigned NOT NULL COMMENT 'foreign key',
  `instime` timestamp NOT NULL DEFAULT current_timestamp(),
  `lang` char(3) NOT NULL DEFAULT 'de',
  `label` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '22Jan2026 zu utf8mb4',
  PRIMARY KEY (`id`),
  UNIQUE KEY `fkey` (`option_id`,`lang`),
  KEY `option_id` (`option_id`),
  KEY `lang` (`lang`)
) ENGINE=MyISAM AUTO_INCREMENT=544 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `options_desc`
--

LOCK TABLES `options_desc` WRITE;
/*!40000 ALTER TABLE `options_desc` DISABLE KEYS */;
INSERT INTO `options_desc` VALUES
(538,1,'2026-10-04 08:40:17','de','Optiox Einx'),
(539,1,'2026-10-04 08:40:17','fr','* New (fr) *'),
(540,1,'2026-10-04 08:40:17','en','* New (en) *'),
(541,2,'2026-10-04 09:40:47','de','Zweitmöglichkeit'),
(542,2,'2026-10-04 09:40:47','fr','* New (fr) *'),
(543,2,'2026-10-04 09:40:47','en','* New (en) *');
/*!40000 ALTER TABLE `options_desc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `options_details`
--

DROP TABLE IF EXISTS `options_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `options_details` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `instime` timestamp NOT NULL DEFAULT current_timestamp(),
  `ref` char(31) DEFAULT NULL,
  `amount` double DEFAULT NULL COMMENT 'Excl. VAT',
  `stock` int(11) NOT NULL DEFAULT -1 COMMENT 'Availble items. -1 = unlim',
  PRIMARY KEY (`id`),
  UNIQUE KEY `ref` (`ref`)
) ENGINE=MyISAM AUTO_INCREMENT=776 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Elements of an option group';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `options_details`
--

LOCK TABLES `options_details` WRITE;
/*!40000 ALTER TABLE `options_details` DISABLE KEYS */;
INSERT INTO `options_details` VALUES
(772,'2026-10-04 08:40:17','IDENT-DE-610041-1',4.62534690101758,-1),
(773,'2026-10-04 08:44:05','IDENT-DE-610041-2',9.25069380203515,-1),
(774,'2026-10-04 09:40:47','R61004-1',18.50138760407031,-1),
(775,'2026-10-04 09:40:57','R61004-2',37.00277520814061,-1);
/*!40000 ALTER TABLE `options_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `options_feat`
--

DROP TABLE IF EXISTS `options_feat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `options_feat` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `option_id` mediumint(8) unsigned NOT NULL COMMENT 'foreign key',
  `instime` timestamp NOT NULL DEFAULT current_timestamp(),
  `lang` char(3) NOT NULL DEFAULT 'de',
  `details_id` mediumint(8) unsigned NOT NULL DEFAULT 0 COMMENT 'Refers to options_details',
  `description` varchar(511) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '02Apr2024: zu utf8mb4',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unq` (`option_id`,`lang`,`details_id`),
  KEY `option_id` (`option_id`),
  KEY `details_id` (`details_id`),
  KEY `lang` (`lang`)
) ENGINE=MyISAM AUTO_INCREMENT=2496 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `options_feat`
--

LOCK TABLES `options_feat` WRITE;
/*!40000 ALTER TABLE `options_feat` DISABLE KEYS */;
INSERT INTO `options_feat` VALUES
(2485,1,'2026-10-04 08:40:17','de',772,'Ausw. plus Fünf'),
(2486,1,'2026-10-04 08:40:17','fr',772,'Auswahl 610041'),
(2487,1,'2026-10-04 08:40:17','en',772,'Auswahl 610041'),
(2488,1,'2026-10-04 08:44:05','de',773,'Ausw. plus Zehn'),
(2489,2,'2026-10-04 09:40:47','de',774,'AAAAAAAA'),
(2490,2,'2026-10-04 09:40:47','fr',774,'AAAAAAAA'),
(2491,2,'2026-10-04 09:40:47','en',774,'AAAAAAAA'),
(2492,2,'2026-10-04 09:40:57','de',775,'BBBBBBBBBBB'),
(2493,2,'2026-10-04 09:40:57','fr',775,'New-20261004-114057'),
(2494,2,'2026-10-04 09:40:57','en',775,'New-20261004-114057'),
(2495,2,'2026-10-04 10:09:12','de',1217,'New Selection 20261004-120912');
/*!40000 ALTER TABLE `options_feat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `sid` mediumint(8) unsigned NOT NULL COMMENT 'Session ID',
  `uid` mediumint(8) unsigned NOT NULL,
  `pay_meth` tinyint(4) NOT NULL COMMENT '1=cc, 2=cod, 3=bill, 4=paypal, 5=postcard, 6=prepaym',
  `instime` timestamp NOT NULL DEFAULT current_timestamp(),
  `vat_rate` double NOT NULL,
  `amount_incl_vat` double NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1 COMMENT '1=new, 2=pending_cc, 3=cancelled, 4=okay',
  `remarks` varchar(2047) DEFAULT NULL COMMENT 'Ship / order remarks',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='REM:=remarks || EXT_TOP:=order_top.html || EXT_BOTTOM:=tbd_2';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES
(1,78,1,4,'2026-10-05 14:32:36',8.1,1575,1,'XX pay_meth 4'),
(3,78,1,4,'2026-10-05 15:07:00',8.1,1575,1,'XX pay_meth 4'),
(6,78,1,4,'2026-10-05 15:08:48',8.1,1575,1,'XX pay_meth 4'),
(7,2086,1,16,'2026-10-05 15:43:22',8.1,725,4,'XX pay_meth 16'),
(8,78,1,16,'2026-10-05 16:35:49',8.1,397.3,1,'XX pay_meth 16'),
(9,107,7,16,'2026-10-07 15:04:49',8.1,97.3,1,'XX pay_meth 16'),
(10,108,8,16,'2026-10-07 15:26:05',8.1,863.15,1,'XX pay_meth 16'),
(11,111,11,16,'2026-10-07 19:02:34',8.1,107.55,1,'XX pay_meth 16'),
(12,78,1,16,'2026-10-14 11:04:33',8.1,450,4,'XX pay_meth 16'),
(14,2086,1,16,'2026-10-14 11:55:56',8.1,1005,4,'XX pay_meth 16'),
(16,78,1,4,'2026-10-17 15:05:08',8.1,755.6,3,'XX pay_meth 16'),
(18,78,1,16,'2026-10-26 08:02:39',8.1,1782.55,4,'XX pay_meth 16'),
(19,140,18,16,'2026-10-26 10:10:59',8.1,270,1,'XX pay_meth 16'),
(20,141,13,16,'2026-10-26 11:21:30',8.1,598.3,1,'XX pay_meth 16'),
(21,143,19,16,'2026-10-26 14:14:36',8.1,364.75,1,'XX pay_meth 16');
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders_details`
--

DROP TABLE IF EXISTS `orders_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders_details` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` mediumint(8) unsigned NOT NULL COMMENT 'foreign key',
  `xkey` char(31) NOT NULL,
  `xval` varchar(2047) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '18Jan2026 zu utf8mb4',
  `dept_id` smallint(5) unsigned GENERATED ALWAYS AS (case when `xkey` like 'dept\\_%\\_%' then cast(substring_index(`xval`,'-',1) as unsigned) else NULL end) STORED,
  PRIMARY KEY (`id`),
  UNIQUE KEY `okey` (`order_id`,`xkey`),
  KEY `order_id` (`order_id`,`xval`(15))
) ENGINE=InnoDB AUTO_INCREMENT=9617 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders_details`
--

LOCK TABLES `orders_details` WRITE;
/*!40000 ALTER TABLE `orders_details` DISABLE KEYS */;
INSERT INTO `orders_details` VALUES
(1,1,'ship_free_as_of','',NULL),
(2,1,'usr_user_agent_short','Moz/5.0 Win NT 10.0; Win64; x64; rv:157.0 Gecko/20100101 Firefox/157.0',NULL),
(3,1,'usr_user_agent','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:157.0) Gecko/20100101 Firefox/157.0',NULL),
(4,1,'weight','1.5',NULL),
(5,1,'pay_cost','0.00',NULL),
(6,1,'discount_amount','0.00',NULL),
(7,1,'basket_total','1622.6',NULL),
(8,1,'basket_total_net','1622.6',NULL),
(9,1,'_version','0.8003',NULL),
(10,1,'discount_perc','',NULL),
(11,1,'prod_id_7_price_incl_vat','700.00',NULL),
(12,1,'prd_id_7_bask_ins','2026-10-05 09:13:01',NULL),
(13,1,'feat_prod_id_7_1_1','IDENT-DE-610041-2',NULL),
(14,1,'feat_prod_id_7_654_1','refxy',NULL),
(15,1,'feat_prod_id_7_2_1','R61004-2',NULL),
(16,1,'prod_id_6_price_incl_vat','300.00',NULL),
(17,1,'prd_id_6_bask_ins','2026-10-05 09:16:21',NULL),
(20,1,'feat_prod_id_7_654_3','refxy',NULL),
(21,1,'checkout_zahlungsart_select','pp',NULL),
(22,1,'ref','',NULL),
(23,1,'remarks','adsf eeeeee yyyyyyyyyyy',NULL),
(24,1,'delivery_date','05.10.2026',NULL),
(25,1,'campaign_count','',NULL),
(26,1,'XX total_incl_vat','1737.25',NULL),
(27,1,'vat_amount','114.64',NULL),
(28,1,'XX shipping','',NULL),
(29,1,'voucher_value','161.887141535615',NULL),
(30,1,'voucher_count_available','',NULL),
(31,1,'voucher_count_used','',NULL),
(32,1,'voucher_id','2',NULL),
(33,1,'ship_meth','std',NULL),
(34,1,'ship_meth_amount','0.00',NULL),
(35,1,'currency','CHF',NULL),
(37,1,'prod_id_123_654','refxy',NULL),
(39,1,'prod_id_7_654','refxy',NULL),
(40,1,'prod_id_2_price_incl_vat','364.75',NULL),
(41,1,'stock_1','9999',NULL),
(42,1,'stock_3','9999',NULL),
(43,1,'stock_2','9999',NULL),
(87,3,'ship_free_as_of','',NULL),
(88,3,'usr_user_agent_short','Moz/5.0 Win NT 10.0; Win64; x64; rv:157.0 Gecko/20100101 Firefox/157.0',NULL),
(89,3,'usr_user_agent','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:157.0) Gecko/20100101 Firefox/157.0',NULL),
(90,3,'weight','1.5',NULL),
(91,3,'pay_cost','0.00',NULL),
(92,3,'discount_amount','0.00',NULL),
(93,3,'basket_total','1622.6',NULL),
(94,3,'basket_total_net','1622.6',NULL),
(95,3,'_version','0.8003',NULL),
(96,3,'discount_perc','',NULL),
(97,3,'prod_id_7_price_incl_vat','700.00',NULL),
(98,3,'prd_id_7_bask_ins','2026-10-05 09:13:01',NULL),
(99,3,'feat_prod_id_7_1_7','IDENT-DE-610041-2',NULL),
(100,3,'feat_prod_id_7_654_7','refxy',NULL),
(101,3,'feat_prod_id_7_2_7','R61004-2',NULL),
(102,3,'prod_id_6_price_incl_vat','300.00',NULL),
(103,3,'prd_id_6_bask_ins','2026-10-05 09:16:21',NULL),
(106,3,'feat_prod_id_7_654_9','refxy',NULL),
(107,3,'checkout_zahlungsart_select','pp',NULL),
(108,3,'ref','',NULL),
(109,3,'remarks','adsf eeeeee yyyyyyyyyyy',NULL),
(110,3,'delivery_date','05.10.2026',NULL),
(111,3,'campaign_count','',NULL),
(112,3,'XX total_incl_vat','1737.25',NULL),
(113,3,'vat_amount','114.64',NULL),
(114,3,'XX shipping','',NULL),
(115,3,'voucher_value','161.887141535615',NULL),
(116,3,'voucher_count_available','',NULL),
(117,3,'voucher_count_used','',NULL),
(118,3,'voucher_id','2',NULL),
(119,3,'ship_meth','std',NULL),
(120,3,'ship_meth_amount','0.00',NULL),
(121,3,'currency','CHF',NULL),
(123,3,'prod_id_123_654','refxy',NULL),
(125,3,'prod_id_7_654','refxy',NULL),
(126,3,'prod_id_2_price_incl_vat','364.75',NULL),
(127,3,'stock_7','9997',NULL),
(128,3,'stock_9','9997',NULL),
(129,3,'stock_8','9997',NULL),
(216,6,'ship_free_as_of','',NULL),
(217,6,'usr_user_agent_short','Moz/5.0 Win NT 10.0; Win64; x64; rv:157.0 Gecko/20100101 Firefox/157.0',NULL),
(218,6,'usr_user_agent','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:157.0) Gecko/20100101 Firefox/157.0',NULL),
(219,6,'weight','1.5',NULL),
(221,6,'discount_amount','0.00',NULL),
(222,6,'basket_total','1622.6',NULL),
(223,6,'basket_total_net','1622.6',NULL),
(224,6,'_version','0.8003',NULL),
(225,6,'discount_perc','',NULL),
(226,6,'prod_id_7_price_incl_vat','700.00',NULL),
(227,6,'prd_id_7_bask_ins','2026-10-05 09:13:01',NULL),
(228,6,'feat_prod_id_7_1_16','IDENT-DE-610041-2',NULL),
(229,6,'feat_prod_id_7_654_16','refxy',NULL),
(230,6,'feat_prod_id_7_2_16','R61004-2',NULL),
(231,6,'prod_id_6_price_incl_vat','300.00',NULL),
(232,6,'prd_id_6_bask_ins','2026-10-05 09:16:21',NULL),
(235,6,'feat_prod_id_7_654_18','refxy',NULL),
(236,6,'checkout_zahlungsart_select','pp',NULL),
(237,6,'ref','',NULL),
(238,6,'remarks','adsf eeeeee yyyyyyyyyyy',NULL),
(239,6,'delivery_date','05.10.2026',NULL),
(240,6,'campaign_count','',NULL),
(242,6,'vat_amount','114.64',NULL),
(244,6,'voucher_value','161.887141535615',NULL),
(245,6,'voucher_count_available','',NULL),
(246,6,'voucher_count_used','',NULL),
(247,6,'voucher_id','2',NULL),
(248,6,'ship_meth','std',NULL),
(250,6,'currency','CHF',NULL),
(252,6,'prod_id_123_654','refxy',NULL),
(254,6,'prod_id_7_654','refxy',NULL),
(255,6,'prod_id_2_price_incl_vat','364.75',NULL),
(256,6,'stock_18','9994',NULL),
(257,6,'stock_16','9994',NULL),
(258,6,'stock_17','9994',NULL),
(271,6,'feat_prod_id_7_1_19','IDENT-DE-610041-2',NULL),
(272,6,'feat_prod_id_7_654_19','refxy',NULL),
(273,6,'feat_prod_id_7_2_19','R61004-2',NULL),
(278,6,'feat_prod_id_7_654_21','refxy',NULL),
(299,6,'stock_20','9993',NULL),
(300,6,'stock_19','9993',NULL),
(301,6,'stock_21','9993',NULL),
(314,6,'feat_prod_id_7_1_22','IDENT-DE-610041-2',NULL),
(315,6,'feat_prod_id_7_654_22','refxy',NULL),
(316,6,'feat_prod_id_7_2_22','R61004-2',NULL),
(321,6,'feat_prod_id_7_654_24','refxy',NULL),
(342,6,'stock_22','9993',NULL),
(343,6,'stock_23','9993',NULL),
(344,6,'stock_24','9993',NULL),
(357,6,'feat_prod_id_7_1_25','IDENT-DE-610041-2',NULL),
(358,6,'feat_prod_id_7_654_25','refxy',NULL),
(359,6,'feat_prod_id_7_2_25','R61004-2',NULL),
(364,6,'feat_prod_id_7_654_27','refxy',NULL),
(385,6,'stock_27','9993',NULL),
(386,6,'stock_26','9993',NULL),
(387,6,'stock_25','9993',NULL),
(400,6,'feat_prod_id_7_1_28','IDENT-DE-610041-2',NULL),
(401,6,'feat_prod_id_7_654_28','refxy',NULL),
(402,6,'feat_prod_id_7_2_28','R61004-2',NULL),
(407,6,'feat_prod_id_7_654_30','refxy',NULL),
(428,6,'stock_29','9993',NULL),
(429,6,'stock_30','9993',NULL),
(430,6,'stock_28','9993',NULL),
(443,6,'feat_prod_id_7_1_31','IDENT-DE-610041-2',NULL),
(444,6,'feat_prod_id_7_654_31','refxy',NULL),
(445,6,'feat_prod_id_7_2_31','R61004-2',NULL),
(450,6,'feat_prod_id_7_654_33','refxy',NULL),
(471,6,'stock_32','9993',NULL),
(472,6,'stock_33','9993',NULL),
(473,6,'stock_31','9993',NULL),
(486,6,'feat_prod_id_7_1_34','IDENT-DE-610041-2',NULL),
(487,6,'feat_prod_id_7_654_34','refxy',NULL),
(488,6,'feat_prod_id_7_2_34','R61004-2',NULL),
(493,6,'feat_prod_id_7_654_36','refxy',NULL),
(514,6,'stock_36','9993',NULL),
(515,6,'stock_34','9993',NULL),
(516,6,'stock_35','9993',NULL),
(529,6,'feat_prod_id_7_1_37','IDENT-DE-610041-2',NULL),
(530,6,'feat_prod_id_7_654_37','refxy',NULL),
(531,6,'feat_prod_id_7_2_37','R61004-2',NULL),
(536,6,'feat_prod_id_7_654_39','refxy',NULL),
(557,6,'stock_39','9993',NULL),
(558,6,'stock_37','9993',NULL),
(559,6,'stock_38','9993',NULL),
(572,6,'feat_prod_id_7_1_40','IDENT-DE-610041-2',NULL),
(573,6,'feat_prod_id_7_654_40','refxy',NULL),
(574,6,'feat_prod_id_7_2_40','R61004-2',NULL),
(579,6,'feat_prod_id_7_654_42','refxy',NULL),
(600,6,'stock_40','9993',NULL),
(601,6,'stock_42','9993',NULL),
(602,6,'stock_41','9993',NULL),
(615,6,'feat_prod_id_7_1_43','IDENT-DE-610041-2',NULL),
(616,6,'feat_prod_id_7_654_43','refxy',NULL),
(617,6,'feat_prod_id_7_2_43','R61004-2',NULL),
(622,6,'feat_prod_id_7_654_45','refxy',NULL),
(643,6,'stock_44','9993',NULL),
(644,6,'stock_45','9993',NULL),
(645,6,'stock_43','9993',NULL),
(658,6,'feat_prod_id_7_1_46','IDENT-DE-610041-2',NULL),
(659,6,'feat_prod_id_7_654_46','refxy',NULL),
(660,6,'feat_prod_id_7_2_46','R61004-2',NULL),
(665,6,'feat_prod_id_7_654_48','refxy',NULL),
(686,6,'stock_47','9993',NULL),
(687,6,'stock_48','9993',NULL),
(688,6,'stock_46','9993',NULL),
(701,6,'feat_prod_id_7_1_49','IDENT-DE-610041-2',NULL),
(702,6,'feat_prod_id_7_654_49','refxy',NULL),
(703,6,'feat_prod_id_7_2_49','R61004-2',NULL),
(708,6,'feat_prod_id_7_654_51','refxy',NULL),
(729,6,'stock_51','9993',NULL),
(730,6,'stock_49','9993',NULL),
(731,6,'stock_50','9993',NULL),
(744,6,'feat_prod_id_7_1_52','IDENT-DE-610041-2',NULL),
(745,6,'feat_prod_id_7_654_52','refxy',NULL),
(746,6,'feat_prod_id_7_2_52','R61004-2',NULL),
(751,6,'feat_prod_id_7_654_54','refxy',NULL),
(772,6,'stock_54','9993',NULL),
(773,6,'stock_53','9993',NULL),
(774,6,'stock_52','9993',NULL),
(787,6,'feat_prod_id_7_1_55','IDENT-DE-610041-2',NULL),
(788,6,'feat_prod_id_7_654_55','refxy',NULL),
(789,6,'feat_prod_id_7_2_55','R61004-2',NULL),
(794,6,'feat_prod_id_7_654_57','refxy',NULL),
(815,6,'stock_55','9993',NULL),
(816,6,'stock_56','9993',NULL),
(817,6,'stock_57','9993',NULL),
(830,6,'feat_prod_id_7_1_58','IDENT-DE-610041-2',NULL),
(831,6,'feat_prod_id_7_654_58','refxy',NULL),
(832,6,'feat_prod_id_7_2_58','R61004-2',NULL),
(837,6,'feat_prod_id_7_654_60','refxy',NULL),
(858,6,'stock_58','9993',NULL),
(859,6,'stock_60','9993',NULL),
(860,6,'stock_59','9993',NULL),
(873,6,'feat_prod_id_7_1_61','IDENT-DE-610041-2',NULL),
(874,6,'feat_prod_id_7_654_61','refxy',NULL),
(875,6,'feat_prod_id_7_2_61','R61004-2',NULL),
(880,6,'feat_prod_id_7_654_63','refxy',NULL),
(901,6,'stock_63','9993',NULL),
(902,6,'stock_61','9993',NULL),
(903,6,'stock_62','9993',NULL),
(916,6,'feat_prod_id_7_1_64','IDENT-DE-610041-2',NULL),
(917,6,'feat_prod_id_7_654_64','refxy',NULL),
(918,6,'feat_prod_id_7_2_64','R61004-2',NULL),
(923,6,'feat_prod_id_7_654_66','refxy',NULL),
(944,6,'stock_66','9993',NULL),
(945,6,'stock_64','9993',NULL),
(946,6,'stock_65','9993',NULL),
(959,6,'feat_prod_id_7_1_67','IDENT-DE-610041-2',NULL),
(960,6,'feat_prod_id_7_654_67','refxy',NULL),
(961,6,'feat_prod_id_7_2_67','R61004-2',NULL),
(966,6,'feat_prod_id_7_654_69','refxy',NULL),
(987,6,'stock_68','9993',NULL),
(988,6,'stock_69','9993',NULL),
(989,6,'stock_67','9993',NULL),
(1002,6,'feat_prod_id_7_1_70','IDENT-DE-610041-2',NULL),
(1003,6,'feat_prod_id_7_654_70','refxy',NULL),
(1004,6,'feat_prod_id_7_2_70','R61004-2',NULL),
(1009,6,'feat_prod_id_7_654_72','refxy',NULL),
(1030,6,'stock_71','9993',NULL),
(1031,6,'stock_70','9993',NULL),
(1032,6,'stock_72','9993',NULL),
(1045,6,'feat_prod_id_7_1_73','IDENT-DE-610041-2',NULL),
(1046,6,'feat_prod_id_7_654_73','refxy',NULL),
(1047,6,'feat_prod_id_7_2_73','R61004-2',NULL),
(1052,6,'feat_prod_id_7_654_75','refxy',NULL),
(1073,6,'stock_73','9993',NULL),
(1074,6,'stock_74','9993',NULL),
(1075,6,'stock_75','9993',NULL),
(1088,6,'feat_prod_id_7_1_76','IDENT-DE-610041-2',NULL),
(1089,6,'feat_prod_id_7_654_76','refxy',NULL),
(1090,6,'feat_prod_id_7_2_76','R61004-2',NULL),
(1095,6,'feat_prod_id_7_654_78','refxy',NULL),
(1116,6,'stock_76','9993',NULL),
(1117,6,'stock_78','9993',NULL),
(1118,6,'stock_77','9993',NULL),
(1131,6,'feat_prod_id_7_1_79','IDENT-DE-610041-2',NULL),
(1132,6,'feat_prod_id_7_654_79','refxy',NULL),
(1133,6,'feat_prod_id_7_2_79','R61004-2',NULL),
(1138,6,'feat_prod_id_7_654_81','refxy',NULL),
(1159,6,'stock_80','9993',NULL),
(1160,6,'stock_79','9993',NULL),
(1161,6,'stock_81','9993',NULL),
(1174,6,'feat_prod_id_7_1_82','IDENT-DE-610041-2',NULL),
(1175,6,'feat_prod_id_7_654_82','refxy',NULL),
(1176,6,'feat_prod_id_7_2_82','R61004-2',NULL),
(1181,6,'feat_prod_id_7_654_84','refxy',NULL),
(1202,6,'stock_82','9993',NULL),
(1203,6,'stock_83','9993',NULL),
(1204,6,'stock_84','9993',NULL),
(1217,6,'feat_prod_id_7_1_85','IDENT-DE-610041-2',NULL),
(1218,6,'feat_prod_id_7_654_85','refxy',NULL),
(1219,6,'feat_prod_id_7_2_85','R61004-2',NULL),
(1224,6,'feat_prod_id_7_654_87','refxy',NULL),
(1245,6,'stock_87','9993',NULL),
(1246,6,'stock_86','9993',NULL),
(1247,6,'stock_85','9993',NULL),
(1260,6,'feat_prod_id_7_1_88','IDENT-DE-610041-2',NULL),
(1261,6,'feat_prod_id_7_654_88','refxy',NULL),
(1262,6,'feat_prod_id_7_2_88','R61004-2',NULL),
(1267,6,'feat_prod_id_7_654_90','refxy',NULL),
(1288,6,'stock_89','9993',NULL),
(1289,6,'stock_90','9993',NULL),
(1290,6,'stock_88','9993',NULL),
(1303,6,'feat_prod_id_7_1_91','IDENT-DE-610041-2',NULL),
(1304,6,'feat_prod_id_7_654_91','refxy',NULL),
(1305,6,'feat_prod_id_7_2_91','R61004-2',NULL),
(1310,6,'feat_prod_id_7_654_93','refxy',NULL),
(1331,6,'stock_92','9993',NULL),
(1332,6,'stock_91','9993',NULL),
(1333,6,'stock_93','9993',NULL),
(1346,6,'feat_prod_id_7_1_94','IDENT-DE-610041-2',NULL),
(1347,6,'feat_prod_id_7_654_94','refxy',NULL),
(1348,6,'feat_prod_id_7_2_94','R61004-2',NULL),
(1353,6,'feat_prod_id_7_654_96','refxy',NULL),
(1374,6,'stock_94','9993',NULL),
(1375,6,'stock_95','9993',NULL),
(1376,6,'stock_96','9993',NULL),
(1389,6,'feat_prod_id_7_1_97','IDENT-DE-610041-2',NULL),
(1390,6,'feat_prod_id_7_654_97','refxy',NULL),
(1391,6,'feat_prod_id_7_2_97','R61004-2',NULL),
(1396,6,'feat_prod_id_7_654_99','refxy',NULL),
(1417,6,'stock_97','9993',NULL),
(1418,6,'stock_99','9993',NULL),
(1419,6,'stock_98','9993',NULL),
(1432,6,'feat_prod_id_7_1_100','IDENT-DE-610041-2',NULL),
(1433,6,'feat_prod_id_7_654_100','refxy',NULL),
(1434,6,'feat_prod_id_7_2_100','R61004-2',NULL),
(1439,6,'feat_prod_id_7_654_102','refxy',NULL),
(1460,6,'stock_102','9993',NULL),
(1461,6,'stock_100','9993',NULL),
(1462,6,'stock_101','9993',NULL),
(1475,6,'feat_prod_id_7_1_103','IDENT-DE-610041-2',NULL),
(1476,6,'feat_prod_id_7_654_103','refxy',NULL),
(1477,6,'feat_prod_id_7_2_103','R61004-2',NULL),
(1482,6,'feat_prod_id_7_654_105','refxy',NULL),
(1503,6,'stock_104','9993',NULL),
(1504,6,'stock_105','9993',NULL),
(1505,6,'stock_103','9993',NULL),
(1518,6,'feat_prod_id_7_1_106','IDENT-DE-610041-2',NULL),
(1519,6,'feat_prod_id_7_654_106','refxy',NULL),
(1520,6,'feat_prod_id_7_2_106','R61004-2',NULL),
(1525,6,'feat_prod_id_7_654_108','refxy',NULL),
(1546,6,'stock_108','9993',NULL),
(1547,6,'stock_106','9993',NULL),
(1548,6,'stock_107','9993',NULL),
(1561,6,'feat_prod_id_7_1_109','IDENT-DE-610041-2',NULL),
(1562,6,'feat_prod_id_7_654_109','refxy',NULL),
(1563,6,'feat_prod_id_7_2_109','R61004-2',NULL),
(1568,6,'feat_prod_id_7_654_111','refxy',NULL),
(1589,6,'stock_110','9993',NULL),
(1590,6,'stock_111','9993',NULL),
(1591,6,'stock_109','9993',NULL),
(1604,6,'feat_prod_id_7_1_112','IDENT-DE-610041-2',NULL),
(1605,6,'feat_prod_id_7_654_112','refxy',NULL),
(1606,6,'feat_prod_id_7_2_112','R61004-2',NULL),
(1611,6,'feat_prod_id_7_654_114','refxy',NULL),
(1632,6,'stock_113','9993',NULL),
(1633,6,'stock_112','9993',NULL),
(1634,6,'stock_114','9993',NULL),
(1647,6,'feat_prod_id_7_1_115','IDENT-DE-610041-2',NULL),
(1648,6,'feat_prod_id_7_654_115','refxy',NULL),
(1649,6,'feat_prod_id_7_2_115','R61004-2',NULL),
(1654,6,'feat_prod_id_7_654_117','refxy',NULL),
(1675,6,'stock_116','9993',NULL),
(1676,6,'stock_117','9993',NULL),
(1677,6,'stock_115','9993',NULL),
(1690,6,'feat_prod_id_7_1_118','IDENT-DE-610041-2',NULL),
(1691,6,'feat_prod_id_7_654_118','refxy',NULL),
(1692,6,'feat_prod_id_7_2_118','R61004-2',NULL),
(1697,6,'feat_prod_id_7_654_120','refxy',NULL),
(1718,6,'stock_119','9993',NULL),
(1719,6,'stock_118','9993',NULL),
(1720,6,'stock_120','9993',NULL),
(1733,6,'feat_prod_id_7_1_121','IDENT-DE-610041-2',NULL),
(1734,6,'feat_prod_id_7_654_121','refxy',NULL),
(1735,6,'feat_prod_id_7_2_121','R61004-2',NULL),
(1740,6,'feat_prod_id_7_654_123','refxy',NULL),
(1761,6,'stock_122','9993',NULL),
(1762,6,'stock_121','9993',NULL),
(1763,6,'stock_123','9993',NULL),
(1776,6,'feat_prod_id_7_1_124','IDENT-DE-610041-2',NULL),
(1777,6,'feat_prod_id_7_654_124','refxy',NULL),
(1778,6,'feat_prod_id_7_2_124','R61004-2',NULL),
(1783,6,'feat_prod_id_7_654_126','refxy',NULL),
(1804,6,'stock_124','9993',NULL),
(1805,6,'stock_125','9993',NULL),
(1806,6,'stock_126','9993',NULL),
(1819,6,'feat_prod_id_7_1_127','IDENT-DE-610041-2',NULL),
(1820,6,'feat_prod_id_7_654_127','refxy',NULL),
(1821,6,'feat_prod_id_7_2_127','R61004-2',NULL),
(1826,6,'feat_prod_id_7_654_129','refxy',NULL),
(1847,6,'stock_128','9993',NULL),
(1848,6,'stock_127','9993',NULL),
(1849,6,'stock_129','9993',NULL),
(1862,6,'feat_prod_id_7_1_130','IDENT-DE-610041-2',NULL),
(1863,6,'feat_prod_id_7_654_130','refxy',NULL),
(1864,6,'feat_prod_id_7_2_130','R61004-2',NULL),
(1869,6,'feat_prod_id_7_654_132','refxy',NULL),
(1890,6,'stock_130','9993',NULL),
(1891,6,'stock_131','9993',NULL),
(1892,6,'stock_132','9993',NULL),
(1905,6,'feat_prod_id_7_1_133','IDENT-DE-610041-2',NULL),
(1906,6,'feat_prod_id_7_654_133','refxy',NULL),
(1907,6,'feat_prod_id_7_2_133','R61004-2',NULL),
(1912,6,'feat_prod_id_7_654_135','refxy',NULL),
(1933,6,'stock_135','9993',NULL),
(1934,6,'stock_133','9993',NULL),
(1935,6,'stock_134','9993',NULL),
(1948,6,'feat_prod_id_7_1_136','IDENT-DE-610041-2',NULL),
(1949,6,'feat_prod_id_7_654_136','refxy',NULL),
(1950,6,'feat_prod_id_7_2_136','R61004-2',NULL),
(1955,6,'feat_prod_id_7_654_138','refxy',NULL),
(1976,6,'stock_136','9993',NULL),
(1977,6,'stock_137','9993',NULL),
(1978,6,'stock_138','9993',NULL),
(1991,6,'feat_prod_id_7_1_139','IDENT-DE-610041-2',NULL),
(1992,6,'feat_prod_id_7_654_139','refxy',NULL),
(1993,6,'feat_prod_id_7_2_139','R61004-2',NULL),
(1998,6,'feat_prod_id_7_654_141','refxy',NULL),
(2019,6,'stock_140','9993',NULL),
(2020,6,'stock_141','9993',NULL),
(2021,6,'stock_139','9993',NULL),
(2034,6,'feat_prod_id_7_1_142','IDENT-DE-610041-2',NULL),
(2035,6,'feat_prod_id_7_654_142','refxy',NULL),
(2036,6,'feat_prod_id_7_2_142','R61004-2',NULL),
(2041,6,'feat_prod_id_7_654_144','refxy',NULL),
(2062,6,'stock_143','9993',NULL),
(2063,6,'stock_142','9993',NULL),
(2064,6,'stock_144','9993',NULL),
(2077,6,'feat_prod_id_7_1_145','IDENT-DE-610041-2',NULL),
(2078,6,'feat_prod_id_7_654_145','refxy',NULL),
(2079,6,'feat_prod_id_7_2_145','R61004-2',NULL),
(2084,6,'feat_prod_id_7_654_147','refxy',NULL),
(2105,6,'stock_146','9993',NULL),
(2106,6,'stock_147','9993',NULL),
(2107,6,'stock_145','9993',NULL),
(2120,6,'feat_prod_id_7_1_148','IDENT-DE-610041-2',NULL),
(2121,6,'feat_prod_id_7_654_148','refxy',NULL),
(2122,6,'feat_prod_id_7_2_148','R61004-2',NULL),
(2127,6,'feat_prod_id_7_654_150','refxy',NULL),
(2148,6,'stock_149','9993',NULL),
(2149,6,'stock_150','9993',NULL),
(2150,6,'stock_148','9993',NULL),
(2163,6,'feat_prod_id_7_1_151','IDENT-DE-610041-2',NULL),
(2164,6,'feat_prod_id_7_654_151','refxy',NULL),
(2165,6,'feat_prod_id_7_2_151','R61004-2',NULL),
(2170,6,'feat_prod_id_7_654_153','refxy',NULL),
(2191,6,'stock_151','9993',NULL),
(2192,6,'stock_153','9993',NULL),
(2193,6,'stock_152','9993',NULL),
(2206,6,'feat_prod_id_7_1_154','IDENT-DE-610041-2',NULL),
(2207,6,'feat_prod_id_7_654_154','refxy',NULL),
(2208,6,'feat_prod_id_7_2_154','R61004-2',NULL),
(2213,6,'feat_prod_id_7_654_156','refxy',NULL),
(2234,6,'stock_156','9993',NULL),
(2235,6,'stock_155','9993',NULL),
(2236,6,'stock_154','9993',NULL),
(2249,6,'feat_prod_id_7_1_157','IDENT-DE-610041-2',NULL),
(2250,6,'feat_prod_id_7_654_157','refxy',NULL),
(2251,6,'feat_prod_id_7_2_157','R61004-2',NULL),
(2256,6,'feat_prod_id_7_654_159','refxy',NULL),
(2277,6,'stock_157','9993',NULL),
(2278,6,'stock_159','9993',NULL),
(2279,6,'stock_158','9993',NULL),
(2280,7,'ship_free_as_of','',NULL),
(2281,7,'usr_user_agent_short','Moz/5.0 Win NT 10.0; Win64; x64 AWK/537.36 KHTML, l-Gck Chrome/154.0.0.0',NULL),
(2282,7,'usr_user_agent','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL),
(2283,7,'weight','1',NULL),
(2285,7,'discount_amount','0.00',NULL),
(2286,7,'basket_total','950.05',NULL),
(2287,7,'basket_total_net','950.05',NULL),
(2288,7,'_version','0.8003',NULL),
(2289,7,'discount_perc','',NULL),
(2290,7,'prod_id_6_price_incl_vat','300.00',NULL),
(2291,7,'prd_id_6_bask_ins','2026-10-03 13:36:18',NULL),
(2292,7,'prod_id_7_price_incl_vat','725.00',NULL),
(2293,7,'prd_id_7_bask_ins','2026-10-05 08:16:53',NULL),
(2294,7,'feat_prod_id_7_1_161','IDENT-DE-610041-1',NULL),
(2295,7,'feat_prod_id_7_2_161','R61004-1',NULL),
(2296,7,'checkout_zahlungsart_select','prx',NULL),
(2297,7,'ref','',NULL),
(2298,7,'remarks','',NULL),
(2299,7,'delivery_date','05.10.2026',NULL),
(2300,7,'campaign_count','',NULL),
(2302,7,'vat_amount','74.93',NULL),
(2304,7,'ship_meth','std',NULL),
(2306,7,'currency','CHF',NULL),
(2309,7,'prod_id_7_1','IDENT-DE-610041-1',NULL),
(2310,7,'prod_id_7_2','R61004-1',NULL),
(2311,7,'stock_160','9993',NULL),
(2312,7,'stock_161','9993',NULL),
(2327,7,'feat_prod_id_7_1_163','IDENT-DE-610041-1',NULL),
(2328,7,'feat_prod_id_7_2_163','R61004-1',NULL),
(2344,7,'stock_163','9992',NULL),
(2345,7,'stock_162','9992',NULL),
(2358,6,'feat_prod_id_7_1_164','IDENT-DE-610041-2',NULL),
(2359,6,'feat_prod_id_7_654_164','refxy',NULL),
(2360,6,'feat_prod_id_7_2_164','R61004-2',NULL),
(2365,6,'feat_prod_id_7_654_166','refxy',NULL),
(2386,6,'stock_165','9992',NULL),
(2387,6,'stock_166','9992',NULL),
(2388,6,'stock_164','9992',NULL),
(2401,6,'feat_prod_id_7_1_167','IDENT-DE-610041-2',NULL),
(2402,6,'feat_prod_id_7_654_167','refxy',NULL),
(2403,6,'feat_prod_id_7_2_167','R61004-2',NULL),
(2408,6,'feat_prod_id_7_654_169','refxy',NULL),
(2429,6,'stock_167','9992',NULL),
(2430,6,'stock_169','9992',NULL),
(2431,6,'stock_168','9992',NULL),
(2444,6,'feat_prod_id_7_1_170','IDENT-DE-610041-2',NULL),
(2445,6,'feat_prod_id_7_654_170','refxy',NULL),
(2446,6,'feat_prod_id_7_2_170','R61004-2',NULL),
(2451,6,'feat_prod_id_7_654_172','refxy',NULL),
(2472,6,'stock_172','9992',NULL),
(2473,6,'stock_170','9992',NULL),
(2474,6,'stock_171','9992',NULL),
(2487,6,'feat_prod_id_7_1_173','IDENT-DE-610041-2',NULL),
(2488,6,'feat_prod_id_7_654_173','refxy',NULL),
(2489,6,'feat_prod_id_7_2_173','R61004-2',NULL),
(2494,6,'feat_prod_id_7_654_175','refxy',NULL),
(2515,6,'stock_174','9992',NULL),
(2516,6,'stock_173','9992',NULL),
(2517,6,'stock_175','9992',NULL),
(2530,6,'feat_prod_id_7_1_176','IDENT-DE-610041-2',NULL),
(2531,6,'feat_prod_id_7_654_176','refxy',NULL),
(2532,6,'feat_prod_id_7_2_176','R61004-2',NULL),
(2537,6,'feat_prod_id_7_654_178','refxy',NULL),
(2558,6,'stock_178','9992',NULL),
(2559,6,'stock_176','9992',NULL),
(2560,6,'stock_177','9992',NULL),
(2573,6,'feat_prod_id_7_1_179','IDENT-DE-610041-2',NULL),
(2574,6,'feat_prod_id_7_654_179','refxy',NULL),
(2575,6,'feat_prod_id_7_2_179','R61004-2',NULL),
(2580,6,'feat_prod_id_7_654_181','refxy',NULL),
(2601,6,'stock_180','9992',NULL),
(2602,6,'stock_181','9992',NULL),
(2603,6,'stock_179','9992',NULL),
(2608,6,'pay_cost','0.00',NULL),
(2616,6,'feat_prod_id_7_1_182','IDENT-DE-610041-2',NULL),
(2617,6,'feat_prod_id_7_654_182','refxy',NULL),
(2618,6,'feat_prod_id_7_2_182','R61004-2',NULL),
(2623,6,'feat_prod_id_7_654_184','refxy',NULL),
(2629,6,'XX total_incl_vat','1737.25',NULL),
(2631,6,'XX shipping','',NULL),
(2637,6,'ship_meth_amount','0.00',NULL),
(2644,6,'stock_183','9992',NULL),
(2645,6,'stock_182','9992',NULL),
(2646,6,'stock_184','9992',NULL),
(2647,8,'ship_free_as_of','',NULL),
(2648,8,'usr_user_agent_short','Moz/5.0 Win NT 10.0; Win64; x64; rv:157.0 Gecko/20100101 Firefox/157.0',NULL),
(2649,8,'usr_user_agent','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:157.0) Gecko/20100101 Firefox/157.0',NULL),
(2650,8,'weight','0.5',NULL),
(2652,8,'discount_amount','0.00',NULL),
(2653,8,'basket_total','647.55',NULL),
(2654,8,'basket_total_net','647.55',NULL),
(2655,8,'_version','0.8003',NULL),
(2656,8,'discount_perc','',NULL),
(2657,8,'prod_id_7_price_incl_vat','700.00',NULL),
(2658,8,'prd_id_7_bask_ins','2026-10-05 18:35:40',NULL),
(2659,8,'feat_prod_id_7_654_185','refxy',NULL),
(2660,8,'checkout_zahlungsart_select','prx',NULL),
(2661,8,'ref','',NULL),
(2662,8,'remarks','adsf eeeeee yyyyyyyyyyy',NULL),
(2663,8,'delivery_date','05.10.2026',NULL),
(2664,8,'campaign_count','',NULL),
(2666,8,'vat_amount','47.21',NULL),
(2668,8,'voucher_value','64.754856614246',NULL),
(2669,8,'voucher_count_available','',NULL),
(2670,8,'voucher_count_used','',NULL),
(2671,8,'voucher_id','2',NULL),
(2672,8,'ship_meth','std',NULL),
(2674,8,'currency','CHF',NULL),
(2675,8,'prod_id_6_price_incl_vat','300.00',NULL),
(2676,8,'prod_id_123_654','refxy',NULL),
(2678,8,'prod_id_7_654','refxy',NULL),
(2679,8,'prod_id_2_price_incl_vat','364.75',NULL),
(2680,8,'stock_185','9992',NULL),
(2693,8,'feat_prod_id_7_654_186','refxy',NULL),
(2714,8,'stock_186','9991',NULL),
(2726,8,'prd_id_2_bask_ins','2026-10-07 11:39:17',NULL),
(2729,8,'feat_prod_id_7_654_188','refxy',NULL),
(2730,8,'feat_prod_id_7_1_188','IDENT-DE-610041-2',NULL),
(2750,8,'prod_id_7_1','IDENT-DE-610041-2',NULL),
(2752,8,'stock_188','9991',NULL),
(2753,8,'stock_187','7777',NULL),
(2768,8,'feat_prod_id_7_654_190','refxy',NULL),
(2769,8,'feat_prod_id_7_1_190','IDENT-DE-610041-2',NULL),
(2791,8,'stock_189','7776',NULL),
(2792,8,'stock_190','9991',NULL),
(2807,8,'feat_prod_id_7_654_192','refxy',NULL),
(2808,8,'feat_prod_id_7_1_192','IDENT-DE-610041-2',NULL),
(2830,8,'stock_192','9991',NULL),
(2831,8,'stock_191','7776',NULL),
(2846,8,'feat_prod_id_7_654_194','refxy',NULL),
(2847,8,'feat_prod_id_7_1_194','IDENT-DE-610041-2',NULL),
(2869,8,'stock_194','9991',NULL),
(2870,8,'stock_193','7776',NULL),
(2885,8,'feat_prod_id_7_654_196','refxy',NULL),
(2886,8,'feat_prod_id_7_1_196','IDENT-DE-610041-2',NULL),
(2908,8,'stock_195','7776',NULL),
(2909,8,'stock_196','9991',NULL),
(2924,8,'feat_prod_id_7_654_198','refxy',NULL),
(2925,8,'feat_prod_id_7_1_198','IDENT-DE-610041-2',NULL),
(2947,8,'stock_197','7776',NULL),
(2948,8,'stock_198','9991',NULL),
(2963,8,'feat_prod_id_7_654_200','refxy',NULL),
(2964,8,'feat_prod_id_7_1_200','IDENT-DE-610041-2',NULL),
(2986,8,'stock_200','9991',NULL),
(2987,8,'stock_199','7776',NULL),
(3002,8,'feat_prod_id_7_654_202','refxy',NULL),
(3003,8,'feat_prod_id_7_1_202','IDENT-DE-610041-2',NULL),
(3025,8,'stock_201','7776',NULL),
(3026,8,'stock_202','9991',NULL),
(3041,8,'feat_prod_id_7_654_204','refxy',NULL),
(3042,8,'feat_prod_id_7_1_204','IDENT-DE-610041-2',NULL),
(3064,8,'stock_204','9991',NULL),
(3065,8,'stock_203','7776',NULL),
(3077,8,'prd_id_6_bask_ins','2026-10-07 14:29:03',NULL),
(3078,8,'prod_id_3_price_incl_vat','97.30',NULL),
(3079,8,'prd_id_3_bask_ins','2026-10-07 14:29:16',NULL),
(3098,8,'stock_205','9992',NULL),
(3099,8,'stock_206','9999',NULL),
(3114,8,'feat_prod_id_7_654_208','refxy',NULL),
(3115,8,'feat_prod_id_7_1_208','IDENT-DE-610041-2',NULL),
(3116,8,'feat_prod_id_7_2_208','R61004-2',NULL),
(3131,8,'prod_id_7_2','R61004-2',NULL),
(3136,8,'stock_207','9991',NULL),
(3137,8,'stock_208','9991',NULL),
(3152,8,'feat_prod_id_7_654_210','refxy',NULL),
(3153,8,'feat_prod_id_7_1_210','IDENT-DE-610041-2',NULL),
(3154,8,'feat_prod_id_7_2_210','R61004-2',NULL),
(3174,8,'stock_210','9991',NULL),
(3175,8,'stock_209','9991',NULL),
(3190,8,'feat_prod_id_7_654_212','refxy',NULL),
(3191,8,'feat_prod_id_7_1_212','IDENT-DE-610041-2',NULL),
(3192,8,'feat_prod_id_7_2_212','R61004-2',NULL),
(3212,8,'stock_211','9991',NULL),
(3213,8,'stock_212','9991',NULL),
(3228,8,'feat_prod_id_7_654_214','refxy',NULL),
(3229,8,'feat_prod_id_7_1_214','IDENT-DE-610041-2',NULL),
(3230,8,'feat_prod_id_7_2_214','R61004-2',NULL),
(3250,8,'stock_213','9991',NULL),
(3251,8,'stock_214','9991',NULL),
(3266,8,'feat_prod_id_7_654_216','refxy',NULL),
(3267,8,'feat_prod_id_7_1_216','IDENT-DE-610041-2',NULL),
(3268,8,'feat_prod_id_7_2_216','R61004-2',NULL),
(3288,8,'stock_215','9991',NULL),
(3289,8,'stock_216','9991',NULL),
(3304,8,'feat_prod_id_7_654_218','refxy',NULL),
(3305,8,'feat_prod_id_7_1_218','IDENT-DE-610041-2',NULL),
(3306,8,'feat_prod_id_7_2_218','R61004-2',NULL),
(3326,8,'stock_217','9991',NULL),
(3327,8,'stock_218','9991',NULL),
(3342,8,'feat_prod_id_7_654_220','refxy',NULL),
(3343,8,'feat_prod_id_7_1_220','IDENT-DE-610041-2',NULL),
(3344,8,'feat_prod_id_7_2_220','R61004-2',NULL),
(3364,8,'stock_219','9991',NULL),
(3365,8,'stock_220','9991',NULL),
(3380,8,'feat_prod_id_7_654_222','refxy',NULL),
(3381,8,'feat_prod_id_7_1_222','IDENT-DE-610041-2',NULL),
(3382,8,'feat_prod_id_7_2_222','R61004-2',NULL),
(3402,8,'stock_222','9991',NULL),
(3403,8,'stock_221','9991',NULL),
(3418,8,'feat_prod_id_7_654_224','refxy',NULL),
(3419,8,'feat_prod_id_7_1_224','IDENT-DE-610041-2',NULL),
(3420,8,'feat_prod_id_7_2_224','R61004-2',NULL),
(3440,8,'stock_223','9991',NULL),
(3441,8,'stock_224','9991',NULL),
(3456,8,'feat_prod_id_7_654_226','refxy',NULL),
(3457,8,'feat_prod_id_7_1_226','IDENT-DE-610041-2',NULL),
(3458,8,'feat_prod_id_7_2_226','R61004-2',NULL),
(3478,8,'stock_226','9991',NULL),
(3479,8,'stock_225','9991',NULL),
(3494,8,'feat_prod_id_7_654_228','refxy',NULL),
(3495,8,'feat_prod_id_7_1_228','IDENT-DE-610041-2',NULL),
(3496,8,'feat_prod_id_7_2_228','R61004-2',NULL),
(3516,8,'stock_228','9991',NULL),
(3517,8,'stock_227','9991',NULL),
(3532,8,'feat_prod_id_7_654_230','refxy',NULL),
(3533,8,'feat_prod_id_7_1_230','IDENT-DE-610041-2',NULL),
(3534,8,'feat_prod_id_7_2_230','R61004-2',NULL),
(3554,8,'stock_229','9991',NULL),
(3555,8,'stock_230','9991',NULL),
(3570,8,'feat_prod_id_7_654_232','refxy',NULL),
(3571,8,'feat_prod_id_7_1_232','IDENT-DE-610041-2',NULL),
(3572,8,'feat_prod_id_7_2_232','R61004-2',NULL),
(3592,8,'stock_232','9991',NULL),
(3593,8,'stock_231','9991',NULL),
(3594,9,'ship_free_as_of','',NULL),
(3595,9,'usr_user_agent_short','Moz/5.0 Win NT 10.0; Win64; x64; rv:157.0 Gecko/20100101 Firefox/157.0',NULL),
(3596,9,'usr_user_agent','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:157.0) Gecko/20100101 Firefox/157.0',NULL),
(3597,9,'weight','0.5',NULL),
(3598,9,'pay_cost','0.00',NULL),
(3599,9,'discount_amount','0.00',NULL),
(3600,9,'basket_total_net','90',NULL),
(3601,9,'_version','0.8003',NULL),
(3602,9,'basket_total','90',NULL),
(3603,9,'discount_perc','',NULL),
(3604,9,'prod_id_3_price_incl_vat','97.30',NULL),
(3605,9,'prd_id_3_bask_ins','2026-10-07 17:04:46',NULL),
(3606,9,'checkout_zahlungsart_select','prx',NULL),
(3607,9,'ref','',NULL),
(3608,9,'remarks','',NULL),
(3609,9,'delivery_date','07.10.2026',NULL),
(3610,9,'campaign_count','',NULL),
(3611,9,'XX total_incl_vat','97.30',NULL),
(3612,9,'vat_amount','7.29',NULL),
(3613,9,'XX shipping','',NULL),
(3614,9,'ship_meth','std',NULL),
(3615,9,'ship_meth_amount','0.00',NULL),
(3616,9,'currency','CHF',NULL),
(3618,9,'stock_233','9998',NULL),
(3619,10,'ship_free_as_of','',NULL),
(3620,10,'usr_user_agent_short','Moz/5.0 Win NT 10.0; Win64; x64; rv:157.0 Gecko/20100101 Firefox/157.0',NULL),
(3621,10,'usr_user_agent','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:157.0) Gecko/20100101 Firefox/157.0',NULL),
(3622,10,'weight','1',NULL),
(3623,10,'pay_cost','0.00',NULL),
(3624,10,'discount_amount','0.00',NULL),
(3625,10,'basket_total_net','798.5',NULL),
(3626,10,'_version','0.8003',NULL),
(3627,10,'basket_total','798.5',NULL),
(3628,10,'discount_perc','',NULL),
(3629,10,'prod_id_4_price_incl_vat','755.60',NULL),
(3630,10,'prd_id_4_bask_ins','2026-10-07 17:25:00',NULL),
(3631,10,'prod_id_1_price_incl_vat','107.55',NULL),
(3632,10,'prd_id_1_bask_ins','2026-10-07 17:25:02',NULL),
(3633,10,'checkout_zahlungsart_select','prx',NULL),
(3634,10,'ref','',NULL),
(3635,10,'remarks','',NULL),
(3636,10,'delivery_date','07.10.2026',NULL),
(3637,10,'campaign_count','',NULL),
(3638,10,'XX total_incl_vat','863.15',NULL),
(3639,10,'vat_amount','64.68',NULL),
(3640,10,'XX shipping','',NULL),
(3641,10,'ship_meth','std',NULL),
(3642,10,'ship_meth_amount','0.00',NULL),
(3643,10,'currency','EUR',NULL),
(3646,10,'stock_235','9999',NULL),
(3647,10,'stock_234','9999',NULL),
(3648,11,'ship_free_as_of','',NULL),
(3649,11,'usr_user_agent_short','Moz/5.0 Win NT 10.0; Win64; x64; rv:157.0 Gecko/20100101 Firefox/157.0',NULL),
(3650,11,'usr_user_agent','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:157.0) Gecko/20100101 Firefox/157.0',NULL),
(3651,11,'weight','0.5',NULL),
(3652,11,'pay_cost','0.00',NULL),
(3653,11,'discount_amount','0.00',NULL),
(3654,11,'basket_total_net','99.5',NULL),
(3655,11,'_version','0.8003',NULL),
(3656,11,'basket_total','99.5',NULL),
(3657,11,'discount_perc','',NULL),
(3658,11,'prod_id_1_price_incl_vat','107.55',NULL),
(3659,11,'prd_id_1_bask_ins','2026-10-07 21:02:06',NULL),
(3660,11,'checkout_zahlungsart_select','prx',NULL),
(3661,11,'ref','',NULL),
(3662,11,'remarks','',NULL),
(3663,11,'delivery_date','07.10.2026',NULL),
(3664,11,'campaign_count','',NULL),
(3665,11,'XX total_incl_vat','107.55',NULL),
(3666,11,'vat_amount','8.06',NULL),
(3667,11,'XX shipping','',NULL),
(3668,11,'ship_meth','std',NULL),
(3669,11,'ship_meth_amount','0.00',NULL),
(3670,11,'currency','CHF',NULL),
(3672,11,'stock_236','9998',NULL),
(3704,8,'stock_237','9991',NULL),
(3709,8,'pay_cost','0.00',NULL),
(3724,8,'XX total_incl_vat','397.25',NULL),
(3726,8,'XX shipping','',NULL),
(3728,8,'ship_meth_amount','0.00',NULL),
(3738,8,'stock_238','9991',NULL),
(3739,8,'stock_239','9997',NULL),
(3744,7,'pay_cost','0.00',NULL),
(3752,7,'feat_prod_id_7_1_240','IDENT-DE-610041-1',NULL),
(3753,7,'feat_prod_id_7_2_240','R61004-1',NULL),
(3759,7,'XX total_incl_vat','725.00',NULL),
(3761,7,'XX shipping','',NULL),
(3763,7,'ship_meth_amount','0.00',NULL),
(3769,7,'stock_240','9991',NULL),
(3770,12,'ship_free_as_of','',NULL),
(3771,12,'usr_user_agent_short','Moz/5.0 Win NT 10.0; Win64; x64; rv:157.0 Gecko/20100101 Firefox/157.0',NULL),
(3772,12,'usr_user_agent','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:157.0) Gecko/20100101 Firefox/157.0',NULL),
(3773,12,'weight','1.5',NULL),
(3774,12,'pay_cost','0.00',NULL),
(3775,12,'basket_total','416.25',NULL),
(3776,12,'basket_total_net','416.25',NULL),
(3777,12,'discount_amount','0.00',NULL),
(3778,12,'_version','0.8003',NULL),
(3779,12,'discount_perc','',NULL),
(3780,12,'prod_id_6_price_incl_vat','300.00',NULL),
(3781,12,'prd_id_6_bask_ins','2026-10-08 13:08:21',NULL),
(3782,12,'prod_id_8_price_incl_vat','50.00',NULL),
(3783,12,'prd_id_8_bask_ins','2026-10-14 09:44:28',NULL),
(3784,12,'prod_id_1_price_incl_vat','100.00',NULL),
(3785,12,'prd_id_1_bask_ins','2026-10-14 13:04:01',NULL),
(3786,12,'checkout_zahlungsart_select','prx',NULL),
(3787,12,'ref','',NULL),
(3788,12,'remarks','test',NULL),
(3789,12,'delivery_date','14.10.2026',NULL),
(3790,12,'campaign_count','',NULL),
(3791,12,'XX total_incl_vat','449.95',NULL),
(3792,12,'vat_amount','33.72',NULL),
(3793,12,'XX shipping','',NULL),
(3794,12,'ship_meth','std',NULL),
(3795,12,'ship_meth_amount','0.00',NULL),
(3796,12,'currency','CHF',NULL),
(3800,12,'stock_242','9999',NULL),
(3801,12,'stock_243','9997',NULL),
(3802,12,'stock_241','9991',NULL),
(3803,12,'dhl_shipmentTrackingNumber','',NULL),
(3804,12,'dhl_packages__trackingUrl__0','',NULL),
(3805,12,'dhl_trackingUrl','',NULL),
(3806,12,'dhl_packages__trackingNumber__0','',NULL),
(3807,12,'dhl_doc_path','upload/dhl_61014132820_526.pdf',NULL),
(3839,14,'ship_free_as_of','',NULL),
(3840,14,'usr_user_agent_short','Moz/5.0 Win NT 10.0; Win64; x64 AWK/537.36 KHTML, l-Gck Chrome/155.0.0.0',NULL),
(3841,14,'usr_user_agent','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36',NULL),
(3842,14,'weight','0.5',NULL),
(3844,14,'basket_total','277.5',NULL),
(3845,14,'basket_total_net','277.5',NULL),
(3846,14,'discount_amount','0.00',NULL),
(3847,14,'_version','0.8003',NULL),
(3848,14,'discount_perc','',NULL),
(3849,14,'prod_id_6_price_incl_vat','300.00',NULL),
(3850,14,'prd_id_6_bask_ins','2026-10-14 13:55:50',NULL),
(3851,14,'checkout_zahlungsart_select','prx',NULL),
(3852,14,'ref','',NULL),
(3853,14,'remarks','',NULL),
(3854,14,'delivery_date','14.10.2026',NULL),
(3855,14,'campaign_count','',NULL),
(3857,14,'vat_amount','22.48',NULL),
(3859,14,'ship_meth','std',NULL),
(3861,14,'currency','CHF',NULL),
(3862,14,'prod_id_7_price_incl_vat','700.00',NULL),
(3864,14,'prod_id_5_price_incl_vat','100.00',NULL),
(3865,14,'stock_246','9990',NULL),
(3866,14,'dhl_shipmentTrackingNumber','',NULL),
(3867,14,'dhl_packages__trackingUrl__0','',NULL),
(3868,14,'dhl_trackingUrl','',NULL),
(3869,14,'dhl_packages__trackingNumber__0','',NULL),
(3870,14,'dhl_doc_path','upload/dhl_61014141712_6225.pdf',NULL),
(3871,14,'pdf_bill','upload/qr_bill_cust_rcpt_14_610141.pdf',NULL),
(3887,14,'prd_id_7_bask_ins','2026-10-16 14:24:48',NULL),
(3888,14,'feat_prod_id_7_1_248','IDENT-DE-610041-1',NULL),
(3902,14,'prod_id_7_1','IDENT-DE-610041-1',NULL),
(3904,14,'stock_248','9990',NULL),
(3905,14,'stock_247','9989',NULL),
(3920,14,'feat_prod_id_7_1_250','IDENT-DE-610041-1',NULL),
(3936,14,'stock_249','9989',NULL),
(3937,14,'stock_250','9989',NULL),
(3952,14,'feat_prod_id_7_1_252','IDENT-DE-610041-1',NULL),
(3968,14,'stock_251','9989',NULL),
(3969,14,'stock_252','9989',NULL),
(3984,14,'feat_prod_id_7_1_254','IDENT-DE-610041-1',NULL),
(4000,14,'stock_253','9989',NULL),
(4001,14,'stock_254','9989',NULL),
(4016,14,'feat_prod_id_7_1_256','IDENT-DE-610041-1',NULL),
(4032,14,'stock_255','9989',NULL),
(4033,14,'stock_256','9989',NULL),
(4048,14,'feat_prod_id_7_1_258','IDENT-DE-610041-1',NULL),
(4064,14,'stock_257','9989',NULL),
(4065,14,'stock_258','9989',NULL),
(4080,14,'feat_prod_id_7_1_260','IDENT-DE-610041-1',NULL),
(4096,14,'stock_259','9989',NULL),
(4097,14,'stock_260','9989',NULL),
(4112,14,'feat_prod_id_7_1_262','IDENT-DE-610041-1',NULL),
(4128,14,'stock_261','9989',NULL),
(4129,14,'stock_262','9989',NULL),
(4144,14,'feat_prod_id_7_1_264','IDENT-DE-610041-1',NULL),
(4160,14,'stock_263','9989',NULL),
(4161,14,'stock_264','9989',NULL),
(4176,14,'feat_prod_id_7_1_266','IDENT-DE-610041-1',NULL),
(4192,14,'stock_266','9989',NULL),
(4193,14,'stock_265','9989',NULL),
(4208,14,'feat_prod_id_7_1_268','IDENT-DE-610041-1',NULL),
(4224,14,'stock_267','9989',NULL),
(4225,14,'stock_268','9989',NULL),
(4240,14,'feat_prod_id_7_1_270','IDENT-DE-610041-1',NULL),
(4256,14,'stock_270','9989',NULL),
(4257,14,'stock_269','9989',NULL),
(4272,14,'feat_prod_id_7_1_272','IDENT-DE-610041-1',NULL),
(4288,14,'stock_271','9989',NULL),
(4289,14,'stock_272','9989',NULL),
(4304,14,'feat_prod_id_7_1_274','IDENT-DE-610041-1',NULL),
(4320,14,'stock_274','9989',NULL),
(4321,14,'stock_273','9989',NULL),
(4336,14,'feat_prod_id_7_1_276','IDENT-DE-610041-1',NULL),
(4352,14,'stock_275','9989',NULL),
(4353,14,'stock_276','9989',NULL),
(4368,14,'feat_prod_id_7_1_278','IDENT-DE-610041-1',NULL),
(4384,14,'stock_277','9989',NULL),
(4385,14,'stock_278','9989',NULL),
(4400,14,'feat_prod_id_7_1_280','IDENT-DE-610041-1',NULL),
(4416,14,'stock_279','9989',NULL),
(4417,14,'stock_280','9989',NULL),
(4432,14,'feat_prod_id_7_1_282','IDENT-DE-610041-1',NULL),
(4448,14,'stock_281','9989',NULL),
(4449,14,'stock_282','9989',NULL),
(4464,14,'feat_prod_id_7_1_284','IDENT-DE-610041-1',NULL),
(4480,14,'stock_283','9989',NULL),
(4481,14,'stock_284','9989',NULL),
(4496,14,'feat_prod_id_7_1_286','IDENT-DE-610041-1',NULL),
(4512,14,'stock_285','9989',NULL),
(4513,14,'stock_286','9989',NULL),
(4528,14,'feat_prod_id_7_1_288','IDENT-DE-610041-1',NULL),
(4544,14,'stock_287','9989',NULL),
(4545,14,'stock_288','9989',NULL),
(4560,14,'feat_prod_id_7_1_290','IDENT-DE-610041-1',NULL),
(4576,14,'stock_290','9989',NULL),
(4577,14,'stock_289','9989',NULL),
(4592,14,'feat_prod_id_7_1_292','IDENT-DE-610041-1',NULL),
(4608,14,'stock_291','9989',NULL),
(4609,14,'stock_292','9989',NULL),
(4624,14,'feat_prod_id_7_1_294','IDENT-DE-610041-1',NULL),
(4640,14,'stock_294','9989',NULL),
(4641,14,'stock_293','9989',NULL),
(4656,14,'feat_prod_id_7_1_296','IDENT-DE-610041-1',NULL),
(4672,14,'stock_296','9989',NULL),
(4673,14,'stock_295','9989',NULL),
(4688,14,'feat_prod_id_7_1_298','IDENT-DE-610041-1',NULL),
(4704,14,'stock_297','9989',NULL),
(4705,14,'stock_298','9989',NULL),
(4720,14,'feat_prod_id_7_1_300','IDENT-DE-610041-1',NULL),
(4736,14,'stock_299','9989',NULL),
(4737,14,'stock_300','9989',NULL),
(4752,14,'feat_prod_id_7_1_302','IDENT-DE-610041-1',NULL),
(4768,14,'stock_301','9989',NULL),
(4769,14,'stock_302','9989',NULL),
(4784,14,'feat_prod_id_7_1_304','IDENT-DE-610041-1',NULL),
(4800,14,'stock_303','9989',NULL),
(4801,14,'stock_304','9989',NULL),
(4816,14,'feat_prod_id_7_1_306','IDENT-DE-610041-1',NULL),
(4832,14,'stock_306','9989',NULL),
(4833,14,'stock_305','9989',NULL),
(4848,14,'feat_prod_id_7_1_308','IDENT-DE-610041-1',NULL),
(4864,14,'stock_307','9989',NULL),
(4865,14,'stock_308','9989',NULL),
(4880,14,'feat_prod_id_7_1_310','IDENT-DE-610041-1',NULL),
(4896,14,'stock_310','9989',NULL),
(4897,14,'stock_309','9989',NULL),
(4912,14,'feat_prod_id_7_1_312','IDENT-DE-610041-1',NULL),
(4928,14,'stock_311','9989',NULL),
(4929,14,'stock_312','9989',NULL),
(4944,14,'feat_prod_id_7_1_314','IDENT-DE-610041-1',NULL),
(4960,14,'stock_314','9989',NULL),
(4961,14,'stock_313','9989',NULL),
(4976,14,'feat_prod_id_7_1_316','IDENT-DE-610041-1',NULL),
(4992,14,'stock_316','9989',NULL),
(4993,14,'stock_315','9989',NULL),
(5008,14,'feat_prod_id_7_1_318','IDENT-DE-610041-1',NULL),
(5024,14,'stock_317','9989',NULL),
(5025,14,'stock_318','9989',NULL),
(5040,14,'feat_prod_id_7_1_320','IDENT-DE-610041-1',NULL),
(5056,14,'stock_319','9989',NULL),
(5057,14,'stock_320','9989',NULL),
(5072,14,'feat_prod_id_7_1_322','IDENT-DE-610041-1',NULL),
(5088,14,'stock_321','9989',NULL),
(5089,14,'stock_322','9989',NULL),
(5104,14,'feat_prod_id_7_1_324','IDENT-DE-610041-1',NULL),
(5120,14,'stock_324','9989',NULL),
(5121,14,'stock_323','9989',NULL),
(5136,14,'feat_prod_id_7_1_326','IDENT-DE-610041-1',NULL),
(5152,14,'stock_325','9989',NULL),
(5153,14,'stock_326','9989',NULL),
(5168,14,'feat_prod_id_7_1_328','IDENT-DE-610041-1',NULL),
(5184,14,'stock_327','9989',NULL),
(5185,14,'stock_328','9989',NULL),
(5200,14,'feat_prod_id_7_1_330','IDENT-DE-610041-1',NULL),
(5216,14,'stock_329','9989',NULL),
(5217,14,'stock_330','9989',NULL),
(5232,14,'feat_prod_id_7_1_332','IDENT-DE-610041-1',NULL),
(5248,14,'stock_331','9989',NULL),
(5249,14,'stock_332','9989',NULL),
(5264,14,'feat_prod_id_7_1_334','IDENT-DE-610041-1',NULL),
(5280,14,'stock_333','9989',NULL),
(5281,14,'stock_334','9989',NULL),
(5296,14,'feat_prod_id_7_1_336','IDENT-DE-610041-1',NULL),
(5312,14,'stock_336','9989',NULL),
(5313,14,'stock_335','9989',NULL),
(5328,14,'feat_prod_id_7_1_338','IDENT-DE-610041-1',NULL),
(5344,14,'stock_337','9989',NULL),
(5345,14,'stock_338','9989',NULL),
(5360,14,'feat_prod_id_7_1_340','IDENT-DE-610041-1',NULL),
(5376,14,'stock_339','9989',NULL),
(5377,14,'stock_340','9989',NULL),
(5392,14,'feat_prod_id_7_1_342','IDENT-DE-610041-1',NULL),
(5408,14,'stock_341','9989',NULL),
(5409,14,'stock_342','9989',NULL),
(5424,14,'feat_prod_id_7_1_344','IDENT-DE-610041-1',NULL),
(5440,14,'stock_343','9989',NULL),
(5441,14,'stock_344','9989',NULL),
(5456,14,'feat_prod_id_7_1_346','IDENT-DE-610041-1',NULL),
(5472,14,'stock_345','9989',NULL),
(5473,14,'stock_346','9989',NULL),
(5488,14,'feat_prod_id_7_1_348','IDENT-DE-610041-1',NULL),
(5504,14,'stock_347','9989',NULL),
(5505,14,'stock_348','9989',NULL),
(5520,14,'feat_prod_id_7_1_350','IDENT-DE-610041-1',NULL),
(5536,14,'stock_350','9989',NULL),
(5537,14,'stock_349','9989',NULL),
(5552,14,'feat_prod_id_7_1_352','IDENT-DE-610041-1',NULL),
(5568,14,'stock_351','9989',NULL),
(5569,14,'stock_352','9989',NULL),
(5584,14,'feat_prod_id_7_1_354','IDENT-DE-610041-1',NULL),
(5600,14,'stock_354','9989',NULL),
(5601,14,'stock_353','9989',NULL),
(5616,14,'feat_prod_id_7_1_356','IDENT-DE-610041-1',NULL),
(5632,14,'stock_355','9989',NULL),
(5633,14,'stock_356','9989',NULL),
(5648,14,'feat_prod_id_7_1_358','IDENT-DE-610041-1',NULL),
(5664,14,'stock_357','9989',NULL),
(5665,14,'stock_358','9989',NULL),
(5680,14,'feat_prod_id_7_1_360','IDENT-DE-610041-1',NULL),
(5696,14,'stock_359','9989',NULL),
(5697,14,'stock_360','9989',NULL),
(6430,16,'ship_free_as_of','',NULL),
(6431,16,'usr_user_agent_short','Moz/5.0 Win NT 10.0; Win64; x64; rv:158.0 Gecko/20100101 Firefox/158.0',NULL),
(6432,16,'usr_user_agent','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:158.0) Gecko/20100101 Firefox/158.0',NULL),
(6433,16,'weight','0.5',NULL),
(6435,16,'discount_perc','',NULL),
(6436,16,'discount_amount','0.00',NULL),
(6437,16,'basket_total_net','699',NULL),
(6438,16,'basket_total','699',NULL),
(6439,16,'_version','0.8003',NULL),
(6440,16,'prod_id_4_price_incl_vat','755.60',NULL),
(6441,16,'prd_id_4_bask_ins','2026-10-17 17:05:01',NULL),
(6442,16,'checkout_zahlungsart_select','prx',NULL),
(6443,16,'ref','',NULL),
(6444,16,'remarks','test',NULL),
(6445,16,'delivery_date','17.10.2026',NULL),
(6446,16,'campaign_count','',NULL),
(6448,16,'vat_amount','56.62',NULL),
(6450,16,'ship_meth','std',NULL),
(6452,16,'currency','CHF',NULL),
(6453,16,'prod_id_5_price_incl_vat','100.00',NULL),
(6455,16,'prod_id_6_price_incl_vat','300.00',NULL),
(6456,16,'prod_id_3_price_incl_vat','97.30',NULL),
(6457,16,'prod_id_1_price_incl_vat','100.00',NULL),
(6458,16,'prod_id_8_price_incl_vat','50.00',NULL),
(6459,16,'stock_388','9998',NULL),
(6464,16,'pay_cost','0.00',NULL),
(6477,16,'XX total_incl_vat','755.60',NULL),
(6479,16,'XX shipping','',NULL),
(6481,16,'ship_meth_amount','0.00',NULL),
(6489,16,'stock_389','9997',NULL),
(6614,18,'ship_free_as_of','',NULL),
(6615,18,'usr_user_agent_short','Moz/5.0 Win NT 10.0; Win64; x64; rv:158.0 Gecko/20100101 Firefox/158.0',NULL),
(6616,18,'usr_user_agent','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:158.0) Gecko/20100101 Firefox/158.0',NULL),
(6617,18,'weight','2',NULL),
(6619,18,'discount_perc','',NULL),
(6620,18,'basket_total_net','555',NULL),
(6621,18,'discount_amount','0.00',NULL),
(6622,18,'basket_total','555',NULL),
(6623,18,'_version','0.8003',NULL),
(6624,18,'prod_id_1_price_incl_vat','100.00',NULL),
(6625,18,'prd_id_1_bask_ins','2026-10-21 17:03:03',NULL),
(6626,18,'prod_id_6_price_incl_vat','300.00',NULL),
(6627,18,'prd_id_6_bask_ins','2026-10-21 17:03:36',NULL),
(6628,18,'prod_id_5_price_incl_vat','100.00',NULL),
(6629,18,'prd_id_5_bask_ins','2026-10-21 17:03:44',NULL),
(6632,18,'checkout_zahlungsart_select','prx',NULL),
(6633,18,'ref','',NULL),
(6634,18,'remarks','test',NULL),
(6635,18,'delivery_date','26.10.2026',NULL),
(6636,18,'campaign_count','',NULL),
(6638,18,'vat_amount','44.96',NULL),
(6640,18,'ship_meth','std',NULL),
(6642,18,'currency','CHF',NULL),
(6643,18,'prod_id_7_2','R61004-1',NULL),
(6647,18,'prod_id_7_1','IDENT-DE-610041-2',NULL),
(6648,18,'prod_id_3_price_incl_vat','97.30',NULL),
(6649,18,'prod_id_8_price_incl_vat','50.00',NULL),
(6650,18,'prod_id_7_price_incl_vat','725.00',NULL),
(6651,18,'prod_id_4_price_incl_vat','755.60',NULL),
(6652,18,'stock_396','9998',NULL),
(6653,18,'stock_395','9989',NULL),
(6654,18,'stock_397','9995',NULL),
(6655,18,'stock_394','9995',NULL),
(6692,18,'stock_399','9988',NULL),
(6693,18,'stock_398','9994',NULL),
(6694,18,'stock_400','9997',NULL),
(6731,18,'stock_401','9994',NULL),
(6732,18,'stock_402','9988',NULL),
(6733,18,'stock_403','9997',NULL),
(6770,18,'stock_405','9988',NULL),
(6771,18,'stock_406','9997',NULL),
(6772,18,'stock_404','9994',NULL),
(6809,18,'stock_409','9997',NULL),
(6810,18,'stock_407','9994',NULL),
(6811,18,'stock_408','9988',NULL),
(6834,18,'voucher_value','18.5013876040703',NULL),
(6835,18,'voucher_count_available','',NULL),
(6836,18,'voucher_count_used','',NULL),
(6837,18,'voucher_id','2',NULL),
(6850,18,'stock_411','9997',NULL),
(6851,18,'stock_410','9994',NULL),
(6890,18,'stock_413','9997',NULL),
(6891,18,'stock_412','9994',NULL),
(6906,14,'feat_prod_id_7_1_415','IDENT-DE-610041-1',NULL),
(6922,14,'stock_415','9988',NULL),
(6923,14,'stock_414','9988',NULL),
(6938,14,'feat_prod_id_7_1_417','IDENT-DE-610041-1',NULL),
(6954,14,'stock_416','9988',NULL),
(6955,14,'stock_417','9988',NULL),
(6994,18,'stock_419','9997',NULL),
(6995,18,'stock_418','9994',NULL),
(7032,18,'stock_420','9997',NULL),
(7044,18,'prd_id_4_bask_ins','2026-10-26 10:14:30',NULL),
(7045,18,'feat_prod_id_4_1_421','IDENT-DE-610041-2',NULL),
(7066,18,'prod_id_4_1','IDENT-DE-610041-2',NULL),
(7071,18,'stock_421','9996',NULL),
(7084,18,'feat_prod_id_4_1_422','IDENT-DE-610041-2',NULL),
(7110,18,'stock_422','9995',NULL),
(7123,18,'feat_prod_id_4_1_423','IDENT-DE-610041-2',NULL),
(7149,18,'stock_423','9995',NULL),
(7164,14,'feat_prod_id_7_1_425','IDENT-DE-610041-1',NULL),
(7180,14,'stock_424','9988',NULL),
(7181,14,'stock_425','9988',NULL),
(7196,14,'feat_prod_id_7_1_427','IDENT-DE-610041-1',NULL),
(7212,14,'stock_427','9988',NULL),
(7213,14,'stock_426','9988',NULL),
(7228,14,'feat_prod_id_7_1_429','IDENT-DE-610041-1',NULL),
(7244,14,'stock_428','9988',NULL),
(7245,14,'stock_429','9988',NULL),
(7250,14,'pay_cost','0.00',NULL),
(7260,14,'feat_prod_id_7_1_431','IDENT-DE-610041-1',NULL),
(7266,14,'XX total_incl_vat','1005.00',NULL),
(7268,14,'XX shipping','',NULL),
(7270,14,'ship_meth_amount','0.00',NULL),
(7276,14,'stock_431','9988',NULL),
(7277,14,'stock_430','9988',NULL),
(7290,18,'feat_prod_id_4_1_432','IDENT-DE-610041-2',NULL),
(7316,18,'stock_432','9995',NULL),
(7317,19,'ship_free_as_of','',NULL),
(7318,19,'usr_user_agent_short','Moz/5.0 Win NT 10.0; Win64; x64; rv:158.0 Gecko/20100101 Firefox/158.0',NULL),
(7319,19,'usr_user_agent','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:158.0) Gecko/20100101 Firefox/158.0',NULL),
(7320,19,'weight','0.5',NULL),
(7322,19,'discount_perc','',NULL),
(7323,19,'basket_total_net','277.5',NULL),
(7324,19,'discount_amount','0.00',NULL),
(7325,19,'basket_total','277.5',NULL),
(7326,19,'_version','0.8003',NULL),
(7327,19,'prod_id_6_price_incl_vat','300.00',NULL),
(7328,19,'prd_id_6_bask_ins','2026-10-26 11:09:42',NULL),
(7329,19,'checkout_zahlungsart_select','prx',NULL),
(7330,19,'ref','',NULL),
(7331,19,'remarks','',NULL),
(7332,19,'delivery_date','26.10.2026',NULL),
(7333,19,'campaign_count','',NULL),
(7335,19,'vat_amount','20.23',NULL),
(7337,19,'voucher_value','27.7520814061055',NULL),
(7338,19,'voucher_count_available','',NULL),
(7339,19,'voucher_count_used','',NULL),
(7340,19,'voucher_id','2',NULL),
(7341,19,'ship_meth','std',NULL),
(7343,19,'currency','CHF',NULL),
(7345,19,'stock_433','9988',NULL),
(7374,19,'stock_434','9987',NULL),
(7403,19,'stock_435','9987',NULL),
(7432,19,'stock_436','9987',NULL),
(7461,19,'stock_437','9987',NULL),
(7490,19,'stock_438','9987',NULL),
(7519,19,'stock_439','9987',NULL),
(7548,19,'stock_440','9987',NULL),
(7577,19,'stock_441','9987',NULL),
(7582,19,'pay_cost','0.00',NULL),
(7595,19,'XX total_incl_vat','297.75',NULL),
(7597,19,'XX shipping','',NULL),
(7603,19,'ship_meth_amount','0.00',NULL),
(7606,19,'stock_442','9987',NULL),
(7619,18,'feat_prod_id_4_1_443','IDENT-DE-610041-2',NULL),
(7645,18,'stock_443','9995',NULL),
(7658,18,'feat_prod_id_4_1_444','IDENT-DE-610041-2',NULL),
(7684,18,'stock_444','9995',NULL),
(7697,18,'feat_prod_id_4_1_445','IDENT-DE-610041-2',NULL),
(7723,18,'stock_445','9995',NULL),
(7736,18,'feat_prod_id_4_1_446','IDENT-DE-610041-2',NULL),
(7762,18,'stock_446','9995',NULL),
(7775,18,'feat_prod_id_4_1_447','IDENT-DE-610041-2',NULL),
(7801,18,'stock_447','9995',NULL),
(7814,18,'feat_prod_id_4_1_448','IDENT-DE-610041-2',NULL),
(7840,18,'stock_448','9995',NULL),
(7853,18,'feat_prod_id_4_1_449','IDENT-DE-610041-2',NULL),
(7879,18,'stock_449','9995',NULL),
(7892,18,'feat_prod_id_4_1_450','IDENT-DE-610041-2',NULL),
(7918,18,'stock_450','9995',NULL),
(7931,18,'feat_prod_id_4_1_451','IDENT-DE-610041-2',NULL),
(7957,18,'stock_451','9995',NULL),
(7970,18,'feat_prod_id_4_1_452','IDENT-DE-610041-2',NULL),
(7996,18,'stock_452','9995',NULL),
(8009,18,'feat_prod_id_4_1_453','IDENT-DE-610041-2',NULL),
(8035,18,'stock_453','9995',NULL),
(8048,18,'feat_prod_id_4_1_454','IDENT-DE-610041-2',NULL),
(8074,18,'stock_454','9995',NULL),
(8087,18,'feat_prod_id_4_1_455','IDENT-DE-610041-2',NULL),
(8113,18,'stock_455','9995',NULL),
(8126,18,'feat_prod_id_4_1_456','IDENT-DE-610041-2',NULL),
(8128,18,'prd_id_8_bask_ins','2026-10-26 11:49:54',NULL),
(8154,18,'stock_456','9995',NULL),
(8155,18,'stock_457','9998',NULL),
(8168,18,'feat_prod_id_4_1_458','IDENT-DE-610041-2',NULL),
(8170,18,'prd_id_7_bask_ins','2026-10-26 11:50:22',NULL),
(8171,18,'feat_prod_id_7_2_459','R61004-1',NULL),
(8172,18,'feat_prod_id_7_1_459','IDENT-DE-610041-1',NULL),
(8198,18,'stock_459','9988',NULL),
(8199,18,'stock_458','9995',NULL),
(8212,18,'feat_prod_id_4_1_460','IDENT-DE-610041-2',NULL),
(8215,18,'feat_prod_id_7_2_461','R61004-1',NULL),
(8216,18,'feat_prod_id_7_1_461','IDENT-DE-610041-1',NULL),
(8242,18,'stock_461','9987',NULL),
(8243,18,'stock_460','9995',NULL),
(8256,18,'feat_prod_id_4_1_462','IDENT-DE-610041-2',NULL),
(8259,18,'feat_prod_id_7_2_463','R61004-1',NULL),
(8260,18,'feat_prod_id_7_1_463','IDENT-DE-610041-1',NULL),
(8286,18,'stock_463','9987',NULL),
(8287,18,'stock_462','9995',NULL),
(8300,18,'feat_prod_id_4_1_464','IDENT-DE-610041-2',NULL),
(8303,18,'feat_prod_id_7_2_465','R61004-1',NULL),
(8304,18,'feat_prod_id_7_1_465','IDENT-DE-610041-1',NULL),
(8330,18,'stock_465','9987',NULL),
(8331,18,'stock_464','9995',NULL),
(8344,18,'feat_prod_id_4_1_466','IDENT-DE-610041-2',NULL),
(8347,18,'feat_prod_id_7_2_467','R61004-1',NULL),
(8348,18,'feat_prod_id_7_1_467','IDENT-DE-610041-1',NULL),
(8374,18,'stock_466','9995',NULL),
(8375,18,'stock_467','9987',NULL),
(8388,18,'feat_prod_id_4_1_468','IDENT-DE-610041-2',NULL),
(8391,18,'feat_prod_id_7_2_469','R61004-1',NULL),
(8392,18,'feat_prod_id_7_1_469','IDENT-DE-610041-1',NULL),
(8418,18,'stock_469','9987',NULL),
(8419,18,'stock_468','9995',NULL),
(8432,18,'feat_prod_id_4_1_470','IDENT-DE-610041-2',NULL),
(8435,18,'feat_prod_id_7_2_471','R61004-1',NULL),
(8436,18,'feat_prod_id_7_1_471','IDENT-DE-610041-1',NULL),
(8462,18,'stock_471','9987',NULL),
(8463,18,'stock_470','9995',NULL),
(8476,18,'feat_prod_id_4_1_472','IDENT-DE-610041-2',NULL),
(8479,18,'feat_prod_id_7_2_473','R61004-1',NULL),
(8480,18,'feat_prod_id_7_1_473','IDENT-DE-610041-1',NULL),
(8506,18,'stock_473','9987',NULL),
(8507,18,'stock_472','9995',NULL),
(8520,18,'feat_prod_id_4_1_474','IDENT-DE-610041-2',NULL),
(8523,18,'feat_prod_id_7_2_475','R61004-1',NULL),
(8524,18,'feat_prod_id_7_1_475','IDENT-DE-610041-1',NULL),
(8550,18,'stock_475','9987',NULL),
(8551,18,'stock_474','9995',NULL),
(8564,18,'feat_prod_id_4_1_476','IDENT-DE-610041-2',NULL),
(8567,18,'feat_prod_id_7_2_477','R61004-1',NULL),
(8568,18,'feat_prod_id_7_1_477','IDENT-DE-610041-1',NULL),
(8594,18,'stock_476','9995',NULL),
(8595,18,'stock_477','9987',NULL),
(8608,18,'feat_prod_id_4_1_478','IDENT-DE-610041-2',NULL),
(8611,18,'feat_prod_id_7_2_479','R61004-1',NULL),
(8612,18,'feat_prod_id_7_1_479','IDENT-DE-610041-1',NULL),
(8638,18,'stock_479','9987',NULL),
(8639,18,'stock_478','9995',NULL),
(8652,18,'feat_prod_id_4_1_480','IDENT-DE-610041-2',NULL),
(8655,18,'feat_prod_id_7_2_481','R61004-1',NULL),
(8656,18,'feat_prod_id_7_1_481','IDENT-DE-610041-1',NULL),
(8682,18,'stock_481','9987',NULL),
(8683,18,'stock_480','9995',NULL),
(8696,18,'feat_prod_id_4_1_482','IDENT-DE-610041-2',NULL),
(8699,18,'feat_prod_id_7_2_483','R61004-1',NULL),
(8700,18,'feat_prod_id_7_1_483','IDENT-DE-610041-1',NULL),
(8726,18,'stock_482','9995',NULL),
(8727,18,'stock_483','9987',NULL),
(8740,18,'feat_prod_id_4_1_484','IDENT-DE-610041-2',NULL),
(8743,18,'feat_prod_id_7_2_485','R61004-1',NULL),
(8744,18,'feat_prod_id_7_1_485','IDENT-DE-610041-1',NULL),
(8770,18,'stock_485','9987',NULL),
(8771,18,'stock_484','9995',NULL),
(8784,18,'feat_prod_id_4_1_486','IDENT-DE-610041-2',NULL),
(8787,18,'feat_prod_id_7_2_487','R61004-1',NULL),
(8788,18,'feat_prod_id_7_1_487','IDENT-DE-610041-1',NULL),
(8814,18,'stock_486','9995',NULL),
(8815,18,'stock_487','9987',NULL),
(8828,18,'feat_prod_id_4_1_488','IDENT-DE-610041-2',NULL),
(8831,18,'feat_prod_id_7_2_489','R61004-1',NULL),
(8832,18,'feat_prod_id_7_1_489','IDENT-DE-610041-1',NULL),
(8858,18,'stock_489','9987',NULL),
(8859,18,'stock_488','9995',NULL),
(8872,18,'feat_prod_id_4_1_490','IDENT-DE-610041-2',NULL),
(8875,18,'feat_prod_id_7_2_491','R61004-1',NULL),
(8876,18,'feat_prod_id_7_1_491','IDENT-DE-610041-1',NULL),
(8902,18,'stock_490','9995',NULL),
(8903,18,'stock_491','9987',NULL),
(8904,20,'ship_free_as_of','',NULL),
(8905,20,'usr_user_agent_short','Moz/5.0 Win NT 10.0; Win64; x64; rv:158.0 Gecko/20100101 Firefox/158.0',NULL),
(8906,20,'usr_user_agent','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:158.0) Gecko/20100101 Firefox/158.0',NULL),
(8907,20,'weight','1',NULL),
(8909,20,'discount_perc','',NULL),
(8910,20,'basket_total_net','614.95',NULL),
(8911,20,'discount_amount','0.00',NULL),
(8912,20,'basket_total','614.95',NULL),
(8913,20,'_version','0.8003',NULL),
(8914,20,'prod_id_6_price_incl_vat','300.00',NULL),
(8915,20,'prd_id_6_bask_ins','2026-10-26 11:20:07',NULL),
(8916,20,'prod_id_2_price_incl_vat','364.75',NULL),
(8917,20,'prd_id_2_bask_ins','2026-10-26 12:20:11',NULL),
(8918,20,'checkout_zahlungsart_select','prx',NULL),
(8919,20,'ref','',NULL),
(8920,20,'remarks','',NULL),
(8921,20,'delivery_date','26.10.2026',NULL),
(8922,20,'campaign_count','',NULL),
(8924,20,'vat_amount','44.83',NULL),
(8926,20,'voucher_value','61.4960814061055',NULL),
(8927,20,'voucher_count_available','',NULL),
(8928,20,'voucher_count_used','',NULL),
(8929,20,'voucher_id','2',NULL),
(8930,20,'ship_meth','std',NULL),
(8932,20,'currency','CHF',NULL),
(8935,20,'stock_492','9987',NULL),
(8936,20,'stock_493','7776',NULL),
(8968,20,'stock_494','9986',NULL),
(8969,20,'stock_495','7775',NULL),
(8982,18,'feat_prod_id_4_1_496','IDENT-DE-610041-2',NULL),
(8985,18,'feat_prod_id_7_2_497','R61004-1',NULL),
(8986,18,'feat_prod_id_7_1_497','IDENT-DE-610041-1',NULL),
(9012,18,'stock_497','9987',NULL),
(9013,18,'stock_496','9995',NULL),
(9045,20,'stock_498','9986',NULL),
(9046,20,'stock_499','7775',NULL),
(9078,20,'stock_500','9986',NULL),
(9079,20,'stock_501','7775',NULL),
(9111,20,'stock_502','9986',NULL),
(9112,20,'stock_503','7775',NULL),
(9144,20,'stock_504','9986',NULL),
(9145,20,'stock_505','7775',NULL),
(9177,20,'stock_507','7775',NULL),
(9178,20,'stock_506','9986',NULL),
(9210,20,'stock_508','9986',NULL),
(9211,20,'stock_509','7775',NULL),
(9224,18,'feat_prod_id_4_1_510','IDENT-DE-610041-2',NULL),
(9227,18,'feat_prod_id_7_2_511','R61004-1',NULL),
(9228,18,'feat_prod_id_7_1_511','IDENT-DE-610041-1',NULL),
(9254,18,'stock_510','9995',NULL),
(9255,18,'stock_511','9987',NULL),
(9287,20,'stock_513','7775',NULL),
(9288,20,'stock_512','9986',NULL),
(9301,18,'feat_prod_id_4_1_514','IDENT-DE-610041-2',NULL),
(9304,18,'feat_prod_id_7_2_515','R61004-1',NULL),
(9305,18,'feat_prod_id_7_1_515','IDENT-DE-610041-1',NULL),
(9331,18,'stock_514','9995',NULL),
(9332,18,'stock_515','9987',NULL),
(9345,18,'feat_prod_id_4_1_516','IDENT-DE-610041-2',NULL),
(9348,18,'feat_prod_id_7_2_517','R61004-1',NULL),
(9349,18,'feat_prod_id_7_1_517','IDENT-DE-610041-1',NULL),
(9375,18,'stock_517','9987',NULL),
(9376,18,'stock_516','9995',NULL),
(9389,18,'feat_prod_id_4_1_518','IDENT-DE-610041-2',NULL),
(9392,18,'feat_prod_id_7_2_519','R61004-1',NULL),
(9393,18,'feat_prod_id_7_1_519','IDENT-DE-610041-1',NULL),
(9419,18,'stock_518','9995',NULL),
(9420,18,'stock_519','9987',NULL),
(9433,18,'feat_prod_id_4_1_520','IDENT-DE-610041-2',NULL),
(9436,18,'feat_prod_id_7_2_521','R61004-1',NULL),
(9437,18,'feat_prod_id_7_1_521','IDENT-DE-610041-1',NULL),
(9463,18,'stock_521','9987',NULL),
(9464,18,'stock_520','9995',NULL),
(9496,20,'stock_522','9986',NULL),
(9497,20,'stock_523','7775',NULL),
(9502,20,'pay_cost','0.00',NULL),
(9517,20,'XX total_incl_vat','659.80',NULL),
(9519,20,'XX shipping','',NULL),
(9525,20,'ship_meth_amount','0.00',NULL),
(9529,20,'stock_525','7775',NULL),
(9530,20,'stock_524','9986',NULL),
(9531,21,'ship_free_as_of','',NULL),
(9532,21,'usr_user_agent_short','Moz/5.0 Win NT 10.0; Win64; x64 AWK/537.36 KHTML, l-Gck Chrome/155.0.0.0',NULL),
(9533,21,'usr_user_agent','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36',NULL),
(9534,21,'weight','0.5',NULL),
(9535,21,'pay_cost','0.00',NULL),
(9536,21,'discount_perc','',NULL),
(9537,21,'basket_total_net','337.45',NULL),
(9538,21,'discount_amount','0.00',NULL),
(9539,21,'basket_total','337.45',NULL),
(9540,21,'_version','0.8003',NULL),
(9541,21,'prod_id_2_price_incl_vat','364.75',NULL),
(9542,21,'prd_id_2_bask_ins','2026-10-26 15:14:18',NULL),
(9543,21,'checkout_zahlungsart_select','prx',NULL),
(9544,21,'ref','',NULL),
(9545,21,'remarks','',NULL),
(9546,21,'delivery_date','26.10.2026',NULL),
(9547,21,'campaign_count','',NULL),
(9548,21,'XX total_incl_vat','364.80',NULL),
(9549,21,'vat_amount','27.33',NULL),
(9550,21,'XX shipping','',NULL),
(9551,21,'ship_meth','std',NULL),
(9552,21,'ship_meth_amount','0.00',NULL),
(9553,21,'currency','CHF',NULL),
(9555,21,'stock_526','7775',NULL),
(9556,16,'cancel_uid','1',NULL),
(9557,16,'cancel_time','2026-10-29 12:24:41',NULL),
(9562,18,'pay_cost','0.00',NULL),
(9570,18,'feat_prod_id_4_1_527','IDENT-DE-610041-2',NULL),
(9577,18,'feat_prod_id_7_1_530','IDENT-DE-610041-1',NULL),
(9578,18,'feat_prod_id_7_2_530','R61004-1',NULL),
(9586,18,'XX total_incl_vat','1966.00',NULL),
(9588,18,'XX shipping','',NULL),
(9594,18,'ship_meth_amount','0.00',NULL),
(9606,18,'stock_528','9986',NULL),
(9607,18,'stock_531','9997',NULL),
(9608,18,'stock_529','9994',NULL),
(9609,18,'stock_527','9996',NULL),
(9610,18,'stock_530','9987',NULL),
(9611,18,'dhl_shipmentTrackingNumber','',NULL),
(9612,18,'dhl_packages__trackingUrl__0','',NULL),
(9613,18,'dhl_trackingUrl','',NULL),
(9614,18,'dhl_packages__trackingNumber__0','',NULL),
(9615,18,'dhl_doc_path','upload/dhl_61029125427_270.pdf',NULL),
(9616,18,'pdf_bill','upload/qr_bill_18_610291.pdf',NULL);
/*!40000 ALTER TABLE `orders_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders_products`
--

DROP TABLE IF EXISTS `orders_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders_products` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` mediumint(8) unsigned NOT NULL COMMENT 'foreign key',
  `prod_id` mediumint(8) unsigned NOT NULL COMMENT 'Product ID',
  `count` smallint(5) unsigned DEFAULT NULL,
  `campaign_id` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `price` double NOT NULL COMMENT 'Excl. VAT',
  `discount_perc` double NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`),
  KEY `idx_order_id_prod_id` (`order_id`,`prod_id`)
) ENGINE=MyISAM AUTO_INCREMENT=532 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders_products`
--

LOCK TABLES `orders_products` WRITE;
/*!40000 ALTER TABLE `orders_products` DISABLE KEYS */;
INSERT INTO `orders_products` VALUES
(1,1,7,1,0,699.352451433857,7.40740740740741),
(2,1,6,1,0,308.048103607771,9.90990990990991),
(3,1,7,1,0,699.352451433857,7.40740740740741),
(239,8,3,1,0,98,8.16326530612245),
(241,12,6,1,0,308.048103607771,9.90990990990991),
(240,7,7,1,0,699.352451433857,7.40740740740741),
(7,3,7,1,0,699.352451433857,7.40740740740741),
(8,3,6,1,0,308.048103607771,9.90990990990991),
(9,3,7,1,0,699.352451433857,7.40740740740741),
(234,10,4,1,0,699,0),
(233,9,3,1,0,98,8.16326530612245),
(238,8,6,1,0,308.048103607771,9.90990990990991),
(242,12,8,1,0,51.3927433446397,10),
(236,11,1,1,0,99.5,0),
(235,10,1,1,0,99.5,0),
(184,6,7,1,0,699.352451433857,7.40740740740741),
(183,6,6,1,0,308.048103607771,9.90990990990991),
(182,6,7,1,0,699.352451433857,7.40740740740741),
(243,12,1,1,0,92.5069380203515,0),
(530,18,7,1,0,699.352451433857,7.40740740740741),
(529,18,1,1,0,92.5069380203515,10),
(431,14,7,1,0,699.352451433857,7.40740740740741),
(430,14,6,1,0,308.048103607771,9.90990990990991),
(531,18,5,1,0,102.785486689279,10),
(389,16,4,1,0,699,0),
(525,20,2,1,0,444,24),
(528,18,6,1,0,308.048103607771,9.90990990990991),
(442,19,6,1,0,308.048103607771,9.90990990990991),
(527,18,4,1,0,699,0),
(524,20,6,1,0,308.048103607771,9.90990990990991),
(526,21,2,1,0,444,24);
/*!40000 ALTER TABLE `orders_products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders_status`
--

DROP TABLE IF EXISTS `orders_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders_status` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `uid` mediumint(9) NOT NULL COMMENT 'READONLY:=readonly',
  `src` char(31) CHARACTER SET ascii COLLATE ascii_bin DEFAULT NULL COMMENT 'READONLY:=readonly',
  `order_id` mediumint(8) unsigned NOT NULL COMMENT 'REM:=Order-ID || READONLY:=readonly || STYLE:=font-family:Consolas; font-weight:bold',
  `status_id` smallint(5) unsigned NOT NULL,
  `xval` varchar(511) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='REM:=remarks || EXT_TOP:=_foo.html || EXT_BOTTOM:=tbd_2';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders_status`
--

LOCK TABLES `orders_status` WRITE;
/*!40000 ALTER TABLE `orders_status` DISABLE KEYS */;
INSERT INTO `orders_status` VALUES
(1,'2026-02-16 14:07:24',1,'create_order_api',1,2,'{ \"UID\": 1 }'),
(2,'2026-10-05 16:04:03',1,'',7,4,'Order completed'),
(3,'2026-10-14 11:28:20',1,'',12,4,'Order completed'),
(4,'2026-10-14 11:28:21',0,'dhl_send_shipment',12,400,'<a href=\"/adx/show-order-info.html?info=dhl&order_id=12\">DHL Shipment</a> '),
(5,'2026-10-14 12:17:12',1,'',14,4,'Order completed'),
(6,'2026-10-14 12:17:13',0,'dhl_send_shipment',14,400,'<a href=\"/adx/show-order-info.html?info=dhl&order_id=14\">DHL Shipment</a> '),
(7,'2026-10-14 12:17:22',1,'mail_order2cust',14,213,'Re-sent to admin.local@eshop.pub'),
(8,'2026-10-14 13:54:49',1,'finalize_order',14,211,'Bestellbest&auml;tigung gesendet an Kunde: admin.local@eshop.pub'),
(9,'2026-10-14 14:35:44',1,'mail_order2merchant',14,800,'🛒 Bestellung [Auftrag Nr. 14] to root.shopd.merchant@algonetic.ch'),
(10,'2026-10-14 14:40:00',1,'mail_order2merchant',14,800,'🛒 Bestellung [Auftrag Nr. 14] to root.shopd.merchant@algonetic.ch'),
(11,'2026-10-29 11:24:41',1,'cancel_order',16,105,'Order cancelled'),
(12,'2026-10-29 11:54:27',1,'',18,4,'Order completed'),
(13,'2026-10-29 11:54:28',0,'dhl_send_shipment',18,400,'<a href=\"/adx/show-order-info.html?info=dhl&order_id=18\">DHL Shipment</a> '),
(14,'2026-10-29 11:54:35',1,'mail_order2cust',18,213,'Re-sent to admin.local@eshop.pub'),
(15,'2026-11-06 07:12:42',1,'Admin UI',18,104,'Delivery Note created: dn_18_611060.pdf'),
(16,'2026-11-06 07:14:18',1,'Admin UI',18,104,'Delivery Note created: dn_18_611060.pdf'),
(17,'2026-11-06 07:19:00',1,'Admin UI',18,104,'Delivery Note created: dn_18_611060.pdf');
/*!40000 ALTER TABLE `orders_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pdf_config`
--

DROP TABLE IF EXISTS `pdf_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `pdf_config` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT 'REM:=Primary Key || READONLY:=readonly',
  `xkey` char(63) NOT NULL COMMENT 'REM:=Param||STYLE:=color:red; font-family:Courier; background-color:#f0f0f0',
  `type` tinyint(3) unsigned DEFAULT NULL,
  `xval` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'STYLE:=background-color:lightyellow; font-weight:bold',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unq` (`xkey`,`type`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='PDF Konfiguration';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pdf_config`
--

LOCK TABLES `pdf_config` WRITE;
/*!40000 ALTER TABLE `pdf_config` DISABLE KEYS */;
INSERT INTO `pdf_config` VALUES
(1,'default_font',1,'RobotoFlex-Regular'),
(3,'default_font_size',0,'9.5'),
(4,'default_bold_font',0,'Helvetica-Bold'),
(5,'default_margin_left_a4p',0,'60'),
(6,'default_page_start_a4p',0,'750'),
(7,'default_logo_pos_y',0,'760'),
(8,'company',0,'PDF & ACME GmbH'),
(9,'company_street',0,'Moussonstrasse 8'),
(11,'company_zip',0,'8044'),
(12,'company_city',0,'Züri'),
(13,'company_phone',0,'+41 44 555 44 33'),
(15,'logo_path',0,'images/logo_algonetic_black_on_white_299x96.png'),
(17,'logo_height',0,'34'),
(18,'logo_width',0,'105'),
(19,'address_pos_x',0,'355'),
(20,'address_pos_y',0,'695'),
(21,'default_line_height',0,'12'),
(22,'company_vat_no',0,'CHE-434.825.408 (MWST)'),
(23,'company_iban',0,'CH93 0483 5277 5229 1100 1'),
(24,'company_iban_2',0,'CH66 0483 5277 5229 1100 2'),
(25,'company_email',0,'foo.bar@example.ch'),
(26,'company_slogan',0,'im Auftrag der Sub-ACME Züri');
/*!40000 ALTER TABLE `pdf_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `brand` char(15) DEFAULT NULL,
  `fingerprint` char(32) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL COMMENT 'READONLY:=1 || REM:=MD5',
  `instime` timestamp NOT NULL DEFAULT current_timestamp(),
  `count` mediumint(9) NOT NULL COMMENT 'READONLY:=1',
  `campaign_id` smallint(5) unsigned NOT NULL DEFAULT 0 COMMENT 'Referes to campaign_tok : id',
  `price` double NOT NULL COMMENT 'Excl. VAT',
  `sale_type` tinyint(3) unsigned NOT NULL DEFAULT 2 COMMENT 'READONLY:=1 || REM:=Calculates shipping',
  `prod_type` tinyint(3) unsigned NOT NULL DEFAULT 1 COMMENT 'REM:=2=Tastatur, Maus || READONLY:=0',
  `art_no` char(25) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL COMMENT 'Always required',
  `extra` char(8) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL COMMENT 'e.g. XP PRO',
  `condition` char(2) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL COMMENT 'e.g. A, A-',
  `ssp_it_service_code` char(3) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT 'n/a' COMMENT 'e.g. 4 / 2A / 2C',
  PRIMARY KEY (`id`),
  KEY `art_no` (`art_no`),
  KEY `ssp_it_serv_code` (`ssp_it_service_code`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='One product per row';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES
(1,'EdelMarke','','2026-09-26 16:19:42',9994,0,92.5069380203515,2,1,'A-609261_261011-153531','2','SO','n/a'),
(2,'Lenovo','','2026-09-26 16:24:20',7774,0,444,2,1,'A-609261_260929-110914','2','SO','n/a'),
(3,'Foo','','2026-09-28 16:13:36',0,0,98,2,1,'A-609261_260930-073255','2','SO','n/a'),
(4,'Foo','','2026-09-28 16:13:39',9996,0,699,2,1,'A-609261','2','SO','n/a'),
(5,'Foo','','2026-09-28 16:16:31',9997,0,102.785486689279,2,1,'A-609261_261008-142839','2','SO','n/a'),
(6,'FooMarke','','2026-09-28 16:16:32',9986,0,308.048103607771,2,1,'A-609261_261001-113537','2','SO','n/a'),
(7,'Lenotest','','2026-09-28 16:16:32',7,0,699.352451433857,2,1,'A-609261_261001-113354','2','SO','n/a'),
(8,'Lenovo','','2026-09-28 16:16:33',9997,0,51.3927433446397,2,1,'A-609261-261','2','SO','n/a'),
(9,'Test-Lenovo','','2026-10-25 11:51:22',99,1,91.581868640148,2,1,'A13610251-25122','2','SO','n/a'),
(10,'TEST','','2026-10-27 13:44:39',888,1,924.144310823312,2,1,'A8610271-44439','2','SO','n/a'),
(11,NULL,'','2026-10-28 08:29:37',0,0,0,2,1,'A8610280-92937','2','SO','n/a'),
(12,'Leno','','2026-10-28 08:30:03',0,1,18.5013876040703,2,1,'A8610280-93003','2','SO','n/a');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products2categ`
--

DROP TABLE IF EXISTS `products2categ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `products2categ` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` mediumint(8) unsigned NOT NULL COMMENT 'foreign key',
  `cat_id` smallint(5) unsigned NOT NULL,
  `instime` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `prod_id_cat_id` (`product_id`,`cat_id`),
  KEY `fkey` (`product_id`)
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products2categ`
--

LOCK TABLES `products2categ` WRITE;
/*!40000 ALTER TABLE `products2categ` DISABLE KEYS */;
INSERT INTO `products2categ` VALUES
(16,9,13,'2026-10-25 11:51:22'),
(2,2,1,'2026-09-29 08:57:53'),
(3,3,1,'2026-09-29 08:58:00'),
(4,4,1,'2026-09-29 08:58:05'),
(17,10,8,'2026-10-27 13:44:39'),
(6,6,1,'2026-09-29 08:58:44'),
(7,7,1,'2026-09-29 08:58:46'),
(8,8,1,'2026-09-29 08:58:49'),
(13,5,1,'2026-10-08 12:28:39'),
(15,1,8,'2026-10-11 13:35:31'),
(14,1,1,'2026-10-11 13:35:31'),
(18,11,8,'2026-10-28 08:29:37'),
(26,12,14,'2026-11-05 12:31:12'),
(25,12,8,'2026-11-05 12:31:12'),
(22,8,16,'2026-10-28 13:12:59'),
(23,8,0,'2026-10-28 13:12:59'),
(24,6,13,'2026-10-28 13:53:03');
/*!40000 ALTER TABLE `products2categ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products_desc`
--

DROP TABLE IF EXISTS `products_desc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `products_desc` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` mediumint(8) unsigned NOT NULL COMMENT 'foreign key',
  `instime` timestamp NOT NULL DEFAULT current_timestamp(),
  `lang` char(3) NOT NULL DEFAULT 'de',
  `title` char(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '* Product Title *' COMMENT '08Jan2026: zu utf8mb4',
  `description` varchar(2047) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `desc_long` varchar(8191) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'Desc at Detail View',
  PRIMARY KEY (`id`),
  UNIQUE KEY `fkey` (`product_id`,`lang`)
) ENGINE=MyISAM AUTO_INCREMENT=57 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products_desc`
--

LOCK TABLES `products_desc` WRITE;
/*!40000 ALTER TABLE `products_desc` DISABLE KEYS */;
INSERT INTO `products_desc` VALUES
(1,1,'2026-09-28 16:04:22','de','Lenovo NB TP T14s 2-in-1 G1 U7 32GB RAM','Schlankex Ultrabook mit brillantem Display, ganztägiger Akkulaufzeit und flüsterleisem Betrieb. Ideal für Büro, Studium und unterwegs. Generalüberholt und geprüft.','<b>Das Lenovo NB TP T14s 2-in-1 G1 überzeugt mit leistungsstarkem Intel-Prozessor und 32 GB RAM, was ein flüssiges Multitasking ermöglicht.</b><br><br>Das flexible 2-in-1-Design bietet die Möglichkeit, das Gerät sowohl als Laptop als auch als Tablet zu nutzen. Mit hochwertigem Display und robuster Bauweise ist es ideal für Beruf und Freizeit.'),
(2,2,'2026-09-26 16:44:02','de','Xenovo Z3 TWR G2 U9 128 GB/1 TB SBO','Beschreibung von HP Z3 TWR G2 U9 128 GB/1 TB SBO','Beschreibung von HP Z3 TWR G2 U9 128 GB/1 TB SBO.<br><br>\r\n\r\nSchlankex Ultrabook mit brillantem Display, ganztägiger Akkulaufzeit und flüsterleisem Betrieb. Ideal für Büro, Studium und unterwegs. Generalüberholt und geprüft.'),
(3,3,'2026-09-28 16:14:35','de','AUSERVERKAUFT TC M70q Gen 6 U5 32GB RAM','Aktive Geräuschunterdrückung, bis zu 30 Stunden Akkulaufzeit und satter Klang für Musik, Podcasts und Calls.','Aktive Geräuschunterdrückung, bis zu 30 Stunden Akkulaufzeit und satter Klang für Musik, Podcasts und Calls. tbd'),
(4,4,'2026-02-16 13:37:45','de','Opt-Lenovo ThinkVision T24-40 Monitor','Gestochen scharfes 4K-HDR-Bild, integriertes Smart-TV-System und schlankes Design für dein Wohnzimmer.','<p>Gestochen scharfes 4K-HDR-Bild, integriertes Smart-TV-System und schlankes Design für dein Wohnzimmer.</p><p>Weiterer text.&nbsp;Weiterer text.&nbsp;Weiterer text.&nbsp;Weiterer text.&nbsp;Weiterer text.&nbsp;Weiterer text.&nbsp;Weiterer text.&nbsp;Weiterer text.&nbsp;Weiterer text.&nbsp;Weiterer text.&nbsp;Weiterer text.&nbsp;Weiterer text.&nbsp;Weiterer text.&nbsp;Weiterer text.&nbsp;Weiterer text.&nbsp;Weiterer text.&nbsp;Weiterer text.&nbsp;Weiterer text.&nbsp;Weiterer text.&nbsp;Weiterer text.&nbsp;Weiterer text.&nbsp;Weiterer text.&nbsp;Weiterer text.&nbsp;Weiterer text.&nbsp;</p>'),
(5,5,'2026-02-16 13:55:01','de','Lenovo ThinkPad Universal TBT 4 Dock','Beschreibung von Lenovo ThinkPad Universal TBT 4 Dock','Ext 4567709-40'),
(6,6,'2026-02-16 13:58:30','de','Lenovo ThinkVision T34WD-40 Monitor','Der Lenovo ThinkVision T34WD-40 ist ein beeindruckender 34-Zoll-Ultrawide-Monitor mit QHD-Auflösung und einem Seitenverhältnis von 21:9. Er bietet hervorragende Farbgenauigkeit und breite Betrachtungswinkel, ideal für kreative Profis und Multitasking. Mit USB-C-Anschluss, integrierten Lautsprechern und ergonomischem Design ermöglicht er komfortables Arbeiten und erstklassigen visuellen Genuss in jedem Arbeitsumfeld.','<b>Der Lenovo ThinkVision T34WD-40 ist ein beeindruckender 34-Zoll-Ultrawide-Monitor mit QHD-Auflösung und einem Seitenverhältnis von 21:9.</b><br><br>Er bietet hervorragende Farbgenauigkeit und breite Betrachtungswinkel, ideal für kreative Profis und Multitasking. Mit USB-C-Anschluss, integrierten Lautsprechern und ergonomischem Design ermöglicht er komfortables Arbeiten und erstklassigen visuellen Genuss in jedem Arbeitsumfeld.'),
(7,7,'2026-02-16 13:58:30','de','Robi Tobi','eeeeeee asdf','Ext 4710074-40'),
(8,8,'2026-02-16 13:58:30','de','Lenovo ThinkVision T27Q-40 Monitor','Der Lenovo ThinkVision T27Q-40 ist ein leistungsstarker 27-Zoll-Monitor mit 4K UHD-Auflösung, der brillante Bildqualität und präzise Farben bietet. Dank IPS-Technologie und einer großzügigen Farbpalette eignet er sich ideal für kreative Aufgaben. Vielfältige Anschlussmöglichkeiten und ergonomisches Design sorgen für eine optimale User-Erfahrung, während die integrierte Eye-Care-Technologie die Augengesundheit schützt','<b>Der Lenovo ThinkVision T27Q-40 ist ein leistungsstarker 27-Zoll-Monitor mit 4K UHD-Auflösung, der brillante Bildqualität und präzise Farben bietet.</b><br><br>Dank IPS-Technologie und einer großzügigen Farbpalette eignet er sich ideal für kreative Aufgaben. Vielfältige Anschlussmöglichkeiten und ergonomisches Design sorgen für eine optimale User-Erfahrung, während die integrierte Eye-Care-Technologie die Augengesundheit schützt.'),
(9,9,'2026-02-16 14:03:03','de','Lenovo Tempered Glass für TP X12 G2','Ext 4955680','<b>Das Lenovo Tempered Glass für das TP X12 G2 bietet optimalen Schutz für Ihr Tablet-Display.</b><br><br>Mit einer robusten, kratzfesten Oberfläche gewährleistet es Sicherheit vor Stößen und Schlägen. Die ultradünne Bauweise ermöglicht eine brillante Farbwiedergabe und präzise Touch-Reaktion. Einfach zu installieren, sorgt es für eine langlebige Klarheit und bewahrt die Bildqualität Ihres Geräts.'),
(10,10,'2026-02-16 14:03:03','de','PRO-Zone Smartcard Wired Tastatur II o.Bild','Ext 4908549-40','Ext 4908549-40'),
(11,11,'2026-02-16 14:03:03','de','Lenovo Essential USB Maus','Ext 4254294','Ext 4254294'),
(12,12,'2026-02-16 14:03:03','de','Leno Case für irgendwas','Ext 4955674','Ext 4955674'),
(13,13,'2026-02-16 14:03:03','de','Lenovo ThinkPad 35,6cm (14\") SchutzhÃ¼lle','Ext 4174547','Ext 4174547'),
(14,14,'2026-02-16 14:03:03','de','Lenovo Essential USB Tastatur schwarz','Ext 4883228-40','Ext 4883228-40'),
(15,15,'2026-02-16 14:03:03','de','Lenovo Yoga Pen Eingabestift schwarz','Ext 200514392','Ext 200514392'),
(16,16,'2026-02-16 14:03:03','de','Lenovo Pro Wireless Tastatur + Maus Set','Ext 4921945-40','Ext 4921945-40'),
(17,17,'2026-02-16 14:03:03','de','ARTICONA GRS 43,9 cm (17,3\") Tasche sw.','Ext 4661354','Ext 4661354'),
(18,18,'2026-02-16 14:03:03','de','Lenovo Go Wireless USB-C Maus schwarz','Ext 4599189','Ext 4599189'),
(19,19,'2026-02-16 14:03:03','de','Lenovo ThinkVision MC60 Monitor Webcam','Ext 4672388','Ext 4672388'),
(20,20,'2026-02-16 14:03:03','de','Lenovo 65 W USB-C Standard Netzteil','Ext 4148454-40','Ext 4148454-40'),
(21,21,'2026-02-16 14:03:03','de','Lenovo Professional Funktastatur grau','Ext 4939103-40','Ext 4939103-40'),
(22,22,'2026-02-16 14:03:03','de','Lenovo ThinkPad 39,6 cm (15,6\") HÃ¼lle','Ext 4174549','Ext 4174549'),
(23,23,'2026-02-16 14:03:03','de','Lenovo Performance FHD Webcam','Ext 4597664','Ext 4597664'),
(24,24,'2026-02-16 14:03:03','de','Lenovo ThinkPad 100 W USB-C Netzteil','Ext 4787423-40','Ext 4787423-40'),
(25,25,'2026-02-16 14:03:03','de','ARTICONA DisplayPort - HDMI Adapter','Ext 4102500','Ext 4102500'),
(26,2,'2026-09-29 09:09:14','fr','','',NULL),
(27,2,'2026-09-29 09:09:14','en','tbd en','',NULL),
(28,3,'2026-09-30 05:32:55','fr','Lenovo Desktop TC M70q Gen 6 U5 32GB RAM','',NULL),
(29,3,'2026-09-30 05:32:55','en','Lenovo Desktop TC M70q Gen 6 U5 32GB RAM','',NULL),
(30,8,'2026-10-01 09:32:22','fr','Lenovo ThinkVision T27Q-40 Monitor','Der Lenovo ThinkVision T27Q-40 ist ein leistungsstarker 27-Zoll-Monitor mit 4K UHD-Auflösung, der brillante Bildqualität und präzise Farben bietet. Dank IPS-Technologie und einer großzügigen Farbpalette eignet er sich ideal für kreative Aufgaben. Vielfältige Anschlussmöglichkeiten und ergonomisches Design sorgen für eine optimale User-Erfahrung, während die integrierte Eye-Care-Technologie die Augengesundheit schützt',NULL),
(31,8,'2026-10-01 09:32:22','en','Lenovo ThinkVision T27Q-40 Monitor','Der Lenovo ThinkVision T27Q-40 ist ein leistungsstarker 27-Zoll-Monitor mit 4K UHD-Auflösung, der brillante Bildqualität und präzise Farben bietet. Dank IPS-Technologie und einer großzügigen Farbpalette eignet er sich ideal für kreative Aufgaben. Vielfältige Anschlussmöglichkeiten und ergonomisches Design sorgen für eine optimale User-Erfahrung, während die integrierte Eye-Care-Technologie die Augengesundheit schützt',NULL),
(32,7,'2026-10-01 09:33:54','fr','Lenovo ThinkVision T27Q-40 Monitor','',NULL),
(33,7,'2026-10-01 09:33:54','en','Lenovo ThinkVision T27Q-40 Monitor','',NULL),
(34,6,'2026-10-01 09:35:37','fr','','',NULL),
(35,6,'2026-10-01 09:35:37','en','','',NULL),
(39,5,'2026-10-08 12:28:39','fr','','',NULL),
(40,5,'2026-10-08 12:28:39','en','','',NULL),
(41,1,'2026-10-11 13:35:31','fr','','',NULL),
(42,1,'2026-10-11 13:35:31','en','','',NULL),
(43,9,'2026-10-25 11:51:22','fr','* Titel *','* Titel *','* Titel *'),
(44,9,'2026-10-25 11:51:22','en','* Titel *','* Titel *','* Titel *'),
(45,4,'2026-10-26 07:30:24','fr','','',NULL),
(46,4,'2026-10-26 07:30:24','en','','',NULL),
(47,10,'2026-10-27 13:44:39','fr','* Titel *','* Titel *','* Titel *'),
(48,10,'2026-10-27 13:44:39','en','* Titel *','* Titel *','* Titel *'),
(49,11,'2026-10-28 08:29:37','fr','* Titel *','* Titel *','* Titel *'),
(50,11,'2026-10-28 08:29:37','en','* Titel *','* Titel *','* Titel *'),
(51,12,'2026-10-28 08:30:03','fr','* Titel *','* Titel *','* Titel *'),
(52,12,'2026-10-28 08:30:03','en','* Titel *','* Titel *','* Titel *');
/*!40000 ALTER TABLE `products_desc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products_details`
--

DROP TABLE IF EXISTS `products_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `products_details` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` mediumint(8) unsigned NOT NULL COMMENT 'foreign key',
  `dtype` tinyint(4) NOT NULL DEFAULT 1,
  `instime` timestamp NOT NULL DEFAULT current_timestamp(),
  `detkey` char(63) DEFAULT NULL,
  `val` char(255) DEFAULT NULL,
  `uid` mediumint(8) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `prodid_detkey` (`product_id`,`detkey`),
  KEY `indx` (`product_id`),
  KEY `detkey` (`detkey`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products_details`
--

LOCK TABLES `products_details` WRITE;
/*!40000 ALTER TABLE `products_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `products_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products_discount`
--

DROP TABLE IF EXISTS `products_discount`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `products_discount` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` mediumint(8) unsigned NOT NULL COMMENT 'foreign key',
  `instime` timestamp NOT NULL DEFAULT current_timestamp(),
  `discount` double NOT NULL DEFAULT 0,
  `status` smallint(6) NOT NULL DEFAULT 2 COMMENT '1=active, 2=inactive',
  `description` varchar(511) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `fkey` (`product_id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products_discount`
--

LOCK TABLES `products_discount` WRITE;
/*!40000 ALTER TABLE `products_discount` DISABLE KEYS */;
INSERT INTO `products_discount` VALUES
(1,2,'2026-09-28 20:14:35',24,1,''),
(2,3,'2026-10-01 09:17:32',8.16326530612245,1,'N407071-22: By_UID=1'),
(3,7,'2026-10-01 09:35:01',7.40740740740741,1,'N407071-22: By_UID=1'),
(4,6,'2026-10-01 09:35:37',9.90990990990991,1,'N407071-22: By_UID=1'),
(5,8,'2026-10-08 12:28:04',10,1,'N407071-22: By_UID=1'),
(6,5,'2026-10-08 12:28:48',10,1,'N407071-22: By_UID=1'),
(7,1,'2026-10-28 14:05:10',10,1,'N407071-22: By_UID=1'),
(8,10,'2026-10-28 14:19:02',0.1001001001001,1,'N407071-22: By_UID=1');
/*!40000 ALTER TABLE `products_discount` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products_feat`
--

DROP TABLE IF EXISTS `products_feat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `products_feat` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` mediumint(8) unsigned NOT NULL COMMENT 'foreign key',
  `instime` timestamp NOT NULL DEFAULT current_timestamp(),
  `featname` char(31) NOT NULL,
  `featkey` char(31) DEFAULT NULL,
  `lang` char(3) NOT NULL DEFAULT 'de',
  `weight` smallint(6) NOT NULL DEFAULT 0 COMMENT 'Could contain negative numbers',
  `description` char(63) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT '-',
  `numval` mediumint(8) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `indx` (`product_id`,`lang`),
  KEY `featkey` (`featkey`),
  KEY `description` (`description`),
  KEY `product_id` (`product_id`),
  KEY `numval` (`numval`)
) ENGINE=MyISAM AUTO_INCREMENT=113 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products_feat`
--

LOCK TABLES `products_feat` WRITE;
/*!40000 ALTER TABLE `products_feat` DISABLE KEYS */;
INSERT INTO `products_feat` VALUES
(1,9,'2026-02-16 14:03:03','_exclude','EDI_SKIP','de',-1,'0',0),
(2,9,'2026-02-16 14:03:03','ART_NO','Art-Nr.','de',1,'Bechtle Art-Nr. 4955680',NULL),
(3,10,'2026-02-16 14:03:03','_exclude','EDI_SKIP','de',-1,'0',0),
(4,10,'2026-02-16 14:03:03','ART_NO','Art-Nr.','de',1,'Bechtle Art-Nr. 4908549-40',NULL),
(5,11,'2026-02-16 14:03:03','_exclude','EDI_SKIP','de',-1,'0',0),
(6,11,'2026-02-16 14:03:03','ART_NO','Art-Nr.','de',1,'Bechtle Art-Nr. 4254294',NULL),
(7,12,'2026-02-16 14:03:03','_exclude','EDI_SKIP','de',-1,'0',0),
(8,12,'2026-02-16 14:03:03','ART_NO','Art-Nr.','de',1,'Bechtle Art-Nr. 4955674',NULL),
(9,13,'2026-02-16 14:03:03','_exclude','EDI_SKIP','de',-1,'0',0),
(10,13,'2026-02-16 14:03:03','ART_NO','Art-Nr.','de',1,'Bechtle Art-Nr. 4174547',NULL),
(11,14,'2026-02-16 14:03:03','_exclude','EDI_SKIP','de',-1,'0',0),
(12,14,'2026-02-16 14:03:03','ART_NO','Art-Nr.','de',1,'Bechtle Art-Nr. 4883228-40',NULL),
(13,15,'2026-02-16 14:03:03','_exclude','EDI_SKIP','de',-1,'0',0),
(14,15,'2026-02-16 14:03:03','ART_NO','Art-Nr.','de',1,'Bechtle Art-Nr. 200514392',NULL),
(15,16,'2026-02-16 14:03:03','_exclude','EDI_SKIP','de',-1,'0',0),
(16,16,'2026-02-16 14:03:03','ART_NO','Art-Nr.','de',1,'Bechtle Art-Nr. 4921945-40',NULL),
(17,17,'2026-02-16 14:03:03','_exclude','EDI_SKIP','de',-1,'0',0),
(18,17,'2026-02-16 14:03:03','ART_NO','Art-Nr.','de',1,'Bechtle Art-Nr. 4661354',NULL),
(19,18,'2026-02-16 14:03:03','_exclude','EDI_SKIP','de',-1,'0',0),
(20,18,'2026-02-16 14:03:03','ART_NO','Art-Nr.','de',1,'Bechtle Art-Nr. 4599189',NULL),
(21,19,'2026-02-16 14:03:03','_exclude','EDI_SKIP','de',-1,'0',0),
(22,19,'2026-02-16 14:03:03','ART_NO','Art-Nr.','de',1,'Bechtle Art-Nr. 4672388',NULL),
(23,20,'2026-02-16 14:03:03','_exclude','EDI_SKIP','de',-1,'0',0),
(24,20,'2026-02-16 14:03:03','ART_NO','Art-Nr.','de',1,'Bechtle Art-Nr. 4148454-40',NULL),
(25,21,'2026-02-16 14:03:03','_exclude','EDI_SKIP','de',-1,'0',0),
(26,21,'2026-02-16 14:03:03','ART_NO','Art-Nr.','de',1,'Bechtle Art-Nr. 4939103-40',NULL),
(27,22,'2026-02-16 14:03:03','_exclude','EDI_SKIP','de',-1,'0',0),
(28,22,'2026-02-16 14:03:03','ART_NO','Art-Nr.','de',1,'Bechtle Art-Nr. 4174549',NULL),
(29,23,'2026-02-16 14:03:03','_exclude','EDI_SKIP','de',-1,'0',0),
(30,23,'2026-02-16 14:03:03','ART_NO','Art-Nr.','de',1,'Bechtle Art-Nr. 4597664',NULL),
(31,24,'2026-02-16 14:03:03','_exclude','EDI_SKIP','de',-1,'0',0),
(32,24,'2026-02-16 14:03:03','ART_NO','Art-Nr.','de',1,'Bechtle Art-Nr. 4787423-40',NULL),
(33,25,'2026-02-16 14:03:03','_exclude','EDI_SKIP','de',-1,'0',0),
(34,25,'2026-02-16 14:03:03','ART_NO','Art-Nr.','de',1,'Bechtle Art-Nr. 4102500',NULL),
(43,1,'2026-09-30 09:03:15','_exclude','EXCLUDE609301125','de',-1,'tbd',NULL),
(36,2,'2026-09-29 14:10:46','_image','20260929-161046','SYS',0,'jpg',NULL),
(37,2,'2026-09-29 16:01:04','_image','20260929-180104','SYS',0,'jpg',NULL),
(44,1,'2026-10-01 12:26:00','BKSIT','IT','de',0,'asdf xx',NULL),
(45,1,'2026-10-01 12:26:00','IT','IT','en',0,'asdf xx',NULL),
(46,1,'2026-10-01 12:26:00','IT','IT','fr',0,'asdf xx',NULL),
(47,7,'2026-10-04 12:55:21','BKSIT','IT','de',0,'tbd ee',NULL),
(48,7,'2026-10-04 12:55:21','IT','IT','en',0,'tbd',NULL),
(49,7,'2026-10-04 12:55:21','IT','IT','fr',0,'tbd',NULL),
(50,3,'2026-10-01 11:29:56','BKSIT','IT','de',0,'asdf',NULL),
(51,3,'2026-10-01 11:29:56','IT','IT','en',0,'asdf',NULL),
(52,3,'2026-10-01 11:29:56','IT','IT','fr',0,'asdf',NULL),
(53,4,'2026-10-01 11:36:17','BKSIT','IT','de',0,'asdf xx',NULL),
(54,4,'2026-10-01 11:36:17','IT','IT','en',0,'asdf xx',NULL),
(55,4,'2026-10-01 11:36:17','IT','IT','fr',0,'asdf xx',NULL),
(56,1,'2026-10-01 11:49:03','Prozessor','CPU','de',0,'AMD 1234',NULL),
(57,1,'2026-10-01 11:49:03','Processor','CPU','en',0,'AMD 1234',NULL),
(58,1,'2026-10-01 11:49:03','Processeur','CPU','fr',0,'AMD 1234',NULL),
(59,1,'2026-10-01 12:00:42','_exclude','EXCLUDE609301125','en',0,'tbd',NULL),
(60,1,'2026-10-01 12:00:42','_exclude','EXCLUDE609301125','fr',0,'tbd',NULL),
(61,2,'2026-10-01 12:03:52','Prozessor','CPU','de',0,'AMD 321',NULL),
(62,2,'2026-10-01 12:03:52','Processor','CPU','en',0,'AMD 321',NULL),
(63,2,'2026-10-01 12:03:52','Processeur','CPU','fr',0,'AMD 321',NULL),
(71,6,'2026-10-01 12:28:30','IT','IT','fr',0,'sdfg',NULL),
(70,6,'2026-10-01 12:28:30','IT','IT','en',0,'sdfg',NULL),
(69,6,'2026-10-01 12:28:30','BKSIT','IT','de',0,'sdfg',NULL),
(95,10,'2026-10-27 13:44:39','Pflichtauswahl fehlt: {{WHAT}}','E310151-1','de',0,'-',NULL),
(94,9,'2026-10-27 13:43:05','* _exclude *','EDI_SKIP','en',-1,'0',0),
(72,7,'2026-10-01 13:04:39','_image','20261001-150438','SYS',0,'jpg',NULL),
(73,3,'2026-10-01 13:42:42','_image','20261001-154242','SYS',0,'jpg',NULL),
(74,6,'2026-10-01 15:04:07','_image','20261001-170407','SYS',0,'jpg',NULL),
(103,11,'2026-10-28 08:29:37','_exclude','EDI_SKIP','de',-1,'0',0),
(102,11,'2026-10-28 08:29:37','Pflichtauswahl fehlt: {{WHAT}}','E310151-1','de',0,'-',NULL),
(78,5,'2026-10-08 12:07:07','Prozessor','CPU','de',0,'drucker cpu',NULL),
(79,5,'2026-10-08 12:07:07','Processor','CPU','en',0,'drucker cpu',NULL),
(80,5,'2026-10-08 12:07:07','Processeur','CPU','fr',0,'drucker cpu',NULL),
(84,4,'2026-10-14 07:55:50','_image','20261014-095550','SYS',0,'jpg',NULL),
(85,4,'2026-10-14 07:57:40','_image','20261014-095740','SYS',0,'jpg',NULL),
(96,10,'2026-10-27 13:44:39','_exclude','EDI_SKIP','de',-1,'0',0),
(93,9,'2026-10-27 13:43:05','* _exclude *','EDI_SKIP','fr',-1,'0',0),
(88,9,'2026-10-25 11:51:43','* ART_NO *','Art-Nr.','fr',1,'Bechtle Art-Nr. 4955680',NULL),
(89,9,'2026-10-25 11:51:43','* ART_NO *','Art-Nr.','en',1,'Bechtle Art-Nr. 4955680',NULL),
(90,4,'2026-10-26 07:30:05','','_o1','de',0,'-',NULL),
(91,9,'2026-10-27 12:15:58','Pflichtauswahl fehlt: {{WHAT}}','E310151-1','en',0,'-',NULL),
(92,9,'2026-10-27 12:15:58','Pflichtauswahl fehlt: {{WHAT}}','E310151-1','fr',0,'-',NULL),
(97,10,'2026-10-27 13:45:28','* _exclude *','EDI_SKIP','fr',-1,'0',0),
(98,10,'2026-10-27 13:45:28','* _exclude *','EDI_SKIP','en',-1,'0',0),
(99,10,'2026-10-27 13:45:28','* ART_NO *','Art-Nr.','fr',1,'Bechtle Art-Nr. 4908549-40',NULL),
(100,10,'2026-10-27 13:45:28','* ART_NO *','Art-Nr.','en',1,'Bechtle Art-Nr. 4908549-40',NULL),
(101,9,'2026-10-27 14:05:48','','_o1','de',0,'-',NULL),
(104,12,'2026-10-28 08:30:03','Pflichtauswahl fehlt: {{WHAT}}','E310151-1','de',0,'-',NULL),
(105,12,'2026-10-28 08:30:03','_exclude','EDI_SKIP','de',-1,'0',0),
(106,12,'2026-10-28 08:30:29','* _exclude *','EDI_SKIP','fr',-1,'0',0),
(107,12,'2026-10-28 08:30:29','* _exclude *','EDI_SKIP','en',-1,'0',0),
(108,12,'2026-10-28 08:30:29','* ART_NO *','Art-Nr.','fr',1,'Bechtle Art-Nr. 4955674',NULL),
(109,12,'2026-10-28 08:30:29','* ART_NO *','Art-Nr.','en',1,'Bechtle Art-Nr. 4955674',NULL),
(110,1,'2026-10-28 14:28:21','Schnack','SCHNICK','de',0,'asdf',NULL),
(111,1,'2026-10-28 14:28:21','Schnack en','SCHNICK','en',0,'asdf',NULL),
(112,1,'2026-10-28 14:28:21','Schnack fr','SCHNICK','fr',0,'asdf',NULL);
/*!40000 ALTER TABLE `products_feat` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`apache`@`%`*/ /*!50003 TRIGGER `t_bi_products_feat` BEFORE INSERT ON `products_feat` FOR EACH ROW BEGIN
  IF NEW.description REGEXP '^[0-9]+$' THEN
    SET NEW.numval = CAST(NEW.description AS UNSIGNED);
  ELSE
    SET NEW.numval = NULL;
  END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`apache`@`%`*/ /*!50003 TRIGGER `t_bu_products_feat` BEFORE UPDATE ON `products_feat` FOR EACH ROW BEGIN
  IF NEW.description REGEXP '^[0-9]+$' THEN
    SET NEW.numval = CAST(NEW.description AS UNSIGNED);
  ELSE
    SET NEW.numval = NULL;
  END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `promo_prods`
--

DROP TABLE IF EXISTS `promo_prods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `promo_prods` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT COMMENT 'pkey',
  `instime` timestamp NOT NULL DEFAULT current_timestamp(),
  `product_id` mediumint(8) unsigned NOT NULL COMMENT 'foreign key',
  `weight` int(11) NOT NULL DEFAULT 50,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `promo_prods`
--

LOCK TABLES `promo_prods` WRITE;
/*!40000 ALTER TABLE `promo_prods` DISABLE KEYS */;
INSERT INTO `promo_prods` VALUES
(1,'2026-10-01 06:21:14',1,25,-1),
(2,'2026-10-01 06:26:04',2,25,-1),
(3,'2026-10-01 06:28:01',3,25,-1),
(4,'2026-10-01 06:28:04',4,25,-1),
(10,'2026-10-08 12:08:09',5,75,-1),
(6,'2026-10-01 06:28:16',6,25,-1),
(12,'2026-11-05 12:22:48',12,75,1),
(8,'2026-10-01 06:28:23',8,25,-1);
/*!40000 ALTER TABLE `promo_prods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `properties`
--

DROP TABLE IF EXISTS `properties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `properties` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `tstamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `page` char(63) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL COMMENT 'STYLE:=font-family:Consolas; color:black; background-color:#f0f0f0;',
  `key` char(63) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL COMMENT 'STYLE := background-color:lightyellow; font-weight:bold; letter-spacing:1px',
  `val` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'STYLE:=font-family:Consolas; color:black;',
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_page` (`key`,`page`)
) ENGINE=MyISAM AUTO_INCREMENT=141 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='REM:=Konfiguration || EXT_TOP:=_foo.html || EXT_BOTTOM:=Prismado';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `properties`
--

LOCK TABLES `properties` WRITE;
/*!40000 ALTER TABLE `properties` DISABLE KEYS */;
INSERT INTO `properties` VALUES
(1,'2026-10-27 07:57:21','_global','site_company_de','Demo Shop 2026 Dev'),
(2,'2025-02-27 22:43:02','_global','your_login_de','Ihre Zugangsdaten'),
(5,'2025-03-03 15:55:35','_global','password_de','Passwort'),
(4,'2025-03-03 15:54:53','_global','username_de','Benutzername'),
(6,'2025-09-26 05:47:33','_global','closing_greeting_de','FÃ¼r die Entwicklungsplattform steht kein Support zur VerfÃ¼gung.<br><br>\r\n\r\nFreundliche GrÃ¼sse / Kind regards,<br><br>\r\n\r\n<b>Entwicklungsumgebung.</b><br>\r\n<small>im Auftrag der ACME Ltd</small>'),
(7,'2025-03-03 15:56:40','_global','contact_adress_de','SSG<br>\r\nDottikon'),
(8,'2025-03-09 20:58:29','_global','mail_order_time_de','Bestellzeit'),
(9,'2025-03-09 21:07:46','_global','site_addr_de','Test-Strasse 123 A'),
(10,'2025-03-09 21:07:46','_global','site_zip_de','1234'),
(11,'2025-03-09 21:07:46','_global','site_city_de','Dottikon'),
(12,'2025-03-03 15:56:40','_global','mail_inquiries_text_de','tbd<br>'),
(13,'2026-10-27 07:57:35','_global','site_email_de','algonetic@ch-shop.ch'),
(14,'2025-03-09 21:15:17','_global','slogan_de','Test-System'),
(15,'2025-03-03 15:56:40','_global','mail_payment_method_de','Zahlungsmethode'),
(16,'2025-03-03 15:55:35','_global','email_de','E-Mail'),
(17,'2025-03-03 15:56:40','_global','mail_cust_nr_de','Kundennummer'),
(18,'2025-03-03 15:55:35','_global','invoice_de','Rechnung'),
(19,'2025-03-03 15:55:35','_global','vat_de','MwSt.'),
(20,'2025-03-03 15:55:35','_global','deliv_addr_de','Lieferadresse'),
(21,'2025-03-03 15:56:02','_global','mail_salutation_man_de','Sehr geehrter Herr'),
(22,'2025-03-03 15:56:40','_global','mail_order_thanks_de','Vielen Dank fÃ¼r Ihre Bestellung!'),
(23,'2025-03-03 15:56:40','_global','mail_order_nr_de','Bestellnummer'),
(26,'2025-03-13 16:08:13','_global','phone_de','Telefon'),
(27,'2026-11-09 09:30:43','_global','account_info_subject_de','( ) Ihre Kontoinformationen haben sich geändert'),
(28,'2025-04-01 06:25:02','_global','has_table_product_details_sys','1'),
(29,'2026-09-29 10:03:17','_global','cfg_upload_path_pic_sys','produkte'),
(30,'2025-10-16 09:48:58','_global','user_depts_sys','{\n	\"departments\": [\n	{\n		\"id\": 1,\n		\"code\": \"1-BKS\",\n		\"desc2\": \"zzzzzzzzz\",\n		\"description\": \"\",\n		\"name\": \"D&#233;partement Bildung, Kultur + Sport XX\"\n	},\n	{\n		\"id\": 2,\n		\"code\": \"2-DFR\",\n		\"description\": \"desc zwei asdf\",\n		\"name\": \"Departement Finanzen und Ressourcen ooo asdf xyzu\"\n	},\n	{\n		\"id\": 3,\n		\"code\": \"3-BVU\",\n		\"description\": \"\",\n		\"name\": \"Departement Bau, Verkehr und Umwelt\"\n	},\n	{\n		\"id\": 4,\n		\"code\": \"4-DVIAWA\",\n		\"description\": \"Amt f&#252;r Wirtsch&#224;ft &#252;. Arbeit\",\n		\"name\": \"Departement Volkswirtschaft u Inneres / DVI AWA\"\n	},\n	{\n		\"id\": 5,\n		\"code\": \"5-DVIGES\",\n		\"description\": \"Generalsekretariat DVI GES\",\n		\"name\": \"Departement Volkswirtschaft u Inneres / DVI GES\"\n	},\n	{\n		\"id\": 6,\n		\"code\": \"6-DVIKAPO\",\n		\"description\": \"Kant&#244;nspolizeieieiei\",\n		\"name\": \"Departement Volkswirtschaft u Inneres / DVI KAPO\"\n	},\n	{\n		\"id\": 7,\n		\"code\": \"7-DGS\",\n		\"description\": \"DGS\",\n		\"name\": \"Departement Gesundheit und Soziales\"\n	},\n	{\n		\"id\": 8,\n		\"code\": \"8-SK\",\n		\"description\": \"\",\n		\"name\": \"Staatskanzlei-ei\"\n	},\n	{\n		\"id\": 9,\n		\"code\": \"9-GR\",\n		\"description\": \"\",\n		\"name\": \"Staatskanzlei / Grossrat\"\n	},\n	{\n		\"id\": 10,\n		\"code\": \"10-GKA\",\n		\"description\": \"\",\n		\"name\": \"Gerichte Kt. Aargau m. subcats\"\n	},\n	{\n		\"id\": 11,\n		\"code\": \"11-ELF\",\n		\"desc2\": \"Die Elf\",\n		\"description\": \"tbd\",\n		\"name\": \"Die neue Elf\"\n	},\n	{\n		\"id\": 12,\n		\"code\": \"12-ZWLF\",\n		\"desc2\": \"Neu\",\n		\"description\": \"Zw&#246;lf\",\n		\"name\": \"tbd\"\n	},\n	{\n		\"id\": 13,\n		\"code\": \"13-DRZN\",\n		\"desc2\": \"Dreizehn\",\n		\"description\": \"tbd\",\n		\"name\": \"Dreizehn asdf\"\n	},\n	{\n		\"id\": 14,\n		\"code\": \"14-VRZN\",\n		\"desc2\": \"Vierzehn\",\n		\"description\": \"tbd 14\",\n		\"name\": \"GKA-ZEHN (14)\"\n	},\n	{\n		\"id\": 15,\n		\"code\": \"15-NEU\",\n		\"desc2\": \"Neu\",\n		\"description\": \"Neu\",\n		\"name\": \"Neu\"\n	}\n	],\n	\"metadata\" :{\n		\"version\":     \"1.2 / Stammdaten_KTAG\",\n		\"lastUpdated\": \"2025-10-16 11:48:58\",\n		\"totalCount\":  \"15\"\n	}\n}'),
(31,'2025-07-09 13:20:24','_global','prod_types_sys','{\r\n  \"prod_types\": [\r\n    {\r\n      \"id\": 1,\r\n      \"name\": \"PRE-PROV\",\r\n      \"code\": \"01-INF\",\r\n      \"description\": \"Pre-provisioning mÃ¶glich\"\r\n    },\r\n    {\r\n      \"id\": 2,\r\n      \"name\": \"NO PRE-PROV\",\r\n      \"code\": \"02-MKT\",\r\n      \"description\": \"Kein Pre-provisioning mÃ¶glich / ZubehÃ¶r\"\r\n    },\r\n    {\r\n      \"id\": 3,\r\n      \"name\": \"tbd drei\",\r\n      \"code\": \"03-HR\",\r\n      \"description\": \"tbd\"\r\n    }\r\n  ],\r\n  \"metadata\": {\r\n    \"version\": \"1.0\",\r\n    \"lastUpdated\": \"2025-07-09\",\r\n    \"totalCount\": 3\r\n  }\r\n}'),
(32,'2025-07-18 08:53:37','_global','cfg_extra_service_1_sys','{\r\n  \"prod_id\": 177,\r\n  \"sku\": \"abcd\"\r\n}'),
(33,'2026-02-16 20:10:16','_global','cfg_bill_codes_sys','{\n	\"billing_addresses\": [\n	{\n		\"id\": 1,\n		\"code\": \"9001323250\",\n		\"description\": \"Zentrale Rechnungsstelle (ZRS)\",\n		\"grouptag\": \"BKS\",\n		\"name\": \"Dep. Bildung, Kültur und Sport\"\n	},\n	{\n		\"id\": 2,\n		\"code\": \"9001323248\",\n		\"description\": \"Zentrale Rechnungsstelle (ZRS), Generalsekretariat\",\n		\"grouptag\": \"GKA\",\n		\"name\": \"Gerichte Kanton Aargau\"\n	},\n	{\n		\"id\": 3,\n		\"code\": \"9001330896\",\n		\"description\": \"Zentrale Rechnungsstelle (ZRS), Tellistrasse 67\",\n		\"grouptag\": \"DFR\",\n		\"name\": \"Dep. Finanzen und Ressourcen usw.\"\n	},\n	{\n		\"id\": 4,\n		\"code\": \"9000884176\",\n		\"description\": \"Zentrale Rechnungsstelle (ZRS)\",\n		\"grouptag\": \"BVU\",\n		\"name\": \"Dep. Bau, Verkehr und Umwelt\"\n	},\n	{\n		\"id\": 5,\n		\"code\": \"9001342487\",\n		\"description\": \"Zentrale Rechnungsstelle (ZRS)\",\n		\"grouptag\": \"DVIAWA\",\n		\"name\": \"Dép. Völkswirtschaft u Inneres, Arbeit (Aarau)\"\n	},\n	{\n		\"id\": 6,\n		\"code\": \"9001342487\",\n		\"description\": \"Kantonspolizei Aargau, Länzert 10, Schafisheim\",\n		\"grouptag\": \"DVIKAPO\",\n		\"name\": \"D&#233;p. Völkswirtschaft u. Inneres (Kantonspolizei Aargau)\"\n	},\n	{\n		\"id\": 7,\n		\"code\": \"9000883979\",\n		\"description\": \"Zentrale Rechnungsstelle (ZRS)\",\n		\"grouptag\": \"DVIGES\",\n		\"name\": \"Dep. Gesundheit und Soziales\"\n	},\n	{\n		\"id\": 8,\n		\"code\": \"9001364952\",\n		\"description\": \"Zentrale Rechnungsstelle (ZRS)\",\n		\"grouptag\": \"SK\",\n		\"name\": \"Staatskanzlei\"\n	},\n	{\n		\"id\": 9,\n		\"code\": \"9000350090\",\n		\"description\": \"des Kantons Aargau\",\n		\"grouptag\": \"BVU\",\n		\"name\": \"Strassenverkehrsamt\"\n	},\n	{\n		\"id\": 10,\n		\"code\": \"9001539974\",\n		\"description\": \"Schulpsychologischer Dienst, Niederlenzer Kirchweg 4\",\n		\"grouptag\": \"BKS\",\n		\"name\": \"Dep. Bildung, Kultur und Sport (Lenzburg)\"\n	},\n	{\n		\"id\": 11,\n		\"code\": \"9001579723\",\n		\"description\": \"Schulpsychologischer Dienst, Dammstrasse 3\",\n		\"grouptag\": \"BKS\",\n		\"name\": \"Dept. Bildung Kultur und Sport (Frick)\"\n	},\n	{\n		\"id\": 12,\n		\"code\": \"9998887776\",\n		\"description\": \"Neuer Test\",\n		\"grouptag\": \"TBD\",\n		\"name\": \"Test neu asdf\"\n	}\n	],\n	\"metadata\" :{\n		\"version\":     \"1.2001 / Stammdaten_KTAG\",\n		\"lastUpdated\": \"2026-02-16 21:10:16\",\n		\"totalCount\":  \"12\"\n	}\n}'),
(41,'2026-01-21 12:54:25','_global','cfg_delivery_addresses_sys','{\n	\"delivery_addresses\": [\n	{\n		\"id\": 1,\n		\"city\": \"Zaarauu\",\n		\"company\": \"Gerichte kanton Aargau\",\n		\"dept\": \"Die GerÃ¼chte, GENERAL-sekretariÃ¤t\",\n		\"dept_2\": \"Informatik\",\n		\"email\": \"servicedesk.gka@ag.ch\",\n		\"it_service_code\": \"GKA\",\n		\"name\": \"Silvan HÃ¤chler\",\n		\"remarks\": \"AEW Hochhaus 3. Stocky\",\n		\"street\": \"Obere Vorstadt 40\",\n		\"zip\": \"5000\"\n	},\n	{\n		\"id\": 2,\n		\"city\": \"Unt&#233;rentfeldÃ¤nn\",\n		\"company\": \"Kanton Aargau\",\n		\"dept\": \"Amt fÃ¼r Verbraucherschutz\",\n		\"dept_2\": \"Informatik\",\n		\"email\": \"michael.wyder@ag.ch\",\n		\"it_service_code\": \"DGS\",\n		\"name\": \"Michael Wyder\",\n		\"remarks\": \"\",\n		\"street\": \"MÃ¶nchmattweg 6\",\n		\"zip\": \"5035\"\n	},\n	{\n		\"id\": 9,\n		\"city\": \"Aarau\",\n		\"company\": \"Kanton Aargau\",\n		\"dept\": \"Departement Bildung, Kultur und Sport\",\n		\"dept_2\": \"Informatik\",\n		\"email\": \"fernando.machado@ag.ch\",\n		\"it_service_code\": \"BKS\",\n		\"name\": \"Fernando Machado\",\n		\"remarks\": \"\",\n		\"street\": \"Bachstrasse 15\",\n		\"zip\": \"5002\"\n	},\n	{\n		\"id\": 19,\n		\"city\": \"Aarau\",\n		\"company\": \"Kanton Aargau\",\n		\"dept\": \"Generalsekretariat\",\n		\"dept_2\": \"Informatik\",\n		\"email\": \"ralph.zinniker@ag.ch\",\n		\"it_service_code\": \"DGS\",\n		\"name\": \"RÃ¤lph Zinnik&#233;r\",\n		\"remarks\": \"\",\n		\"street\": \"Bachstrasse 15\",\n		\"zip\": \"5000\"\n	},\n	{\n		\"id\": 20,\n		\"city\": \"Aarau\",\n		\"company\": \"Kanton Aargau\",\n		\"dept\": \"Informatik Aargau / ITSC-CC / 23.OG (Raum 23.6)\",\n		\"dept_2\": \"\",\n		\"email\": \"stefan.steimer@ag.ch\",\n		\"it_service_code\": \"DFR\",\n		\"name\": \"Stefan Steimer\",\n		\"remarks\": \"\",\n		\"street\": \"Tellistrasse 67\",\n		\"zip\": \"5000\"\n	},\n	{\n		\"id\": 21,\n		\"city\": \"Unterentfelden\",\n		\"company\": \"Kanton Aargau\",\n		\"dept\": \"Informatik Aargau / ITSC-CC / 3.OG (ITD)\",\n		\"dept_2\": \"\",\n		\"email\": \"stefan.steimer@ag.ch\",\n		\"it_service_code\": \"DFR\",\n		\"name\": \"Stefan Steimer\",\n		\"remarks\": \"\",\n		\"street\": \"Suhrenmattstrasse 48\",\n		\"zip\": \"5035\"\n	},\n	{\n		\"id\": 22,\n		\"city\": \"Aarau\",\n		\"company\": \"Kanton Aargau\",\n		\"dept\": \"Kantonaler Sozialdienst\",\n		\"dept_2\": \"Informatik\",\n		\"email\": \"jay.helfer@ag.ch\",\n		\"it_service_code\": \"DGS\",\n		\"name\": \"Jay Helfer\",\n		\"remarks\": \"\",\n		\"street\": \"Obere Vorstadt 3\",\n		\"zip\": \"5000\"\n	},\n	{\n		\"id\": 23,\n		\"city\": \"Gr&#228;nichen\",\n		\"company\": \"Kanton Aargau\",\n		\"dept\": \"Landwirtschaftliches Zentrum Liebegg\",\n		\"dept_2\": \"\",\n		\"email\": \"christoph.biner@ag.ch; stefan.steimer@ag.ch\",\n		\"it_service_code\": \"DFR\",\n		\"name\": \"Christoph Biner\",\n		\"remarks\": \"\",\n		\"street\": \"Liebegg 1\",\n		\"zip\": \"5722\"\n	},\n	{\n		\"id\": 24,\n		\"city\": \"Aarau\",\n		\"company\": \"Kanton Aargau\",\n		\"dept\": \"MilitÃ¤r und B&#233;vÃ¶lk&#232;rungsschutzzz\",\n		\"dept_2\": \"Informatik\",\n		\"email\": \"hans.anneler@ag.ch\",\n		\"it_service_code\": \"DGS\",\n		\"name\": \"Hans Anneler\",\n		\"remarks\": \"\",\n		\"street\": \"Rohrerstrasse 7\",\n		\"zip\": \"5000\"\n	},\n	{\n		\"id\": 25,\n		\"city\": \"Aarau\",\n		\"company\": \"Kanton Aargau\",\n		\"dept\": \"StaatskÃ¤nzlei-Ei AargaÃ¼\",\n		\"dept_2\": \"Regierungsgebaude, Informatikdienst\",\n		\"email\": \"informatikdienst.sk@ag.ch\",\n		\"it_service_code\": \"SK\",\n		\"name\": \"Roberto Ransini\",\n		\"remarks\": \"FÃ¼r C1-Infrastruktur\",\n		\"street\": \"Bahnhofstrasse 2\",\n		\"zip\": \"5001\"\n	},\n	{\n		\"id\": 26,\n		\"city\": \"Aarau\",\n		\"company\": \"Kanton Aargau\",\n		\"dept\": \"Staatskanzlei Aargau\",\n		\"dept_2\": \"Regierungsgebaude, Informatikdienst\",\n		\"email\": \"informatikdienst.sk@ag.ch\",\n		\"it_service_code\": \"GR\",\n		\"name\": \"Roberto Ransini\",\n		\"remarks\": \"F&#252;r C8-Infrastruktur\",\n		\"street\": \"Bahnhofstrasse 2\",\n		\"zip\": \"5001\"\n	},\n	{\n		\"id\": 27,\n		\"city\": \"Aarau\",\n		\"company\": \"Kanton Aargau\",\n		\"dept\": \"Statistik Aargau\",\n		\"dept_2\": \"\",\n		\"email\": \"philipp.imhof@ag.ch; stefan.steimer@ag.ch\",\n		\"it_service_code\": \"DFR\",\n		\"name\": \"Philipp Imhof\",\n		\"remarks\": \"\",\n		\"street\": \"Laurenzenvorstadt 9\",\n		\"zip\": \"5000\"\n	},\n	{\n		\"id\": 28,\n		\"city\": \"Schafisheim\",\n		\"company\": \"Kantonspolizei Aargau\",\n		\"dept\": \"Kantonspolizei, Dept. Volkswirtschaft und Inneres\",\n		\"dept_2\": \"Service Desk\",\n		\"email\": \"stefan.pedrossi@kapo.ag.ch\",\n		\"it_service_code\": \"DVI-KAPO-IT\",\n		\"name\": \"Stefan Pedrossi\",\n		\"remarks\": \"\",\n		\"street\": \"LÃ¤nzert 10\",\n		\"zip\": \"5503\"\n	},\n	{\n		\"id\": 29,\n		\"city\": \"Dottikon\",\n		\"company\": \"Test - Swiss Solution Group\",\n		\"dept\": \"SSP\",\n		\"dept_2\": \"\",\n		\"email\": \"rs@algonetic.com\",\n		\"it_service_code\": \"AA Test\",\n		\"name\": \"RS\",\n		\"remarks\": \"Test\",\n		\"street\": \"Bahnhofstrasse 66\",\n		\"zip\": \"5605\"\n	},\n	{\n		\"id\": 30,\n		\"city\": \"Z&#252;rich\",\n		\"company\": \"ALGO\",\n		\"dept\": \"DPX eeeeee\",\n		\"dept_2\": \"\",\n		\"email\": \"\",\n		\"it_service_code\": \"I-S-C\",\n		\"name\": \"ACME Ltd\",\n		\"remarks\": \"Neu\",\n		\"street\": \"-\",\n		\"zip\": \"8001\"\n	},\n	{\n		\"id\": 31,\n		\"city\": \"Z&#252;rich\",\n		\"company\": \"Neuuuuuuuuuuuuu\",\n		\"dept\": \"Neu\",\n		\"dept_2\": \"Neu\",\n		\"email\": \"Neu\",\n		\"it_service_code\": \"Neu\",\n		\"name\": \"Neu\",\n		\"remarks\": \"Neu\",\n		\"street\": \"Neu\",\n		\"zip\": \"Neu\"\n	},\n	{\n		\"id\": 32,\n		\"city\": \"ZÃ¼rich\",\n		\"company\": \"Neu GmbH\",\n		\"dept\": \"DVI AWA\",\n		\"dept_2\": \"Zwei-Detail\",\n		\"email\": \"Neu\",\n		\"it_service_code\": \"DVI-AWA-IT\",\n		\"name\": \"Amt fÃ¼r Arbeit\",\n		\"remarks\": \"\",\n		\"street\": \"\",\n		\"zip\": \"8001\"\n	},\n	{\n		\"id\": 33,\n		\"city\": \"Aargau\",\n		\"company\": \"tbd\",\n		\"dept\": \"DVI-GES\",\n		\"dept_2\": \"\",\n		\"email\": \"Neu@example.ch\",\n		\"it_service_code\": \"DVI-GES-IT\",\n		\"name\": \"dvi ges \",\n		\"remarks\": \"\",\n		\"street\": \"\",\n		\"zip\": \"5001\"\n	}\n	],\n	\"metadata\" :{\n		\"version\":     \"1.2001 / Stammdaten_KTAG\",\n		\"lastUpdated\": \"2026-01-21 13:54:25\",\n		\"totalCount\":  \"18\"\n	}\n}'),
(47,'2025-08-06 15:41:33','_global','prod_meta_AG_PREPROV_sys','{\r\n    \"details\": {\r\n	\"Classification\": \"anderes\",\r\n	\"Classification_all\": \"Notebook, Desktop, Tablet, Monitor, Monitor Dock, Dockingstation, Smart Dock, anderes\",\r\n	\"MANUFACTMAT\": \"AG_PREPROV\",\r\n	\"MainImageURL\": \"/assets/images/products/sku_AG_PREPROV.png\"\r\n    }\r\n}'),
(48,'2026-02-16 14:03:03','_global','prod_meta_4254294_sys','{\n	\"details\": \n	{\n		\"Classification\": \"anderes\",\n		\"LEADTIME\": \"20\",\n		\"MANUFACTCODE\": \"Lenovo\",\n		\"MANUFACTMAT\": \"4Y50R20863\",\n		\"MATGROUP\": \"19130190\",\n		\"MainImageURL\": \"\",\n		\"QUANTITY\": \"1.000\",\n		\"x_RamSize\": \"\"\n	}\n	,\n	\"metadata\": {\n		\"version\": \"1.1\",\n		\"elem_count\": \"1\",\n		\"created\": \"2026-02-16 15:03:03\",\n		\"lastUpdate\": \"2026-02-16 15:03:03\"\n	}\n}'),
(50,'2025-08-13 12:39:18','_global','cancel_order_text_de','Ihre Bestellung wurde storniert.\r\n<br><br>'),
(51,'2025-08-19 15:45:23','_core','40225183_mail_cc_sys','dev@eshop.pub'),
(52,'2026-02-16 14:03:03','_global','prod_meta_4599189_sys','{\n	\"details\": \n	{\n		\"Classification\": \"anderes\",\n		\"LEADTIME\": \"20\",\n		\"MANUFACTCODE\": \"Lenovo\",\n		\"MANUFACTMAT\": \"4Y51C21216\",\n		\"MATGROUP\": \"19130190\",\n		\"MainImageURL\": \"\",\n		\"QUANTITY\": \"1.000\",\n		\"x_RamSize\": \"\"\n	}\n	,\n	\"metadata\": {\n		\"version\": \"1.1\",\n		\"elem_count\": \"1\",\n		\"created\": \"2026-02-16 15:03:03\",\n		\"lastUpdate\": \"2026-02-16 15:03:03\"\n	}\n}'),
(138,'2026-11-09 10:04:21','_global','site_website_de','http://localhost/'),
(139,'2026-11-10 10:27:49','_global','google_conv_tracking_head_sys','<!-- Google Tag Manager -->\r\n<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({\'gtm.start\':\r\nnew Date().getTime(),event:\'gtm.js\'});var f=d.getElementsByTagName(s)[0],\r\nj=d.createElement(s),dl=l!=\'dataLayer\'?\'&l=\'+l:\'\';j.async=true;j.src=\r\n\'https://www.googletagmanager.com/gtm.js?id=\'+i+dl;f.parentNode.insertBefore(j,f);\r\n})(window,document,\'script\',\'dataLayer\',\'GTM-WWR8TCPC\');</script>\r\n<!-- End Google Tag Manager -->'),
(140,'2026-11-10 10:21:05','_global','google_conv_tracking_on_sys','1'),
(71,'2025-10-05 13:47:47','_global','label_{X_ART_NO}_de','Artikelnummer'),
(72,'2025-10-05 19:04:52','_global','label_{PRE_PROV}_de','Pre-prov. tbd'),
(75,'2025-10-19 10:47:34','_global','prod_meta_SSG-BECHTLE_sys','{\n	\"details\": {\n		\"Classification\": \"anderes\",\n		\"Classification_all\": \"Notebook, Desktop, Tablet, Monitor, Monitor Dock, Dockingstation, Smart Dock, anderes\",\n		\"MANUFACTMAT\": \"tbd\",\n		\"MainImageURL\": \"\"\n	}\n}'),
(137,'2026-11-08 17:13:14','_macro','macro_prism_sys_jobs_sys','<macro id=\"402051\" version=\"2\"\r\n	auth_req = \"admin\"\r\n	created  = \"25Feb2024\"\r\n	type     = \"DataTable\">\r\n\r\n<title lang=\"de\">Prismado System Jobs</title>\r\n\r\n<item url=\"\" icon=\"adx/assets/images/logo/prism_icon_cogs.svg\">\r\n	<label lang=\"de\">Automatisierte Abl&amp;auml;ufe / System-Jobs</label>\r\n	<desc  lang=\"breadcrumb_de\">\r\n		[Konfiguration] := /adx/config-dev.html ||\r\n		[System Jobs]   := show.html?macro=prism_sys_jobs\r\n	</desc>\r\n	<desc  lang=\"header_macro\">	header_adm_sys_jobs	</desc>\r\n	<desc  lang=\"body_macro\">	body_adm_sys_jobs	</desc>\r\n\r\n	<sub_item>\r\n	<label lang=\"db_cols\">		id SUBSTR(featkey,10,63) featname Null NULL		</label>\r\n	<label lang=\"db_cols_de\">	Job-ID || Name || Job File || Period. || Zustand	</label>\r\n	<label lang=\"wcl\">		lang=\'sys\' and featkey LIKE \'job\\_path\\_%\'		</label>\r\n	<label lang=\"wcl_filter\">	featkey LIKE \'%{{search}}%\'				</label>\r\n\r\n	<!-- label lang=\"wcl_filter\">label LIKE \'%{{search}}%\'</label -->\r\n	<label lang=\"source\">config_prod_feat</label>\r\n\r\n	<label lang=\"db_edit\">		/adx-26/job.html?id=133		</label>\r\n	<label lang=\"db_col_id_conv\">\r\n	qq~&lt;a class=\"text-dark\" href=\"/adx-26/job.html?id=$val\">&lt;i class=\"fi fi-pencil\"&gt;&lt;/i&gt; $val&lt;/a&gt;~\r\n	</label>\r\n\r\n	<label lang=\"db_col_Null_conv\">\r\n		$val=$C-&gt;squery(q~\r\n			select featname from config_prod_feat\r\n			where featkey=\'job_detail_~ . $r-&gt;[0] . q~__runs_every\'\r\n			limit 1~, $C-&gt;{dbh})-&gt;[0] . \' Min\'\r\n	</label>\r\n\r\n	<label lang=\"db_col_NULL_conv\">\r\n		$val=$C-&gt;squery(q~\r\n			select featname from config_prod_feat\r\n			where featkey=\'job_detail_~ . $r-&gt;[0] . q~__is_active\'\r\n			limit 1~, $C-&gt;{dbh})-&gt;[0]; $val = $val ? \'&lt;b&gt;Active&lt;/b&gt;\' : \'Inact.\';\r\n	</label>\r\n\r\n	<label lang=\"db_col_SUBSTR(featkey,10,63)_class\">	fs--18 font-weight-bold		</label>\r\n	<label lang=\"db_col_Null_css\">				text-align:right;		</label>\r\n	<label lang=\"db_col_NULL_class\">			float-end			</label>\r\n\r\n	</sub_item>\r\n</item>\r\n</macro>'),
(134,'2026-11-06 06:04:00','_global','site_phone_de','+41 99 888 77 66'),
(135,'2026-11-06 06:05:11','_global','site_twitter_de','algonetic'),
(136,'2026-11-06 07:17:52','_global','delivery_legal_note_de','Bei einer allfälligen Retoure bitten wir Sie unbedingt dengeführten Retourenprozess in Ihrem Kundenkonto zu nutzen.\r\n\r\nBestellungen unterliegen den AGB der Swiss Solution Group AG.\r\n\r\nBei Fragen oder Unklarheiten steht der Kundendienst gerne zur Verfügung: https://www.auctionline.ch/contact.html'),
(133,'2026-11-06 06:02:25','_macro','macro_master_data_sys','<macro id=\"402051\" version=\"2\"\r\n	auth_req = \"admin\"\r\n	created  = \"06Mar2024\"\r\n	type     = \"DataTablx\">\r\n\r\n<title lang=\"de\">Master-Daten</title>\r\n\r\n<item url=\"\">\r\n	<label lang=\"de\">		Hauptdaten aktualisieren	</label>\r\n	<desc  lang=\"body_macro\">	body_adm_masterdata		</desc>\r\n\r\n	<desc  lang=\"breadcrumb_de\">\r\n		[Allg.]   := /adx/config.html ||\r\n		[Inhalte] := /adx/content.html\r\n	</desc>\r\n\r\n	<sub_item>\r\n	<label lang=\"db_cols\">id parent_id visible weight label extra_label</label>\r\n	<label lang=\"wcl\">lang=\'de\'</label>\r\n	<label lang=\"wcl_filter\">label LIKE \'%{{search}}%\'</label>\r\n	<label lang=\"source\">categories</label>\r\n\r\n	<label lang=\"db_edit\">(STD)</label>\r\n	</sub_item>\r\n\r\n</item>\r\n</macro>'),
(129,'2026-10-28 13:13:37','_global','_categ_desc_16_de','* [adx-26/categ] _categ_desc_16 (de) *'),
(130,'2026-10-28 14:28:00','_global','label_{SCHNICK}_de','Schnack'),
(131,'2026-10-28 14:28:00','_global','label_{SCHNICK}_en','Schnack en'),
(132,'2026-10-28 14:28:00','_global','label_{SCHNICK}_fr','Schnack fr'),
(128,'2026-10-26 09:04:39','custom/algonetic/html/info_agb','content_de','tbd<br><br>\r\n\r\nagbs asdf äöü'),
(82,'2025-11-22 07:57:55','_global','prod_meta_4890109_sys','{\r\n	\"details\": \r\n	{\r\n		\"Classification\": \"anderes\",\r\n		\"LEADTIME\": \"3\",\r\n		\"MANUFACTCODE\": \"Apple\",\r\n		\"MANUFACTMAT\": \"MD4A4TY/A\",\r\n		\"MATGROUP\": \"19010201\",\r\n		\"QUANTITY\": \"3.000\",\r\n		\"gugus\": \"dada\"\r\n	}\r\n	,\r\n	\"metadata\": {\r\n		\"version\": \"1.1\",\r\n		\"elem_count\": \"1\",\r\n		\"created\": \"2025-11-22 08:57:55\",\r\n		\"lastUpdate\": \"2025-11-22 08:57:55\"\r\n	}\r\n}'),
(85,'2025-11-22 11:19:53','_global','qqqprod_meta_4940914-40_sys','{\r\n	\"details\": \r\n	{\r\n		\"Classification\": \"anderes\",\r\n		\"LEADTIME\": \"3\",\r\n		\"MANUFACTCODE\": \"Lenovo\",\r\n		\"MANUFACTMAT\": \"21Q8000CMZ\",\r\n		\"MATGROUP\": \"19010290\",\r\n		\"MainImageURL\": \"\",\r\n		\"QUANTITY\": \"1.000\"\r\n	}\r\n	,\r\n	\"metadata\": {\r\n		\"version\": \"1.1\",\r\n		\"elem_count\": \"1\",\r\n		\"created\": \"2025-11-22 12:19:53\",\r\n		\"lastUpdate\": \"2025-11-22 12:19:53\"\r\n	}\r\n}'),
(124,'2026-10-08 14:47:13','_global','product_promo_header_de','tbd asdf'),
(125,'2026-10-08 15:24:59','_global','product_promo_header_image_url_de','https://placehold.co/450x250/d8d8d8/a8a8a8?text=Teaser-Bild'),
(126,'2026-10-08 15:26:25','_global','product_promo_header_title_de','Aktuell.'),
(127,'2026-10-08 15:24:59','_global','product_promo_header_text_de','Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.<br><br>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.'),
(89,'2025-12-04 10:46:39','_global','prod_meta_4852985_sys','{\n	\"details\": \n	{\n		\"Classification\": \"Notebook\",\n		\"LEADTIME\": \"3\",\n		\"MANUFACTCODE\": \"Microsoft \",\n		\"MANUFACTMAT\": \"EP2-14782\",\n		\"MATGROUP\": \"19010201\",\n		\"MainImageURL\": \"/assets/images/products/sku_EP2-14782.jpg\",\n		\"QUANTITY\": \"2.000\",\n		\"x_CpuClockFrequency\": \"33345\",\n		\"x_CpuType\": \"Intel asdf xx\",\n		\"x_HdSize\": \"9999 GB\",\n		\"x_RamSize\": \"33 GB\"\n	}\n	,\n	\"metadata\": {\n		\"version\": \"1.1\",\n		\"elem_count\": \"1\",\n		\"created\": \"2025-12-04 11:46:39\",\n		\"lastUpdate\": \"2025-12-04 11:46:39\"\n	}\n}'),
(118,'2026-10-01 11:48:17','_global','label_{CPU}_en','Processor'),
(119,'2026-10-01 11:48:17','_global','label_{CPU}_fr','Processeur'),
(120,'2026-10-01 12:25:04','_global','delete_de','Löschen'),
(121,'2026-10-08 08:02:03','_global','_categ_desc_14_de','* [adx-26/categ] _categ_desc_14 (de) *'),
(122,'2026-10-08 08:24:39','_global','_categ_desc_15_de','* [adx-26/categ] _categ_desc_15 (de) *'),
(123,'2026-10-08 11:58:04','_global','_categ_desc_6_de','* [adx-26/categ] _categ_desc_6 (de) *'),
(115,'2026-10-01 10:21:05','_ai','prompt_product_desc_de','Schreibe eine Kurzbeschreibung fuer das Produkt {{TITLE}} in {{WORD_COUNT}} Woertern auf {{LANG}}'),
(116,'2026-10-01 10:21:33','_ai','prompt_product_desc_word_count_sys','55'),
(117,'2026-10-01 11:48:17','_global','label_{CPU}_de','Prozessor'),
(112,'2026-09-29 08:49:11','_macro','macro_products_sys','<macro id=\"402051\" version=\"2\" auth_req=\"admin\" type=\"DataTable\"\r\n	created = \"07Feb2024\">\r\n<title lang=\"de\">Produkte</title>\r\n\r\n<item url=\"\" icon=\"adx/assets/images/logo/prism_icon_products_2.svg\">\r\n	<label lang=\"de\">Produktekatalog</label>\r\n	<desc  lang=\"css\">\r\n		&lt;link rel=\"stylesheet\" href=\"/adx/assets/css/prism_datatables_1_10_color_lime_2.css\"&gt;\r\n	</desc>\r\n	<desc  lang=\"header_macro\">	header_products	</desc> <!-- custom/algonetic/macros/_foo.html -->\r\n	<desc  lang=\"body_macro\">	body_adm_products		</desc>\r\n	<desc  lang=\"breadcrumb_de\">\r\n		[Promotionen] := /adx/show.html?macro=promos ||\r\n		[Teaser]      := /adm_teaser.html            ||\r\n		[Produkte]    := /adx/products.html\r\n	</desc>\r\n	<sub_item>\r\n	<label lang=\"db_cols\">		id NULL brand title art_no price `count` cat_id extra instime `condition`	</label>\r\n	<label lang=\"db_cols_de\">\r\n		Prod-ID || Bild || Marke || Modell || Art-Nr. || Preis || Stk. || Kateg.-ID || Zustand || Erstellt || condition\r\n	</label>\r\n	<label lang=\"wcl\">		lang=\'de\' AND `condition` != \'IP\'						</label>\r\n	<label lang=\"wcl_filter\">	title LIKE \'%{{search}}%\'							</label>\r\n	<label lang=\"source\">		vproducts									</label>\r\n	<label lang=\"page_size\">	15										</label>\r\n\r\n	<label lang=\"db_col_NULL_conv\">\r\n		qq~&lt;img style=\"width:3.3vw; height:3.3vh; object-fit:cover; box-shadow: 7px 7px 4px #888888;\"\r\n			src=\"/produkte/p$r->[0]_thmb.jpg\"&gt;~;\r\n	</label>\r\n	<label lang=\"db_col_price_css\">\r\n		text-align:right !important; font-weight:bold; padding-right:30px !important; color:#515151\r\n	</label>\r\n	<label lang=\"db_col_price_conv\">	\"$val &lt;small&gt;CHF&lt;/small&gt;\"	</label>\r\n	<label lang=\"db_col_extra_conv\">\r\n		$val = $val==1 ? \'&lt;span class=\"badge badge-danger w-100\"&gt;NEU&lt;/span&gt;\' : \'Refurb.\'\r\n	</label>\r\n\r\n	<label lang=\"db_col_title_conv\">	$C->web_enc_v2($val); $val = $C->shorten_title($val, 42);	</label>\r\n	<label lang=\"db_col_title_class\">	font-weight-bold						</label>\r\n	<label lang=\"db_col_`count`_conv\">	\"$val / $r->[10]\"						</label>\r\n\r\n	<label lang=\"db_col_art_no_class\">	fs--13 badge badge-soft badge-secondary w--150			</label>\r\n	<label lang=\"db_col_`count`_css\">\r\n		text-align:right !important; padding-right:25px !important; font-size:0.75rem\r\n	</label>\r\n	<label lang=\"db_col_instime_css\">	text-align:right !important; padding-right:15px !important	</label>\r\n	<label lang=\"db_col_cat_id_href\">	adm_categ.html?id={{cat_id}}					</label>\r\n	<label lang=\"db_col_cat_id_css\">	text-align:right !important; padding-right:30px !important	</label>\r\n	<label lang=\"db_col_id_css\">		text-align:center;	</label>\r\n\r\n	<label lang=\"db_edit\">		adm_edit_product.html?id={{id}}				</label> <!-- \"(STD)\" / ... -->\r\n	<label lang=\"db_col_id_conv\">\r\n	qq~&lt;a class=\"text-dark\" href=\"/adm_edit_product.html?id=$val\">&lt;i class=\"fi fi-pencil\"&gt;&lt;/i&gt; $val&lt;/a&gt;~\r\n	</label>\r\n\r\n	<label lang=\"db_col_`condition`_omit\">1</label>\r\n	</sub_item>\r\n</item>\r\n</macro>'),
(95,'2025-12-04 21:01:52','_global','prod_meta_1011033_sys','{\r\n	\"details\": {\r\n		\"Classification\": \"anderes\",\r\n		\"Classification_all\": \"Notebook, Desktop, Tablet, Monitor, Monitor Dock, Dockingstation, Smart Dock, anderes\",\r\n		\"MANUFACTMAT\": \"1011033\",\r\n		\"MainImageURL\": \"\"\r\n	}\r\n}'),
(96,'2025-12-12 09:24:52','_global','prod_meta_4779249_sys','{\n	\"details\": \n	{\n		\"Classification\": \"Notebook\",\n		\"LEADTIME\": \"99\",\n		\"MANUFACTCODE\": \"Getac\",\n		\"MANUFACTMAT\": \"USH154VIXKXX\",\n		\"MATGROUP\": \"19010201\",\n		\"MainImageURL\": \"\",\n		\"QUANTITY\": \"1.000\",\n		\"x_RamSize\": \"\"\n	}\n	,\n	\"metadata\": {\n		\"version\": \"1.1\",\n		\"elem_count\": \"1\",\n		\"created\": \"2025-12-12 10:24:52\",\n		\"lastUpdate\": \"2025-12-12 10:24:52\"\n	}\n}'),
(97,'2025-12-12 10:16:09','_global','prod_meta_4133976_sys','{\r\n	\"details\": \r\n	{\r\n		\"Classification\": \"anderes\",\r\n		\"LEADTIME\": \"3\",\r\n		\"MANUFACTCODE\": \"Delock\",\r\n		\"MANUFACTMAT\": \"84821\",\r\n		\"MATGROUP\": \"19059205\",\r\n		\"MainImageURL\": \"\",\r\n		\"QUANTITY\": \"3.000\",\r\n		\"x_RamSize\": \"\"\r\n	}\r\n	,\r\n	\"metadata\": {\r\n		\"version\": \"1.1\",\r\n		\"elem_count\": \"1\",\r\n		\"created\": \"2025-12-12 11:16:09\",\r\n		\"lastUpdate\": \"2025-12-12 11:16:09\"\r\n	}\r\n}'),
(100,'2026-02-16 14:03:03','_global','prod_meta_4174547_sys','{\n	\"details\": \n	{\n		\"Classification\": \"anderes\",\n		\"LEADTIME\": \"20\",\n		\"MANUFACTCODE\": \"Lenovo\",\n		\"MANUFACTMAT\": \"4X40N18009\",\n		\"MATGROUP\": \"24360204\",\n		\"MainImageURL\": \"\",\n		\"QUANTITY\": \"1.000\",\n		\"x_RamSize\": \"\"\n	}\n	,\n	\"metadata\": {\n		\"version\": \"1.1\",\n		\"elem_count\": \"1\",\n		\"created\": \"2026-02-16 15:03:03\",\n		\"lastUpdate\": \"2026-02-16 15:03:03\"\n	}\n}'),
(113,'2026-09-29 10:04:31','_global','cfg_upload_path_doc_sys','produkte/docs'),
(114,'2026-10-01 09:42:47','_macro','macro_help_sys','<macro id=\"402051\" version=\"2\"\r\n	auth_req = \"admin\"\r\n	created  = \"13Jul2024\"\r\n	remarks  = \"tbd\"\r\n	type     = \"DataTable\">\r\n<title lang=\"de\">Online Hilfe</title>\r\n\r\n<item url=\"\">\r\n	<label lang=\"de\">Detailbeschreibung</label>\r\n\r\n	<sub_item>\r\n		<label lang=\"db_cols\">id title_de mnemonic xval_de area sub_area created updated </label>\r\n\r\n		<label lang=\"db_cols_de\">\r\n			ID || Titel || Mnemonic || Beschreibung || Area || Sub Area || Erstellt|| Aktualisiert\r\n		</label>\r\n\r\n		<label lang=\"wcl_filter\">title_de LIKE \'%{{search}}%\' OR xval_de LIKE \'%{{search}}%\' OR mnemonic LIKE \'%{{search}}%\'</label>\r\n\r\n		<label lang=\"source\">help</label>\r\n\r\n		<label lang=\"db_col_title_de_class\">font-weight-bold</label>\r\n		<!-- label lang=\"db_col_tstamp_css\">width:110px</label -->\r\n\r\n		<label lang=\"db_col_created_conv\">	$C->trans_date_short($val);	</label>\r\n		<label lang=\"db_col_updated_conv\">	$C->trans_date_short($val);	</label>\r\n\r\n		<!-- \"(STD)\" / ... -->\r\n		<!-- label lang=\"db_edit\">adm_edit_product.html?id={{id}}</label -->\r\n	</sub_item>\r\n</item>\r\n</macro>'),
(102,'2026-02-16 14:03:03','_global','prod_meta_4955680_sys','{\n	\"details\": \n	{\n		\"Classification\": \"anderes\",\n		\"LEADTIME\": \"20\",\n		\"MANUFACTCODE\": \"Lenovo\",\n		\"MANUFACTMAT\": \"4Z11R33898\",\n		\"MATGROUP\": \"24210501\",\n		\"MainImageURL\": \"\",\n		\"QUANTITY\": \"1.000\",\n		\"x_RamSize\": \"\"\n	}\n	,\n	\"metadata\": {\n		\"version\": \"1.1\",\n		\"elem_count\": \"1\",\n		\"created\": \"2026-02-16 15:03:03\",\n		\"lastUpdate\": \"2026-02-16 15:03:03\"\n	}\n}'),
(103,'2026-02-16 14:03:03','_global','prod_meta_4955674_sys','{\n	\"details\": \n	{\n		\"Classification\": \"anderes\",\n		\"LEADTIME\": \"20\",\n		\"MANUFACTCODE\": \"Lenovo\",\n		\"MANUFACTMAT\": \"4Z71S61312\",\n		\"MATGROUP\": \"24360204\",\n		\"MainImageURL\": \"\",\n		\"QUANTITY\": \"1.000\",\n		\"x_RamSize\": \"\"\n	}\n	,\n	\"metadata\": {\n		\"version\": \"1.1\",\n		\"elem_count\": \"1\",\n		\"created\": \"2026-02-16 15:03:03\",\n		\"lastUpdate\": \"2026-02-16 15:03:03\"\n	}\n}'),
(104,'2026-02-16 14:03:03','_global','prod_meta_200514392_sys','{\n	\"details\": \n	{\n		\"Classification\": \"anderes\",\n		\"LEADTIME\": \"20\",\n		\"MANUFACTCODE\": \"Lenovo\",\n		\"MANUFACTMAT\": \"4X81U29637\",\n		\"MATGROUP\": \"19019190\",\n		\"MainImageURL\": \"\",\n		\"QUANTITY\": \"1.000\",\n		\"x_RamSize\": \"\"\n	}\n	,\n	\"metadata\": {\n		\"version\": \"1.1\",\n		\"elem_count\": \"1\",\n		\"created\": \"2026-02-16 15:03:03\",\n		\"lastUpdate\": \"2026-02-16 15:03:03\"\n	}\n}'),
(105,'2026-02-16 14:03:03','_global','prod_meta_4661354_sys','{\n	\"details\": \n	{\n		\"Classification\": \"anderes\",\n		\"LEADTIME\": \"20\",\n		\"MANUFACTCODE\": \"ARTICONA\",\n		\"MANUFACTMAT\": \"4661354\",\n		\"MATGROUP\": \"24360204\",\n		\"MainImageURL\": \"\",\n		\"QUANTITY\": \"1.000\",\n		\"x_RamSize\": \"\"\n	}\n	,\n	\"metadata\": {\n		\"version\": \"1.1\",\n		\"elem_count\": \"1\",\n		\"created\": \"2026-02-16 15:03:03\",\n		\"lastUpdate\": \"2026-02-16 15:03:03\"\n	}\n}'),
(106,'2026-02-16 14:03:03','_global','prod_meta_4672388_sys','{\n	\"details\": \n	{\n		\"Classification\": \"Monitor\",\n		\"LEADTIME\": \"20\",\n		\"MANUFACTCODE\": \"Lenovo\",\n		\"MANUFACTMAT\": \"4XC1J05150\",\n		\"MATGROUP\": \"19100108\",\n		\"MainImageURL\": \"\",\n		\"QUANTITY\": \"1.000\",\n		\"x_RamSize\": \"\"\n	}\n	,\n	\"metadata\": {\n		\"version\": \"1.1\",\n		\"elem_count\": \"1\",\n		\"created\": \"2026-02-16 15:03:03\",\n		\"lastUpdate\": \"2026-02-16 15:03:03\"\n	}\n}'),
(108,'2026-02-16 14:03:03','_global','prod_meta_4174549_sys','{\n	\"details\": \n	{\n		\"Classification\": \"anderes\",\n		\"LEADTIME\": \"20\",\n		\"MANUFACTCODE\": \"Lenovo\",\n		\"MANUFACTMAT\": \"4X40N18010\",\n		\"MATGROUP\": \"24360204\",\n		\"MainImageURL\": \"\",\n		\"QUANTITY\": \"1.000\",\n		\"x_RamSize\": \"\"\n	}\n	,\n	\"metadata\": {\n		\"version\": \"1.1\",\n		\"elem_count\": \"1\",\n		\"created\": \"2026-02-16 15:03:03\",\n		\"lastUpdate\": \"2026-02-16 15:03:03\"\n	}\n}'),
(109,'2026-02-16 14:03:03','_global','prod_meta_4597664_sys','{\n	\"details\": \n	{\n		\"Classification\": \"anderes\",\n		\"LEADTIME\": \"20\",\n		\"MANUFACTCODE\": \"Lenovo\",\n		\"MANUFACTMAT\": \"4XC1D66055\",\n		\"MATGROUP\": \"19100108\",\n		\"MainImageURL\": \"\",\n		\"QUANTITY\": \"1.000\",\n		\"x_RamSize\": \"\"\n	}\n	,\n	\"metadata\": {\n		\"version\": \"1.1\",\n		\"elem_count\": \"1\",\n		\"created\": \"2026-02-16 15:03:03\",\n		\"lastUpdate\": \"2026-02-16 15:03:03\"\n	}\n}'),
(111,'2026-02-16 14:03:03','_global','prod_meta_4102500_sys','{\n	\"details\": \n	{\n		\"Classification\": \"anderes\",\n		\"LEADTIME\": \"20\",\n		\"MANUFACTCODE\": \"ARTICONA\",\n		\"MANUFACTMAT\": \"4102500\",\n		\"MATGROUP\": \"27069210\",\n		\"MainImageURL\": \"\",\n		\"QUANTITY\": \"1.000\",\n		\"x_RamSize\": \"\"\n	}\n	,\n	\"metadata\": {\n		\"version\": \"1.1\",\n		\"elem_count\": \"1\",\n		\"created\": \"2026-02-16 15:03:03\",\n		\"lastUpdate\": \"2026-02-16 15:03:03\"\n	}\n}');
/*!40000 ALTER TABLE `properties` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `session`
--

DROP TABLE IF EXISTS `session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `session` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sid` int(10) unsigned NOT NULL COMMENT 'Important: INT(10) unsiged',
  `key` char(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `val` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `tstamp` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `key_sid` (`key`,`sid`)
) ENGINE=MyISAM AUTO_INCREMENT=5781 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `session`
--

LOCK TABLES `session` WRITE;
/*!40000 ALTER TABLE `session` DISABLE KEYS */;
INSERT INTO `session` VALUES
(23,2086,'_uid','1','2026-09-26 16:18:48'),
(24,2086,'_stay_logged_in','1','2026-09-26 16:18:48'),
(25,2086,'_uid','1','2026-09-26 16:18:52'),
(26,2086,'_stay_logged_in','1','2026-09-26 16:18:52'),
(157,78,'_uid','1','2026-09-29 05:42:08'),
(158,78,'_stay_logged_in','1','2026-09-29 05:42:08'),
(317,83,'_uid','2','2026-10-01 06:43:21'),
(318,83,'_stay_logged_in','1','2026-10-01 06:43:21'),
(319,83,'_uid','2','2026-10-01 06:43:31'),
(320,83,'_stay_logged_in','1','2026-10-01 06:43:31'),
(2433,107,'_uid','7','2026-10-07 15:02:05'),
(2457,108,'_uid','8','2026-10-07 15:25:43'),
(2517,109,'_uid','9','2026-10-07 15:38:23'),
(2532,110,'_uid','10','2026-10-07 15:41:12'),
(2540,111,'_uid','11','2026-10-07 19:02:30'),
(2682,118,'_rc','3','2026-10-13 11:51:46'),
(2683,118,'_msg','Missing: E-Mail, Last Name<br>Invalid E-Mail: <br>','2026-10-13 11:51:46'),
(2684,118,'_rc','3','2026-10-13 11:51:52'),
(2685,118,'_msg','Missing: E-Mail, Last Name<br>Invalid E-Mail: <br>','2026-10-13 11:51:52'),
(2686,118,'_rc','3','2026-10-13 11:51:57'),
(2687,118,'_msg','Missing: E-Mail, Last Name<br>Invalid E-Mail: <br>','2026-10-13 11:51:57'),
(2688,118,'_rc','3','2026-10-13 11:52:02'),
(2689,118,'_msg','Missing: E-Mail, Last Name<br>Invalid E-Mail: <br>','2026-10-13 11:52:02'),
(2690,118,'_rc','3','2026-10-13 11:52:08'),
(2691,118,'_msg','Missing: E-Mail, Last Name<br>Invalid E-Mail: <br>','2026-10-13 11:52:08'),
(2692,118,'_rc','3','2026-10-13 11:52:13'),
(2693,118,'_msg','Missing: E-Mail, Last Name<br>Invalid E-Mail: <br>','2026-10-13 11:52:13'),
(2694,118,'_rc','3','2026-10-13 11:52:19'),
(2695,118,'_msg','Missing: E-Mail, Last Name<br>Invalid E-Mail: <br>','2026-10-13 11:52:19'),
(2696,118,'_rc','3','2026-10-13 11:52:24'),
(2697,118,'_msg','Missing: E-Mail, Last Name<br>Invalid E-Mail: <br>','2026-10-13 11:52:24'),
(2698,118,'_rc','3','2026-10-13 11:52:30'),
(2699,118,'_msg','Missing: E-Mail, Last Name<br>Invalid E-Mail: <br>','2026-10-13 11:52:30'),
(2700,118,'_rc','3','2026-10-13 11:52:35'),
(2701,118,'_msg','Missing: E-Mail, Last Name<br>Invalid E-Mail: <br>','2026-10-13 11:52:35'),
(2702,118,'_rc','3','2026-10-13 11:52:41'),
(2703,118,'_msg','Missing: E-Mail, Last Name<br>Invalid E-Mail: <br>','2026-10-13 11:52:41'),
(2704,118,'_rc','3','2026-10-13 11:52:47'),
(2705,118,'_msg','Missing: E-Mail, Last Name<br>Invalid E-Mail: <br>','2026-10-13 11:52:47'),
(2706,118,'_rc','0','2026-10-13 12:03:02'),
(2707,118,'_msg','Benutzer UID 12 erstellt.','2026-10-13 12:03:02'),
(2708,118,'_uid','12','2026-10-13 12:03:07'),
(2710,121,'_uid','12','2026-10-14 05:54:18'),
(2712,122,'_rc','0','2026-10-14 05:56:01'),
(2713,122,'_msg','Benutzer UID 13 erstellt.','2026-10-14 05:56:01'),
(2714,122,'_uid','13','2026-10-14 05:56:07'),
(2778,123,'_rc','3','2026-10-14 09:53:18'),
(2779,123,'_msg','Missing: E-Mail, Last Name<br>Invalid E-Mail: <br>','2026-10-14 09:53:18'),
(2780,123,'_rc','3','2026-10-14 09:56:16'),
(2781,123,'_msg','Missing: E-Mail, Last Name<br>Invalid E-Mail: <br>','2026-10-14 09:56:16'),
(2815,78,'_current_lang','de','2026-10-14 13:34:28'),
(2816,78,'_current_lang','de','2026-10-14 13:34:28'),
(2817,78,'_current_lang','de','2026-10-14 13:54:38'),
(2818,78,'_current_lang','de','2026-10-14 13:54:49'),
(2819,78,'_current_lang','de','2026-10-14 13:54:49'),
(2820,78,'_current_lang','de','2026-10-14 14:29:48'),
(2821,78,'_current_lang','de','2026-10-14 14:29:48'),
(2822,78,'_current_lang','de','2026-10-14 14:30:46'),
(2823,78,'_current_lang','de','2026-10-14 14:31:06'),
(2824,78,'_current_lang','de','2026-10-14 14:31:33'),
(2830,78,'_current_lang','de','2026-10-14 14:35:34'),
(2831,78,'_current_lang','de','2026-10-14 14:35:44'),
(2832,78,'_current_lang','de','2026-10-14 14:40:00'),
(2833,0,'_current_lang','de','2026-10-14 14:40:00'),
(3802,2088,'_uid','14','2026-10-20 11:43:48'),
(3805,136,'_uid','15','2026-10-20 11:46:35'),
(3808,137,'_uid','16','2026-10-20 11:50:03'),
(3811,138,'_uid','17','2026-10-20 11:51:59'),
(4383,140,'_uid','18','2026-10-26 10:10:49'),
(4718,141,'_uid','13','2026-10-26 11:21:05'),
(5026,143,'_rc','3','2026-10-26 13:50:00'),
(5027,143,'_msg','Missing: E-Mail, Last Name<br>Invalid E-Mail: <br>','2026-10-26 13:50:00'),
(5028,143,'_rc','3','2026-10-26 13:50:06'),
(5029,143,'_msg','Missing: E-Mail, Last Name<br>Invalid E-Mail: <br>','2026-10-26 13:50:06'),
(5030,143,'_rc','3','2026-10-26 13:50:12'),
(5031,143,'_msg','Missing: E-Mail, Last Name<br>Invalid E-Mail: <br>','2026-10-26 13:50:12'),
(5032,143,'_rc','3','2026-10-26 13:51:37'),
(5033,143,'_msg','Missing: E-Mail, Last Name<br>Invalid E-Mail: <br>','2026-10-26 13:51:37'),
(5034,143,'_rc','3','2026-10-26 13:51:43'),
(5035,143,'_msg','Missing: E-Mail, Last Name<br>Invalid E-Mail: <br>','2026-10-26 13:51:43'),
(5036,143,'_rc','3','2026-10-26 13:51:49'),
(5037,143,'_msg','Missing: E-Mail, Last Name<br>Invalid E-Mail: <br>','2026-10-26 13:51:49'),
(5038,143,'_rc','3','2026-10-26 13:53:49'),
(5039,143,'_msg','Missing: E-Mail, Last Name<br>Invalid E-Mail: <br>','2026-10-26 13:53:49'),
(5040,143,'_rc','3','2026-10-26 13:55:37'),
(5041,143,'_msg','Missing: E-Mail, Last Name<br>Invalid E-Mail: <br>','2026-10-26 13:55:37'),
(5042,143,'_rc','3','2026-10-26 13:55:41'),
(5043,143,'_msg','Missing: E-Mail, Last Name<br>Invalid E-Mail: <br>','2026-10-26 13:55:41'),
(5044,143,'_rc','3','2026-10-26 13:55:46'),
(5045,143,'_msg','Missing: E-Mail, Last Name<br>Invalid E-Mail: <br>','2026-10-26 13:55:46'),
(5046,143,'_rc','3','2026-10-26 13:55:53'),
(5047,143,'_msg','Missing: E-Mail, Last Name<br>Invalid E-Mail: <br>','2026-10-26 13:55:53'),
(5048,143,'_rc','3','2026-10-26 13:55:59'),
(5049,143,'_msg','Missing: E-Mail, Last Name<br>Invalid E-Mail: <br>','2026-10-26 13:55:59'),
(5050,143,'_rc','3','2026-10-26 13:56:35'),
(5051,143,'_msg','Missing: E-Mail, Last Name<br>Invalid E-Mail: <br>','2026-10-26 13:56:35'),
(5052,143,'_rc','3','2026-10-26 13:56:49'),
(5053,143,'_msg','Missing: E-Mail, Last Name<br>Invalid E-Mail: <br>','2026-10-26 13:56:49'),
(5054,143,'_rc','3','2026-10-26 13:56:55'),
(5055,143,'_msg','Missing: E-Mail, Last Name<br>Invalid E-Mail: <br>','2026-10-26 13:56:55'),
(5056,143,'_rc','3','2026-10-26 13:57:30'),
(5057,143,'_msg','Missing: E-Mail, Last Name<br>Invalid E-Mail: <br>','2026-10-26 13:57:30'),
(5058,143,'_rc','3','2026-10-26 13:58:45'),
(5059,143,'_msg','Missing: E-Mail, Last Name<br>Invalid E-Mail: <br>','2026-10-26 13:58:45'),
(5060,143,'_rc','3','2026-10-26 14:01:28'),
(5061,143,'_msg','Missing: E-Mail, Last Name<br>Invalid E-Mail: <br>','2026-10-26 14:01:28'),
(5062,143,'_rc','3','2026-10-26 14:02:43'),
(5063,143,'_msg','Missing: E-Mail, Last Name<br>Invalid E-Mail: <br>','2026-10-26 14:02:43'),
(5064,143,'_rc','0','2026-10-26 14:09:16'),
(5065,143,'_msg','Benutzer UID 19 erstellt.','2026-10-26 14:09:16'),
(5066,143,'_uid','19','2026-10-26 14:09:22'),
(5382,0,'_current_lang','de','2026-10-29 11:54:35'),
(5380,151,'_current_lang','de','2026-10-29 11:54:27'),
(5381,151,'_current_lang','de','2026-10-29 11:54:27'),
(5780,78,'promo_pos','3','2026-11-13 09:24:00');
/*!40000 ALTER TABLE `session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shipping`
--

DROP TABLE IF EXISTS `shipping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `shipping` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'pkey',
  `sale_type_id` smallint(6) NOT NULL COMMENT '3=cod, 4=cc',
  `pay_meth` smallint(6) NOT NULL,
  `amount_net` double NOT NULL,
  `threshold_from` int(11) NOT NULL,
  `comment` varchar(255) NOT NULL,
  `begin_time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `end_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shipping`
--

LOCK TABLES `shipping` WRITE;
/*!40000 ALTER TABLE `shipping` DISABLE KEYS */;
/*!40000 ALTER TABLE `shipping` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sid_seq`
--

DROP TABLE IF EXISTS `sid_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sid_seq` (
  `nextval` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`nextval`)
) ENGINE=MyISAM AUTO_INCREMENT=11205692 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Sequence';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sid_seq`
--

LOCK TABLES `sid_seq` WRITE;
/*!40000 ALTER TABLE `sid_seq` DISABLE KEYS */;
INSERT INTO `sid_seq` VALUES
(156);
/*!40000 ALTER TABLE `sid_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `teaser`
--

DROP TABLE IF EXISTS `teaser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `teaser` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `lang` char(3) NOT NULL DEFAULT 'de',
  `is_active` tinyint(1) DEFAULT 1,
  `weight` smallint(6) DEFAULT NULL,
  `prod_id` mediumint(8) unsigned DEFAULT NULL,
  `url` char(255) DEFAULT NULL,
  `last_mod` timestamp NOT NULL DEFAULT current_timestamp(),
  `last_user` char(63) DEFAULT NULL,
  `valid_from` timestamp NULL DEFAULT NULL,
  `valid_to` timestamp NULL DEFAULT NULL,
  `xtext` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teaser`
--

LOCK TABLES `teaser` WRITE;
/*!40000 ALTER TABLE `teaser` DISABLE KEYS */;
INSERT INTO `teaser` VALUES
(3,'de',1,NULL,0,NULL,'2026-10-08 14:27:21',NULL,NULL,NULL,'');
/*!40000 ALTER TABLE `teaser` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `toast_notes`
--

DROP TABLE IF EXISTS `toast_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `toast_notes` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `created` timestamp NOT NULL DEFAULT current_timestamp(),
  `sid` int(10) unsigned NOT NULL,
  `title` char(63) DEFAULT NULL,
  `type` char(7) NOT NULL DEFAULT 'success' COMMENT 'danger, success, pink, info',
  `delay` smallint(5) unsigned NOT NULL DEFAULT 5000,
  `body` varchar(8191) NOT NULL,
  `style` varchar(8191) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sid` (`sid`)
) ENGINE=InnoDB AUTO_INCREMENT=343 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `toast_notes`
--

LOCK TABLES `toast_notes` WRITE;
/*!40000 ALTER TABLE `toast_notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `toast_notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `status` tinyint(4) NOT NULL DEFAULT 1 COMMENT '1=new, 2=released, 3=blocked',
  `tstamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `uname` char(63) NOT NULL,
  `password_hash` char(127) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT '0',
  `pass` char(63) NOT NULL,
  `email` char(255) NOT NULL,
  `newsletter` tinyint(4) NOT NULL DEFAULT 1,
  `gender` tinyint(4) NOT NULL DEFAULT 1 COMMENT '1=male, 2=female',
  `dob` date DEFAULT NULL COMMENT 'Date of Birth',
  `is_admin` tinyint(1) NOT NULL DEFAULT 0,
  `is_devel` tinyint(1) NOT NULL DEFAULT 0,
  `rel_token` char(8) DEFAULT NULL COMMENT 'Release Token',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uname` (`uname`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,2,'2026-11-09 14:00:26','admin','$argon2id$v=19$m=16384,t=3,p=1$3fMW3iOEtU2JKN586WSBwQ$y5OEgsYUMXlpHiFxEz+A6w','','admin.local.2@algonetic.ch',0,1,NULL,1,1,NULL),
(2,1,'2026-10-01 06:42:23','xyadmin','$argon2id$v=19$m=16384,t=3,p=1$3fMW3iOEtU2JKN586WSBwQ$y5OEgsYUMXlpHiFxEz+A6w','','adm@ch2.be',1,1,NULL,1,0,NULL),
(5,1,'2026-10-07 14:54:52','mmm@ch2.be','0','welcome21','mmm@ch2.be',1,1,'1970-01-01',0,0,'Z63354'),
(4,1,'2026-10-07 14:47:59','susi@ch2.be','0','welcome21','susi@ch2.be',1,2,'1970-01-01',0,0,'443652'),
(7,1,'2026-10-07 15:02:05','logi@ch2.be','0','welcome21','logi@ch2.be',1,1,'1970-01-01',0,0,'9656Z5'),
(8,1,'2026-10-07 15:25:43','furzi@ch2.be','0','welcome21','furzi@ch2.be',1,1,'1970-01-01',0,0,'47252Y'),
(9,1,'2026-10-07 15:38:23','testxx@ch2.be','0','welcome21','testxx@ch2.be',1,1,'1970-01-01',0,0,'46545Y'),
(10,1,'2026-10-07 15:41:12','e@ch2.be','0','welcome21','e@ch2.be',1,1,'1970-01-01',0,0,'63782Z'),
(11,1,'2026-10-07 19:02:30','sadfsdaf@ch2.be','0','welcome20','sadfsdaf@ch2.be',1,1,'1970-01-01',0,0,'8Y8359'),
(13,1,'2026-10-14 05:56:01','ag-besteller-test@ch-shop.ch','0','4r#*nmXq60hE','ag-besteller-test@ch-shop.ch',1,0,'1970-01-01',0,0,'737Z53'),
(19,1,'2026-10-26 14:09:16','reto.schaer@hotmail.com','0','War#Rf4T','reto.schaer@hotmail.com',1,0,'1970-01-01',0,0,'554739'),
(15,1,'2026-10-20 11:46:35','sadfxx@ch2.be','0','welcome20','sadfxx@ch2.be',1,1,'1970-01-01',0,0,'4ZZY48'),
(17,1,'2026-10-20 11:51:59','test@algonetic.ch','0','welcome20','test@algonetic.ch',1,1,'1970-01-01',0,0,'668Z45'),
(18,1,'2026-10-26 10:10:49','testsad@algonetic.ch','0','welcome237','testsad@algonetic.ch',1,2,'1970-01-01',0,0,'Z96567');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_addr`
--

DROP TABLE IF EXISTS `users_addr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users_addr` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` mediumint(8) unsigned NOT NULL COMMENT 'foreign key',
  `type` tinyint(4) NOT NULL DEFAULT 1 COMMENT '1=owner, 2=delivery',
  `instime` timestamp NOT NULL DEFAULT current_timestamp(),
  `lastmod` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `gender` tinyint(4) NOT NULL DEFAULT 1 COMMENT '1=male, 2=female',
  `firstname` varchar(40) NOT NULL,
  `lastname` varchar(255) DEFAULT NULL,
  `company` varchar(255) DEFAULT NULL,
  `street` varchar(511) DEFAULT NULL,
  `zip` varchar(255) DEFAULT NULL,
  `city` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `phone` char(255) DEFAULT NULL,
  `country` char(3) NOT NULL DEFAULT 'CH' COMMENT 'e.g. CH, D, F',
  PRIMARY KEY (`id`),
  UNIQUE KEY `fkey` (`user_id`,`type`)
) ENGINE=MyISAM AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='XXTITLE:=Addresses || EXT_TOP:=_users_addr.html';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_addr`
--

LOCK TABLES `users_addr` WRITE;
/*!40000 ALTER TABLE `users_addr` DISABLE KEYS */;
INSERT INTO `users_addr` VALUES
(1,1,1,'2026-02-10 10:48:04','0000-00-00 00:00:00',1,'Firster','Laster','','Musenstrasse 88 A','8044','Zürich','777','CH'),
(2,2,1,'2026-10-01 06:41:23','0000-00-00 00:00:00',1,'Vor',NULL,NULL,NULL,NULL,NULL,NULL,'CH'),
(3,1,2,'2026-10-03 14:21:42','0000-00-00 00:00:00',1,'Liéf','Lieferinsky','Lieferinskiy AG','Lieferstrasse 47 Abc','9001','Lieferingen','* <abbr title=\'_global\'>site_phone (de)</abbr> *','CH'),
(4,2,2,'2026-10-03 14:21:54','0000-00-00 00:00:00',1,'Vor',NULL,NULL,NULL,NULL,NULL,NULL,'CH'),
(9,5,1,'2026-10-07 14:54:52','0000-00-00 00:00:00',1,'vor','nach','firma','m8','9001','St. Gallen','777','LI'),
(7,4,1,'2026-10-07 14:47:59','0000-00-00 00:00:00',2,'','','acme ltd','m8','8001','Zürich','555','LI'),
(8,4,2,'2026-10-07 14:47:59','0000-00-00 00:00:00',2,'','','acme ltd','m8','8001','Zürich','555','LI'),
(10,5,2,'2026-10-07 14:54:52','0000-00-00 00:00:00',1,'vor','nach','firma','m8','9001','St. Gallen','777','LI'),
(14,7,2,'2026-10-07 15:02:05','0000-00-00 00:00:00',1,'V','n','sadf','sdaf','sadf','sdaf','555','CH'),
(13,7,1,'2026-10-07 15:02:05','0000-00-00 00:00:00',1,'V','n','sadf','sdaf','sadf','sdaf','555','CH'),
(15,8,1,'2026-10-07 15:25:43','0000-00-00 00:00:00',1,'Vorzi','Nachzi','ffffffffff','M8','9001','Vaduz','555','LI'),
(16,8,2,'2026-10-07 15:25:43','0000-00-00 00:00:00',1,'Vorzi','Nachzi','ffffffffff','M8','9001','Vaduz','555','LI'),
(17,9,1,'2026-10-07 15:38:23','0000-00-00 00:00:00',1,'Vr','Nch','Firmaaaaaa AG','M8','9001','Vaduz','888','LI'),
(18,9,2,'2026-10-07 15:38:23','0000-00-00 00:00:00',1,'Vr','Nch','Firmaaaaaa AG','M8','9001','Vaduz','888','LI'),
(19,10,1,'2026-10-07 15:41:12','0000-00-00 00:00:00',1,'V','N','fffffffff','M8','9001','Vaduz','777','LI'),
(20,10,2,'2026-10-07 15:41:12','0000-00-00 00:00:00',1,'V','N','fffffffff','M8','9001','Vaduz','777','LI'),
(21,11,1,'2026-10-07 19:02:30','0000-00-00 00:00:00',1,'dsaf','sadf','fffffffff','m8','9999','nirgendwo','555','CH'),
(22,11,2,'2026-10-07 19:02:30','0000-00-00 00:00:00',1,'dsaf','sadf','fffffffff','m8','9999','nirgendwo','555','CH'),
(26,13,2,'2026-10-14 05:56:01','0000-00-00 00:00:00',1,'Kt.','Aargau','','asdf','sadf','','* <abbr title= _global >site_phone (de)</abbr> *','CH'),
(25,13,1,'2026-10-14 05:56:01','0000-00-00 00:00:00',1,'Kt.','Aargau','','','','','','CH'),
(37,19,1,'2026-10-26 14:09:16','0000-00-00 00:00:00',1,'Reto','Schär','','','','','','CH'),
(29,15,1,'2026-10-20 11:46:35','0000-00-00 00:00:00',1,'asdf','asdf','asdf','sdaf','sadf','sadf','55','CH'),
(30,15,2,'2026-10-20 11:46:35','0000-00-00 00:00:00',1,'asdf','asdf','asdf','sdaf','sadf','sadf','55','CH'),
(38,19,2,'2026-10-26 14:09:16','0000-00-00 00:00:00',1,'Reto','Schär','ALGONETIC Ltd','Moussonstrasse 8','8044','Zurich','* <abbr title=\'_global\'>site_phone (de)</abbr> *','CH'),
(33,17,1,'2026-10-20 11:51:59','0000-00-00 00:00:00',1,'asdf','sadf','','sad','sadf','sadf','55','CH'),
(34,17,2,'2026-10-20 11:51:59','0000-00-00 00:00:00',1,'asdf','sadf','','sad','sadf','sadf','55','CH'),
(35,18,1,'2026-10-26 10:10:49','0000-00-00 00:00:00',2,'Vörkera','Nachünski','','asdf','8001','Zürich','555','CH'),
(36,18,2,'2026-10-26 10:10:49','0000-00-00 00:00:00',2,'Vörkera','Nachünski','','asdf','8001','Zürich','555','CH');
/*!40000 ALTER TABLE `users_addr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_details`
--

DROP TABLE IF EXISTS `users_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users_details` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` mediumint(8) unsigned NOT NULL COMMENT 'foreign key',
  `tstamp` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp(),
  `xkey` char(31) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `xval` char(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `okey` (`user_id`,`xkey`)
) ENGINE=MyISAM AUTO_INCREMENT=130 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_details`
--

LOCK TABLES `users_details` WRITE;
/*!40000 ALTER TABLE `users_details` DISABLE KEYS */;
INSERT INTO `users_details` VALUES
(5,1,'2026-02-12 11:03:17','profile_pic','profile_pic_1_ad.jpg'),
(6,1,'2026-02-15 16:38:19','dept_d','13-DRZN'),
(9,1,'2026-02-15 10:34:34','2fa_enabled','0'),
(10,1,'2026-02-15 10:07:16','2fa_secret',''),
(11,1,'2026-02-15 10:35:24','2fa_secret_enc',''),
(15,1,'2026-02-15 16:38:11','uuid_602151','290243054e02aebb418127aae21339f7'),
(16,1,'2026-02-15 16:38:11','uuid_602151-2','b939ea4cfe58372fdc73521b73414a58'),
(17,1,'2026-02-16 13:58:03','uuid_602161','290243054e02aebb418127aae21339f7'),
(18,1,'2026-02-16 13:58:03','uuid_602161-2','b939ea4cfe58372fdc73521b73414a58'),
(19,1,'2026-02-16 20:07:30','perm_is_csp','1'),
(20,1,'2026-02-16 20:07:30','hist_Berechtigung_60216210730','CSP-Rechte ge&auml;ndert zu 1 durch admin@x.pgate.net'),
(21,1,'0000-00-00 00:00:00','perm_is_ssg','1'),
(22,1,'2026-09-26 16:18:52','uuid_609261','1b04f08fb348fee4ae9311ffc577bb2b'),
(23,1,'2026-09-26 16:18:52','uuid_609261-2','5e1d119d33248ca39ca59c776282dbbd'),
(24,1,'2026-09-29 05:42:08','uuid_609290','ad3380642cd9ad102116840368e62e26'),
(25,1,'2026-09-29 05:42:08','uuid_609290-2','f52f2dc40e303c23c52ba79d428085b4'),
(26,2,'2026-10-01 06:43:31','uuid_610010','38ffe08f5ca2e4424a854350080f247b'),
(27,2,'2026-10-01 06:43:31','uuid_610010-2','e615fa10dc458da15c8b84bd8e3d02f8'),
(28,1,'0000-00-00 00:00:00','_lic_status','1'),
(40,5,'0000-00-00 00:00:00','registration_time','2026-10-07 16:54:52'),
(39,5,'0000-00-00 00:00:00','lang',''),
(38,5,'0000-00-00 00:00:00','cb_pay_cod','on'),
(37,5,'0000-00-00 00:00:00','cb_pay_cc','on'),
(33,4,'0000-00-00 00:00:00','cb_pay_cc','on'),
(34,4,'0000-00-00 00:00:00','cb_pay_cod','on'),
(35,4,'0000-00-00 00:00:00','lang',''),
(36,4,'0000-00-00 00:00:00','registration_time','2026-10-07 16:47:59'),
(48,7,'0000-00-00 00:00:00','registration_time','2026-10-07 17:02:05'),
(47,7,'0000-00-00 00:00:00','lang',''),
(46,7,'0000-00-00 00:00:00','cb_pay_cod','on'),
(45,7,'0000-00-00 00:00:00','cb_pay_cc','on'),
(49,8,'0000-00-00 00:00:00','cb_pay_cc','on'),
(50,8,'0000-00-00 00:00:00','cb_pay_cod','on'),
(51,8,'0000-00-00 00:00:00','lang',''),
(52,8,'0000-00-00 00:00:00','registration_time','2026-10-07 17:25:43'),
(53,9,'0000-00-00 00:00:00','cb_pay_cc','on'),
(54,9,'0000-00-00 00:00:00','cb_pay_cod','on'),
(55,9,'0000-00-00 00:00:00','lang',''),
(56,9,'0000-00-00 00:00:00','registration_time','2026-10-07 17:38:23'),
(57,10,'0000-00-00 00:00:00','cb_pay_cc','on'),
(58,10,'0000-00-00 00:00:00','cb_pay_cod','on'),
(59,10,'0000-00-00 00:00:00','lang',''),
(60,10,'0000-00-00 00:00:00','registration_time','2026-10-07 17:41:12'),
(61,11,'0000-00-00 00:00:00','cb_pay_cc','on'),
(62,11,'0000-00-00 00:00:00','cb_pay_cod','on'),
(63,11,'0000-00-00 00:00:00','lang',''),
(64,11,'0000-00-00 00:00:00','registration_time','2026-10-07 21:02:30'),
(93,13,'2026-10-14 05:56:01','hist_Registration_61014075601','Opt-in: ag-besteller-test@ch-shop.ch'),
(119,19,'0000-00-00 00:00:00','registration_time','2026-10-26 15:09:16'),
(129,1,'2026-11-09 14:00:28','hist_update_account_61109150028','Your username changed from <s>admix</s> to <b>\"admin\"</b>!, An e-mail notification has been sent to admin.local.2@algonetic.ch'),
(84,1,'2026-10-13 13:59:20','wishlist_prod_7','{\"price\": 700}'),
(90,13,'0000-00-00 00:00:00','origin','registration'),
(88,13,'0000-00-00 00:00:00','registration_time','2026-10-14 07:56:01'),
(92,13,'0000-00-00 00:00:00','reg_ip',''),
(86,13,'0000-00-00 00:00:00','cb_pay_cod','on'),
(89,13,'0000-00-00 00:00:00','sid','122'),
(87,13,'0000-00-00 00:00:00','lang','de'),
(91,13,'0000-00-00 00:00:00','dept_d','KTAG tbd'),
(85,13,'0000-00-00 00:00:00','cb_pay_cc','on'),
(118,19,'0000-00-00 00:00:00','lang','de'),
(117,19,'0000-00-00 00:00:00','cb_pay_cod','on'),
(116,19,'0000-00-00 00:00:00','cb_pay_cc','on'),
(98,15,'0000-00-00 00:00:00','cb_pay_cc','on'),
(99,15,'0000-00-00 00:00:00','cb_pay_cod','on'),
(100,15,'0000-00-00 00:00:00','lang',''),
(101,15,'0000-00-00 00:00:00','registration_time','2026-10-20 13:46:35'),
(123,19,'0000-00-00 00:00:00','sid','143'),
(122,19,'0000-00-00 00:00:00','origin','registration'),
(121,19,'0000-00-00 00:00:00','reg_ip',''),
(120,19,'0000-00-00 00:00:00','dept_d','KTAG tbd'),
(106,17,'0000-00-00 00:00:00','cb_pay_cc','on'),
(107,17,'0000-00-00 00:00:00','cb_pay_cod','on'),
(108,17,'0000-00-00 00:00:00','lang',''),
(109,17,'0000-00-00 00:00:00','registration_time','2026-10-20 13:51:59'),
(110,1,'2026-10-21 09:08:01','wishlist_prod_6','{\"price\": 300}'),
(125,1,'2026-10-28 08:54:07','wishlist_prod_4','{\"price\": 755.6}'),
(112,18,'0000-00-00 00:00:00','cb_pay_cc','on'),
(113,18,'0000-00-00 00:00:00','cb_pay_cod','on'),
(114,18,'0000-00-00 00:00:00','lang',''),
(115,18,'0000-00-00 00:00:00','registration_time','2026-10-26 11:10:49'),
(124,19,'2026-10-26 14:09:16','hist_Registration_61026150916','Opt-in: reto.schaer@hotmail.com'),
(126,1,'2026-10-28 14:19:53','wishlist_prod_10','{\"price\": 998}'),
(128,1,'2026-11-09 10:18:50','hist_update_account_61109111850','Your username changed from <s>admin</s> to <b>\"admix\"</b>!, An e-mail notification has been sent to admin.local.2@algonetic.ch');
/*!40000 ALTER TABLE `users_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `v_ssp_items_2_w_dpt_from_ord`
--

DROP TABLE IF EXISTS `v_ssp_items_2_w_dpt_from_ord`;
/*!50001 DROP VIEW IF EXISTS `v_ssp_items_2_w_dpt_from_ord`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `v_ssp_items_2_w_dpt_from_ord` AS SELECT
 1 AS `id`,
  1 AS `order_id`,
  1 AS `pos`,
  1 AS `dept_id`,
  1 AS `qty` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_ssp_items_w_dpt_from_ord`
--

DROP TABLE IF EXISTS `v_ssp_items_w_dpt_from_ord`;
/*!50001 DROP VIEW IF EXISTS `v_ssp_items_w_dpt_from_ord`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `v_ssp_items_w_dpt_from_ord` AS SELECT
 1 AS `order_id`,
  1 AS `id`,
  1 AS `pos`,
  1 AS `subpos`,
  1 AS `dept_id`,
  1 AS `dept_ref` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_ssp_orders`
--

DROP TABLE IF EXISTS `v_ssp_orders`;
/*!50001 DROP VIEW IF EXISTS `v_ssp_orders`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `v_ssp_orders` AS SELECT
 1 AS `id`,
  1 AS `uid`,
  1 AS `email`,
  1 AS `dept_id`,
  1 AS `dept_ref`,
  1 AS `order_creation_time`,
  1 AS `amount`,
  1 AS `order_status_id`,
  1 AS `status_id` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_ssp_orders_articles`
--

DROP TABLE IF EXISTS `v_ssp_orders_articles`;
/*!50001 DROP VIEW IF EXISTS `v_ssp_orders_articles`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `v_ssp_orders_articles` AS SELECT
 1 AS `order_id`,
  1 AS `pos`,
  1 AS `dept_id`,
  1 AS `dept_ref` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vbasket_stock_check`
--

DROP TABLE IF EXISTS `vbasket_stock_check`;
/*!50001 DROP VIEW IF EXISTS `vbasket_stock_check`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `vbasket_stock_check` AS SELECT
 1 AS `basket_id`,
  1 AS `prod_id`,
  1 AS `count_basket`,
  1 AS `count_stock`,
  1 AS `sid` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `voptions`
--

DROP TABLE IF EXISTS `voptions`;
/*!50001 DROP VIEW IF EXISTS `voptions`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `voptions` AS SELECT
 1 AS `id`,
  1 AS `style`,
  1 AS `mandatory`,
  1 AS `lang`,
  1 AS `label`,
  1 AS `description`,
  1 AS `ref`,
  1 AS `amount`,
  1 AS `det_id`,
  1 AS `feat_id`,
  1 AS `weight`,
  1 AS `stock` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `voptions2`
--

DROP TABLE IF EXISTS `voptions2`;
/*!50001 DROP VIEW IF EXISTS `voptions2`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `voptions2` AS SELECT
 1 AS `id`,
  1 AS `label`,
  1 AS `lang`,
  1 AS `mandatory`,
  1 AS `style`,
  1 AS `instime`,
  1 AS `weight`,
  1 AS `inc_art_no`,
  1 AS `sel_desc`,
  1 AS `det_id`,
  1 AS `feat_id`,
  1 AS `ref`,
  1 AS `amount`,
  1 AS `stock`,
  1 AS `feat_instime` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vorders`
--

DROP TABLE IF EXISTS `vorders`;
/*!50001 DROP VIEW IF EXISTS `vorders`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `vorders` AS SELECT
 1 AS `id`,
  1 AS `sid`,
  1 AS `uid`,
  1 AS `pay_meth`,
  1 AS `instime`,
  1 AS `vat_rate`,
  1 AS `amount_incl_vat`,
  1 AS `uname`,
  1 AS `email`,
  1 AS `status`,
  1 AS `remarks` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vorders_custname`
--

DROP TABLE IF EXISTS `vorders_custname`;
/*!50001 DROP VIEW IF EXISTS `vorders_custname`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `vorders_custname` AS SELECT
 1 AS `id`,
  1 AS `sid`,
  1 AS `uid`,
  1 AS `firstname`,
  1 AS `lastname`,
  1 AS `gender`,
  1 AS `company`,
  1 AS `zip`,
  1 AS `city`,
  1 AS `country`,
  1 AS `pay_meth`,
  1 AS `instime`,
  1 AS `vat_rate`,
  1 AS `amount_incl_vat`,
  1 AS `uname`,
  1 AS `email`,
  1 AS `status`,
  1 AS `remarks` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `vouchers`
--

DROP TABLE IF EXISTS `vouchers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `vouchers` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `creator_id` mediumint(8) unsigned DEFAULT NULL,
  `style` smallint(6) unsigned DEFAULT 1 COMMENT 'tbd.',
  `vcode` char(31) NOT NULL,
  `instime` timestamp NOT NULL DEFAULT current_timestamp(),
  `last_mod` timestamp NULL DEFAULT NULL,
  `amount` decimal(5,2) DEFAULT NULL,
  `perc` double DEFAULT NULL,
  `categ_id` mediumint(8) unsigned DEFAULT NULL,
  `uid` bigint(20) unsigned DEFAULT NULL,
  `valid_from` timestamp NULL DEFAULT NULL,
  `valid_to` timestamp NULL DEFAULT NULL,
  `count_available` int(10) unsigned DEFAULT NULL,
  `count_used` int(10) unsigned DEFAULT NULL,
  `status` tinyint(3) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `vcode` (`vcode`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='One option per row. No prices on this level! Upd: 16.04.2013';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vouchers`
--

LOCK TABLES `vouchers` WRITE;
/*!40000 ALTER TABLE `vouchers` DISABLE KEYS */;
INSERT INTO `vouchers` VALUES
(4,NULL,1,'VTEST5','2026-10-03 15:44:53',NULL,5.00,0,0,NULL,'2026-10-02 22:00:00','2030-10-02 22:00:00',0,0,1),
(2,NULL,1,'VTEST10','2026-10-03 15:08:10',NULL,0.00,10,0,NULL,'2026-10-02 22:00:00','2030-10-02 22:00:00',0,138,1);
/*!40000 ALTER TABLE `vouchers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `vproducts`
--

DROP TABLE IF EXISTS `vproducts`;
/*!50001 DROP VIEW IF EXISTS `vproducts`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `vproducts` AS SELECT
 1 AS `id`,
  1 AS `art_no`,
  1 AS `cat_id`,
  1 AS `price`,
  1 AS `campaign_id`,
  1 AS `lang`,
  1 AS `brand`,
  1 AS `title`,
  1 AS `description`,
  1 AS `desc_long`,
  1 AS `count`,
  1 AS `extra`,
  1 AS `condition`,
  1 AS `instime` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vproducts_1_02`
--

DROP TABLE IF EXISTS `vproducts_1_02`;
/*!50001 DROP VIEW IF EXISTS `vproducts_1_02`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `vproducts_1_02` AS SELECT
 1 AS `id`,
  1 AS `art_no`,
  1 AS `cat_id`,
  1 AS `price`,
  1 AS `campaign_id`,
  1 AS `lang`,
  1 AS `title`,
  1 AS `description`,
  1 AS `desc_long`,
  1 AS `count`,
  1 AS `extra`,
  1 AS `condition`,
  1 AS `instime` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vusers`
--

DROP TABLE IF EXISTS `vusers`;
/*!50001 DROP VIEW IF EXISTS `vusers`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `vusers` AS SELECT
 1 AS `id`,
  1 AS `status`,
  1 AS `tstamp`,
  1 AS `uname`,
  1 AS `firstname`,
  1 AS `lastname`,
  1 AS `company`,
  1 AS `city`,
  1 AS `country`,
  1 AS `email`,
  1 AS `phone`,
  1 AS `gender`,
  1 AS `is_admin`,
  1 AS `is_devel` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `work`
--

DROP TABLE IF EXISTS `work`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `work` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `k` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL COMMENT 'Key Name (unique)',
  `tstamp` timestamp NOT NULL DEFAULT current_timestamp(),
  `xval` varchar(511) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `k` (`k`)
) ENGINE=MyISAM AUTO_INCREMENT=142 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `work`
--

LOCK TABLES `work` WRITE;
/*!40000 ALTER TABLE `work` DISABLE KEYS */;
INSERT INTO `work` VALUES
(114,'HIST402041_consent:event_set_ready__2026-11-11 10:33:18','2026-11-11 09:33:18','Updated event_set_ready: 1 by UID 1'),
(115,'categ_count_9','2026-11-13 09:32:05','0'),
(116,'categ_count_8','2026-11-13 09:32:05','2'),
(117,'categ_count_13','2026-11-13 09:32:05','1'),
(118,'categ_count_10','2026-11-13 09:32:05','0'),
(119,'categ_count_1','2026-11-13 09:32:05','8'),
(120,'categ_count_6','2026-11-13 09:32:05','0'),
(121,'env_V0.8022_ip_info_hostname','2026-11-13 09:32:05','Unknown-172.18.0.3'),
(122,'env_V0.8022_kernel_release','2026-11-13 09:32:05','6.18.33.2-microsoft-standard-WSL2'),
(123,'env_V0.8022_uname_rel','2026-11-13 09:32:05','6.18.33.2-microsoft-standard-WSL2'),
(124,'env_V0.8022_db_orig','2026-11-13 09:32:05',''),
(125,'env_V0.8022_db_software','2026-11-13 09:32:05','MySQL'),
(126,'env_V0.8022_server_ip','2026-11-13 09:32:05','127.0.0.1'),
(127,'env_V0.8022_mailname','2026-11-13 09:32:05',''),
(128,'env_V0.8022_ip_info_org','2026-11-13 09:32:05','N/A'),
(129,'env_V0.8022_ip_info_city','2026-11-13 09:32:05','ZRH'),
(130,'env_V0.8022_webserver','2026-11-13 09:32:05','Apache 2.4.66-1~deb12u1\n'),
(131,'env_V0.8022_webuser','2026-11-13 09:32:05','www-data'),
(132,'env_V0.8022_db','2026-11-13 09:32:05','MySQL '),
(133,'env_V0.8022_uname_all','2026-11-13 09:32:05','Linux kubernetes.docker.internal 6.18.33.2-microsoft-standard-WSL2 #1 SMP PREEMPT_DYNAMIC Thu Jun 18 21:54:43 UTC 2026 x86_64 GNU/Linux'),
(134,'env_V0.8022_VERSION','2026-11-13 09:32:05','0.8022'),
(135,'env_V0.8022_os','2026-11-13 09:32:05','Debian 12.13'),
(136,'env_V0.8022_daemon','2026-11-13 09:32:05','apache2'),
(137,'env_V0.8022_x_server_ip','2026-11-13 09:32:05',''),
(138,'env_V0.8022_ip_info_bogon','2026-11-13 09:32:05','1'),
(139,'env_V0.8022_uptime','2026-11-13 09:32:05','10 min, user (13.11.2026 10:32)'),
(140,'env_V0.8022_hostname','2026-11-13 09:32:05','kubernetes.docker.internal'),
(141,'env_V0.8022_ip_info_ip','2026-11-13 09:32:05','172.18.0.3');
/*!40000 ALTER TABLE `work` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'db_shop_design'
--

--
-- Dumping routines for database 'db_shop_design'
--
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP FUNCTION IF EXISTS `getProdFeat` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` FUNCTION `getProdFeat`(`prodid` MEDIUMINT,
    `featk` CHAR(31)
) RETURNS varchar(2047) CHARSET utf8mb4 COLLATE utf8mb4_general_ci
    READS SQL DATA
RETURN (
    SELECT `description`
    FROM `products_feat`
    WHERE `product_id` = `prodid`
      AND `lang` IN ('de', 'SYS')
      AND `featkey` = `featk`
    LIMIT 1
) ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP FUNCTION IF EXISTS `SPLIT_STR` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `SPLIT_STR`(x VARCHAR(255),
  delim VARCHAR(12),
  pos INT
) RETURNS varchar(255) CHARSET latin1 COLLATE latin1_swedish_ci
RETURN REPLACE(SUBSTRING(SUBSTRING_INDEX(x, delim, pos),
       LENGTH(SUBSTRING_INDEX(x, delim, pos -1)) + 1),
       delim, '') ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Final view structure for view `v_ssp_items_2_w_dpt_from_ord`
--

/*!50001 DROP VIEW IF EXISTS `v_ssp_items_2_w_dpt_from_ord`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`apache`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_ssp_items_2_w_dpt_from_ord` AS select `orders_details`.`id` AS `id`,`orders_details`.`order_id` AS `order_id`,cast(`split_str`(`orders_details`.`xkey`,'_',3) as unsigned) AS `pos`,cast(`split_str`(`orders_details`.`xkey`,'_',4) as unsigned) AS `dept_id`,cast(`orders_details`.`xval` as unsigned) AS `qty` from `orders_details` where `orders_details`.`xkey` like 'qty\\_pos\\_%\\_%' */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_ssp_items_w_dpt_from_ord`
--

/*!50001 DROP VIEW IF EXISTS `v_ssp_items_w_dpt_from_ord`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`apache`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_ssp_items_w_dpt_from_ord` AS select `o`.`order_id` AS `order_id`,`o`.`id` AS `id`,cast(`split_str`(`o`.`xkey`,'_',2) as unsigned) AS `pos`,cast(`split_str`(`o`.`xkey`,'_',3) as unsigned) AS `subpos`,`o`.`dept_id` AS `dept_id`,`c`.`ref` AS `dept_ref` from (`orders_details` `o` left join `categories` `c` on(`c`.`id` = `o`.`dept_id`)) where `o`.`xkey` like 'dept\\_%\\_%' */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_ssp_orders`
--

/*!50001 DROP VIEW IF EXISTS `v_ssp_orders`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`apache`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_ssp_orders` AS (select `o`.`id` AS `id`,`o`.`uid` AS `uid`,`u`.`email` AS `email`,`oa`.`dept_id` AS `dept_id`,`oa`.`dept_ref` AS `dept_ref`,`o`.`instime` AS `order_creation_time`,`o`.`amount_incl_vat` AS `amount`,`o`.`status` AS `order_status_id`,`ordsat`.`status_id` AS `status_id` from ((((`orders` `o` join `users` `u` on(`o`.`uid` = `u`.`id`)) left join `users_details` `ud` on(`ud`.`user_id` = `o`.`uid` and `ud`.`xkey` = 'dept_d')) left join (select `v_ssp_orders_articles`.`order_id` AS `order_id`,group_concat(distinct `v_ssp_orders_articles`.`dept_id` order by `v_ssp_orders_articles`.`dept_id` ASC separator ',') AS `dept_id`,group_concat(distinct `v_ssp_orders_articles`.`dept_ref` order by `v_ssp_orders_articles`.`dept_ref` ASC separator ',') AS `dept_ref` from `v_ssp_orders_articles` group by `v_ssp_orders_articles`.`order_id`) `oa` on(`oa`.`order_id` = `o`.`id`)) left join (select `os1`.`id` AS `id`,`os1`.`created_at` AS `created_at`,`os1`.`uid` AS `uid`,`os1`.`src` AS `src`,`os1`.`order_id` AS `order_id`,`os1`.`status_id` AS `status_id`,`os1`.`xval` AS `xval` from (`orders_status` `os1` join (select `orders_status`.`order_id` AS `order_id`,max(`orders_status`.`id`) AS `max_id` from `orders_status` where `orders_status`.`status_id` between 700 and 801 or `orders_status`.`status_id` = 251 group by `orders_status`.`order_id`) `latest` on(`latest`.`order_id` = `os1`.`order_id` and `latest`.`max_id` = `os1`.`id`))) `ordsat` on(`ordsat`.`order_id` = `o`.`id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_ssp_orders_articles`
--

/*!50001 DROP VIEW IF EXISTS `v_ssp_orders_articles`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`apache`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_ssp_orders_articles` AS select `items_pt2`.`order_id` AS `order_id`,`items_pt2`.`pos` AS `pos`,`items_pt2`.`dept_id` AS `dept_id`,`cat`.`ref` AS `dept_ref` from (`v_ssp_items_2_w_dpt_from_ord` `items_pt2` join `categories` `cat`) where `items_pt2`.`dept_id` = `cat`.`id` union select `v_ssp_items_w_dpt_from_ord`.`order_id` AS `order_id`,`v_ssp_items_w_dpt_from_ord`.`pos` AS `pos`,`v_ssp_items_w_dpt_from_ord`.`dept_id` AS `dept_id`,`v_ssp_items_w_dpt_from_ord`.`dept_ref` AS `dept_ref` from `v_ssp_items_w_dpt_from_ord` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vbasket_stock_check`
--

/*!50001 DROP VIEW IF EXISTS `vbasket_stock_check`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`apache`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `vbasket_stock_check` AS (select `b`.`id` AS `basket_id`,`b`.`prod_id` AS `prod_id`,sum(`b`.`count`) AS `count_basket`,`p`.`count` AS `count_stock`,`b`.`sid` AS `sid` from (`basket` `b` join `products` `p`) where `b`.`prod_id` = `p`.`id` and `p`.`condition` = 'SO' group by 1) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `voptions`
--

/*!50001 DROP VIEW IF EXISTS `voptions`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `voptions` AS (select `o`.`id` AS `id`,`o`.`style` AS `style`,`o`.`mandatory` AS `mandatory`,`d`.`lang` AS `lang`,`d`.`label` AS `label`,`f`.`description` AS `description`,`p`.`ref` AS `ref`,`p`.`amount` AS `amount`,`p`.`id` AS `det_id`,`f`.`id` AS `feat_id`,`o`.`weight` AS `weight`,`p`.`stock` AS `stock` from (((`options` `o` join `options_desc` `d`) join `options_feat` `f`) join `options_details` `p`) where `o`.`id` = `d`.`option_id` and `o`.`id` = `f`.`option_id` and `f`.`lang` = `d`.`lang` and `f`.`details_id` = `p`.`id`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `voptions2`
--

/*!50001 DROP VIEW IF EXISTS `voptions2`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `voptions2` AS select `o`.`id` AS `id`,`d`.`label` AS `label`,`d`.`lang` AS `lang`,`o`.`mandatory` AS `mandatory`,`o`.`style` AS `style`,`o`.`instime` AS `instime`,`o`.`weight` AS `weight`,`o`.`inc_art_no` AS `inc_art_no`,`f`.`description` AS `sel_desc`,`f`.`details_id` AS `det_id`,`f`.`id` AS `feat_id`,`x`.`ref` AS `ref`,`x`.`amount` AS `amount`,`x`.`stock` AS `stock`,`x`.`instime` AS `feat_instime` from (((`options` `o` join `options_desc` `d` on(`o`.`id` = `d`.`option_id`)) join `options_feat` `f` on(`f`.`option_id` = `o`.`id`)) left join `options_details` `x` on(`f`.`details_id` = `x`.`id`)) where `d`.`lang` = `f`.`lang` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vorders`
--

/*!50001 DROP VIEW IF EXISTS `vorders`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `vorders` AS (select `o`.`id` AS `id`,`o`.`sid` AS `sid`,`o`.`uid` AS `uid`,`o`.`pay_meth` AS `pay_meth`,`o`.`instime` AS `instime`,`o`.`vat_rate` AS `vat_rate`,`o`.`amount_incl_vat` AS `amount_incl_vat`,`u`.`uname` AS `uname`,`u`.`email` AS `email`,`o`.`status` AS `status`,`o`.`remarks` AS `remarks` from (`orders` `o` left join `users` `u` on(`o`.`uid` = `u`.`id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vorders_custname`
--

/*!50001 DROP VIEW IF EXISTS `vorders_custname`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `vorders_custname` AS (select `v`.`id` AS `id`,`v`.`sid` AS `sid`,`v`.`uid` AS `uid`,`a`.`firstname` AS `firstname`,`a`.`lastname` AS `lastname`,`a`.`gender` AS `gender`,`a`.`company` AS `company`,`a`.`zip` AS `zip`,`a`.`city` AS `city`,`a`.`country` AS `country`,`v`.`pay_meth` AS `pay_meth`,`v`.`instime` AS `instime`,`v`.`vat_rate` AS `vat_rate`,`v`.`amount_incl_vat` AS `amount_incl_vat`,`v`.`uname` AS `uname`,`v`.`email` AS `email`,`v`.`status` AS `status`,`v`.`remarks` AS `remarks` from (`vorders` `v` join `users_addr` `a`) where `v`.`uid` = `a`.`user_id` and `a`.`type` = 1) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vproducts`
--

/*!50001 DROP VIEW IF EXISTS `vproducts`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`apache`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `vproducts` AS (select `products`.`id` AS `id`,`products`.`art_no` AS `art_no`,`products2categ`.`cat_id` AS `cat_id`,`products`.`price` AS `price`,`products`.`campaign_id` AS `campaign_id`,`products_desc`.`lang` AS `lang`,`products`.`brand` AS `brand`,`products_desc`.`title` AS `title`,`products_desc`.`description` AS `description`,`products_desc`.`desc_long` AS `desc_long`,`products`.`count` AS `count`,`products`.`extra` AS `extra`,`products`.`condition` AS `condition`,`products`.`instime` AS `instime` from ((`products` join `products2categ`) join `products_desc`) where `products`.`id` = `products_desc`.`product_id` and `products`.`id` = `products2categ`.`product_id`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vproducts_1_02`
--

/*!50001 DROP VIEW IF EXISTS `vproducts_1_02`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`apache`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `vproducts_1_02` AS (select `products`.`id` AS `id`,`products`.`art_no` AS `art_no`,`products2categ`.`cat_id` AS `cat_id`,`products`.`price` AS `price`,`products`.`campaign_id` AS `campaign_id`,`products_desc`.`lang` AS `lang`,`products_desc`.`title` AS `title`,`products_desc`.`description` AS `description`,`products_desc`.`desc_long` AS `desc_long`,`products`.`count` AS `count`,`products`.`extra` AS `extra`,`products`.`condition` AS `condition`,`products`.`instime` AS `instime` from ((`products` join `products2categ`) join `products_desc`) where `products`.`id` = `products_desc`.`product_id` and `products`.`id` = `products2categ`.`product_id`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vusers`
--

/*!50001 DROP VIEW IF EXISTS `vusers`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`apache`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `vusers` AS (select `u`.`id` AS `id`,`u`.`status` AS `status`,`u`.`tstamp` AS `tstamp`,`u`.`uname` AS `uname`,`a`.`firstname` AS `firstname`,`a`.`lastname` AS `lastname`,`a`.`company` AS `company`,`a`.`city` AS `city`,`a`.`country` AS `country`,`u`.`email` AS `email`,`a`.`phone` AS `phone`,`u`.`gender` AS `gender`,`u`.`is_admin` AS `is_admin`,`u`.`is_devel` AS `is_devel` from (`users` `u` join `users_addr` `a`) where `u`.`id` = `a`.`user_id` and `a`.`type` = 1) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-13 10:32:18
